<?php
/**
 * api.php
 * API de SOLO LECTURA (Consultas SELECT) a SQL Server AWS (Conduit)
 * Totalmente protegido: NO contiene operaciones INSERT, UPDATE ni DELETE.
 */

require_once __DIR__ . '/conexion.php';

header("Content-Type: application/json; charset=utf-8");

// Forzar que solo se acepten peticiones GET (Solo Consultas)
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "error" => "Método no permitido. Esta API está configurada exclusivamente para consultas de solo lectura (GET)."
    ]);
    exit();
}

$action = isset($_GET['action']) ? trim($_GET['action']) : '';

// Conectar a Conduit en AWS / Local
$conn = ConectadoAIntelisisAWS2();

if (!$conn && $action !== 'test') {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "error" => "No fue posible conectar con el servidor SQL Server en AWS.",
        "detalles" => function_exists('sqlsrv_errors') ? sqlsrv_errors() : "Extensión sqlsrv no disponible"
    ]);
    exit();
}

// Verificación de parámetro forzar recarga
$forzar = isset($_GET['forzar']) && ($_GET['forzar'] === '1' || $_GET['forzar'] === 'true');

/**
 * Función de caché temporal en disco (60-120s) para acelerar tiempos de respuesta
 */
function ejecutarConsultaConCache($conn, $cacheKey, $sql, $ttl = 60, $forzar = false) {
    $cacheDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'siai_sql_cache';
    if (!is_dir($cacheDir)) {
        @mkdir($cacheDir, 0777, true);
    }
    $cacheFile = $cacheDir . DIRECTORY_SEPARATOR . md5($cacheKey) . '.json';

    if (!$forzar && file_exists($cacheFile) && (time() - filemtime($cacheFile) < $ttl)) {
        $contenido = @file_get_contents($cacheFile);
        if ($contenido) {
            $dec = json_decode($contenido, true);
            if ($dec && !empty($dec['success'])) {
                return $dec;
            }
        }
    }

    $res = dbSelect($conn, $sql);
    if (!empty($res['success']) && !empty($res['data'])) {
        @file_put_contents($cacheFile, json_encode($res));
    }
    return $res;
}

try {
    switch ($action) {

        // ==========================================
        // 0. TEST DE CONEXIÓN A CONDUIT
        // ==========================================
        case 'test':
            if ($conn) {
                $ver = dbSelect($conn, "SELECT @@VERSION as version, DB_NAME() as db_actual, GETDATE() as fecha_servidor");
                echo json_encode([
                    "success" => true,
                    "mensaje" => "Conexión de solo lectura exitosa a SQL Server AWS",
                    "info" => $ver["data"][0] ?? []
                ]);
            } else {
                http_response_code(500);
                echo json_encode([
                    "success" => false,
                    "error" => "Fallo de conexión a SQL Server AWS",
                    "detalles" => function_exists('sqlsrv_errors') ? sqlsrv_errors() : "Driver no instalado"
                ]);
            }
            break;

        // ==========================================
        // 1. CONSULTA RECUPERACIÓN (ALMACÉN RECUMX) - ULTRARRÁPIDA
        // ==========================================
        case 'get_recuperacion_sql':
            $sql = "SELECT  
                        ad.Almacen,
                        ad.Articulo,
                        a.Descripcion1,
                        a.Unidad,
                        ad.Disponible,
                        a.Peso,
                        a.Familia,
                        a.Grupo,
                        a.Categoria,
                        a.Rama,
                        a.Linea,
                        ((ISNULL(ad.Disponible, 0) * ISNULL(a.Peso, 0)) / 1000.0) AS Total
                    FROM (
                        SELECT Almacen, Articulo, Disponible
                        FROM ArtDisponible WITH (NOLOCK)
                        WHERE Almacen = 'RECUMX' AND Disponible > 0
                    ) AS ad
                    JOIN Art AS a WITH (NOLOCK) ON a.Articulo = ad.Articulo
                    ORDER BY ad.Articulo ASC";
            
            $res = ejecutarConsultaConCache($conn, 'get_recuperacion_sql', $sql, 90, $forzar);
            echo json_encode($res);
            break;

        // ==========================================
        // 2. CONSULTA TRANSFERENCIAS (RECUMX -> IFMX / T1BMX) - ULTRARRÁPIDA
        // ==========================================
        case 'get_transferencias_sql':
            $sql = "SELECT 
                        i.MovID, 
                        i.FechaEmision, 
                        i.Concepto, 
                        i.Usuario, 
                        i.Referencia, 
                        i.Almacen, 
                        i.AlmacenDestino, 
                        d.Articulo, 
                        a.Descripcion1, 
                        a.Unidad, 
                        d.Cantidad, 
                        a.Peso, 
                        ((ISNULL(d.Cantidad, 0) * ISNULL(a.Peso, 0)) / 1000.0) AS Total
                    FROM (
                        SELECT ID, MovID, FechaEmision, Concepto, Usuario, Referencia, Almacen, AlmacenDestino
                        FROM inv WITH (NOLOCK)
                        WHERE ejercicio > 2025 
                          AND Mov = 'Transferencia' 
                          AND Almacen = 'RECUMX' 
                          AND AlmacenDestino IN ('IFMX', 'T1BMX')
                    ) AS i
                    JOIN invd AS d WITH (NOLOCK) ON i.ID = d.ID
                    JOIN art AS a WITH (NOLOCK) ON a.Articulo = d.Articulo
                    ORDER BY i.FechaEmision DESC, i.MovID DESC";
            
            $res = ejecutarConsultaConCache($conn, 'get_transferencias_sql', $sql, 90, $forzar);
            echo json_encode($res);
            break;

        // ==========================================
        // 3. CONSULTA DE OPERADORES / PERSONAL
        // ==========================================
        case 'get_operadores':
            $sql = "SELECT TOP 100 * FROM UsuariosIntranet";
            $res = dbSelect($conn, $sql);
            echo json_encode($res);
            break;

        default:
            echo json_encode([
                "success" => false,
                "error" => "Acción de consulta '" . htmlspecialchars($action) . "' no reconocida."
            ]);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "error" => "Error al ejecutar consulta: " . $e->getMessage()
    ]);
}

if ($conn && is_resource($conn)) {
    sqlsrv_close($conn);
}
?>
