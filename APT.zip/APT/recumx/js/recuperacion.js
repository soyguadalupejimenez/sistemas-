/**
 * js/recuperacion.js
 * Dashboard y Gestión de Recuperación (Almacén RECUMX) desde SQL Server (Conduit)
 * Dashboard interactivo con análisis Por Mes, Por Semana y Distribución por Tipo de Material
 */

let datosRecuperacionSQL = [];
let chartRecuArticulosInstance = null;
let chartRecuPesoInstance = null;
let cargandoRecuperacion = false;
let timestampUltimaCarga = 0;

// Estado del Dashboard RECUMX
let modoDashboardPeriodo = 'mes'; // 'mes' | 'semana'
let mesDashboardSeleccionado = '';
let semanaDashboardSeleccionada = '';

/**
 * Obtiene el año y mes actual en formato YYYY-MM
 */
function getDashMesActualStr() {
    const hoy = new Date();
    const yyyy = hoy.getFullYear();
    const mm = String(hoy.getMonth() + 1).padStart(2, '0');
    return `${yyyy}-${mm}`;
}

/**
 * Retorna el nombre legible del mes en español
 */
function getDashNombreMesLegible(mesStr) {
    if (!mesStr) return '';
    const partes = mesStr.split('-');
    if (partes.length < 2) return mesStr;
    const nombres = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    const idx = parseInt(partes[1], 10) - 1;
    return `${nombres[idx] || partes[1]} ${partes[0]}`;
}

/**
 * Determina el nombre limpio del Tipo de Material según código y descripción
 */
function obtenerNombreMaterial(item) {
    const art = String(item.Articulo || item.ARTICULO || '').trim().toUpperCase();
    const desc = String(item.Descripcion1 || item.DESCRIPCION1 || '').trim().toUpperCase();
    const fam = String(item.Familia || item.FAMILIA || '').trim().toUpperCase();
    const lin = String(item.Linea || item.LINEA || '').trim().toUpperCase();

    if (art.startsWith('TVSC') || art.startsWith('TZSC') || art.startsWith('TEMT') || art.startsWith('TACT') || art.startsWith('TCIMC') || art.startsWith('TA2T') || art.startsWith('TE2T') || art.startsWith('T316') || desc.includes('CONDUIT') || desc.includes('EMT') || desc.includes('IMC') || fam.includes('CONDUIT')) {
        return 'Conduit EMT / IMC';
    }
    if (art.startsWith('CURVA') || art.startsWith('CIMC') || art.startsWith('CNPV') || art.startsWith('COAL') || desc.includes('CURVA') || desc.includes('CODO') || desc.includes('COPLE') || desc.includes('CONECTOR') || (fam.includes('ACCESORIOS') && !art.startsWith('VARS'))) {
        return 'Curvos y Accesorios';
    }
    if (art.startsWith('TPTR') || desc.includes('RECTANGULAR') || desc.includes('PTR') || lin.includes('PTR')) {
        return 'PTR / Tubo Rectangular';
    }
    if (art.startsWith('TCUN') || art.startsWith('TICU') || desc.includes('CUADRADO')) {
        return 'Tubo Cuadrado Nacional';
    }
    if (art.startsWith('TC30') || art.startsWith('TC40') || art.startsWith('TA53') || art.startsWith('TL200') || art.startsWith('TULFM') || desc.includes('CED.') || desc.includes('CEDULA') || fam.includes('CONDUCCIÓN')) {
        return 'Cédula 30 / 40 / 80';
    }
    if (art.startsWith('TPVC') || art.startsWith('CNPV') || art.startsWith('CURVA90PVC') || desc.includes('PVC') || fam.includes('PVC')) {
        return 'Conduit PVC';
    }
    if (art.startsWith('UNIP') || desc.includes('UNICANAL') || fam.includes('UNICANAL')) {
        return 'Unicanal Perforado';
    }
    if (art.startsWith('VARS') || desc.includes('VARILLA')) {
        return 'Varillas Roscadas';
    }
    if (art.startsWith('LACI') || desc.includes('CINTA')) {
        return 'Cintas y Rollos';
    }
    if (art.startsWith('TCRA') || art.startsWith('COAL') || desc.includes('ALUM.') || fam.includes('ALUMINIO')) {
        return 'Aluminio';
    }
    return (item.Descripcion1 || item.Articulo || 'Otros Materiales').trim();
}

/**
 * Consulta los datos de Recuperación desde api.php (SQL Server AWS Conduit)
 * Con carga instantánea desde caché local (Stale-While-Revalidate)
 * @param {boolean} forzar - Si es true, ignora el caché y consulta a SQL Server directamente
 */
async function cargarRecuperacionSQL(forzar = false) {
    const ahora = Date.now();

    // 1. Carga instantánea desde memoria si está fresca
    if (!forzar && datosRecuperacionSQL.length > 0 && (ahora - timestampUltimaCarga) < 120000) {
        renderizarTablaRecuperacionSQL(datosRecuperacionSQL);
        actualizarDashboard();
        return;
    }

    // 2. Carga instantánea desde sessionStorage para inicio inmediato sin esperas
    if (!forzar && (!datosRecuperacionSQL || datosRecuperacionSQL.length === 0)) {
        try {
            const cacheGuardada = sessionStorage.getItem('siai_recuperacion_cache');
            if (cacheGuardada) {
                const parsed = JSON.parse(cacheGuardada);
                if (Array.isArray(parsed) && parsed.length > 0) {
                    datosRecuperacionSQL = parsed;
                    window.datosRecuperacionSQL = datosRecuperacionSQL;
                    aplicarFiltrosRecuperacion();
                    actualizarDashboard();
                }
            }
        } catch (e) {}
    }

    if (cargandoRecuperacion) return;
    cargandoRecuperacion = true;

    const tbody = document.getElementById('tbody-recu-sql');
    if (tbody && (!datosRecuperacionSQL || datosRecuperacionSQL.length === 0)) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:32px; color:#64748b; font-weight:600;">
            <div style="display:inline-block; font-size:1.1rem; margin-bottom:8px;">Cargando...</div><br>
            Consultando datos de Recuperación en SQL Server (Conduit - Almacén RECUMX)...
        </td></tr>`;
    }

    try {
        const url = 'api.php?action=get_recuperacion_sql' + (forzar ? '&forzar=1' : '');
        const response = await fetch(url, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        });

        const res = await response.json();

        if (res.success && Array.isArray(res.data)) {
            datosRecuperacionSQL = res.data;
            window.datosRecuperacionSQL = datosRecuperacionSQL;
            try {
                sessionStorage.setItem('siai_recuperacion_cache', JSON.stringify(datosRecuperacionSQL));
            } catch (e) {}
            aplicarFiltrosRecuperacion();
            actualizarDashboard();
        } else {
            console.error('[Recuperación SQL] Error en respuesta:', res.error);
            if (tbody) {
                tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:24px; color:#EA580C; font-weight:600;">
                    Error al consultar SQL Server: ${JSON.stringify(res.error || 'Sin datos')}
                </td></tr>`;
            }
        }
    } catch (err) {
        console.error('[Recuperación SQL] Excepción:', err);
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:24px; color:#EA580C; font-weight:600;">
                No se pudo conectar con api.php: ${err.message}
            </td></tr>`;
        }
    } finally {
        cargandoRecuperacion = false;
        timestampUltimaCarga = Date.now();
    }
}

/**
 * Recarga tanto el dashboard como las transferencias
 */
async function recargarDashboard(forzar = true) {
    if (window.cargarTransferenciasSQL) {
        await window.cargarTransferenciasSQL(forzar);
    }
    await cargarRecuperacionSQL(forzar);
    actualizarDashboard();
}

/**
 * Inicializa y llena los selectores de Mes y Semana para el Dashboard
 */
function inicializarSelectoresDashboard() {
    if (!mesDashboardSeleccionado) {
        mesDashboardSeleccionado = getDashMesActualStr();
    }

    const selMes = document.getElementById('dash-select-mes');
    if (selMes) {
        const meses = [
            { val: '2026-09', label: 'Septiembre 2026 (Actual)' },
            { val: '2026-08', label: 'Agosto 2026' },
            { val: '2026-07', label: 'Julio 2026' },
            { val: '2026-06', label: 'Junio 2026' },
            { val: '2026-05', label: 'Mayo 2026' },
            { val: '2026-04', label: 'Abril 2026' },
            { val: '2026-03', label: 'Marzo 2026' },
            { val: '2026-02', label: 'Febrero 2026' },
            { val: '2026-01', label: 'Enero 2026' }
        ];

        selMes.innerHTML = meses.map(m => `<option value="${m.val}" ${m.val === mesDashboardSeleccionado ? 'selected' : ''}>${m.label}</option>`).join('');
    }

    actualizarSemanasDisponibles();
}

/**
 * Actualiza las opciones del selector de semana según el mes activo
 */
function actualizarSemanasDisponibles() {
    const selSemana = document.getElementById('dash-select-semana');
    if (!selSemana) return;

    const mes = mesDashboardSeleccionado || getDashMesActualStr();
    const partes = mes.split('-');
    const yyyy = parseInt(partes[0], 10) || 2026;
    const mm = parseInt(partes[1], 10) || 9;
    const diasEnMes = new Date(yyyy, mm, 0).getDate();

    const semanas = [
        { val: `${mes}-W1`, start: `${mes}-01`, end: `${mes}-07`, label: `Semana 1 (01 al 07 de ${getDashNombreMesLegible(mes).split(' ')[0]})` },
        { val: `${mes}-W2`, start: `${mes}-08`, end: `${mes}-14`, label: `Semana 2 (08 al 14 de ${getDashNombreMesLegible(mes).split(' ')[0]})` },
        { val: `${mes}-W3`, start: `${mes}-15`, end: `${mes}-21`, label: `Semana 3 (15 al 21 de ${getDashNombreMesLegible(mes).split(' ')[0]})` },
        { val: `${mes}-W4`, start: `${mes}-22`, end: `${mes}-28`, label: `Semana 4 (22 al 28 de ${getDashNombreMesLegible(mes).split(' ')[0]})` },
        { val: `${mes}-W5`, start: `${mes}-29`, end: `${mes}-${String(diasEnMes).padStart(2, '0')}`, label: `Semana 5 (29 al ${diasEnMes} de ${getDashNombreMesLegible(mes).split(' ')[0]})` }
    ];

    if (!semanaDashboardSeleccionada || !semanas.some(s => s.val === semanaDashboardSeleccionada)) {
        semanaDashboardSeleccionada = semanas[0].val;
    }

    selSemana.innerHTML = semanas.map(s => `<option value="${s.val}" data-start="${s.start}" data-end="${s.end}" ${s.val === semanaDashboardSeleccionada ? 'selected' : ''}>${s.label}</option>`).join('');
}

// Estado de métricas del Dashboard RECUMX
let metricaGraficaDashboard = 'ton'; // 'ton' | 'pzas'

/**
 * Cambia la unidad de la Gráfica 1 del Dashboard (Toneladas vs Piezas)
 */
function setMetricaGraficaDashboard(metrica) {
    metricaGraficaDashboard = metrica;
    const btnTon = document.getElementById('btn-dash-metrica-ton');
    const btnPzas = document.getElementById('btn-dash-metrica-pzas');

    if (btnTon && btnPzas) {
        if (metrica === 'ton') {
            btnTon.style.background = '#EA580C';
            btnTon.style.borderColor = '#EA580C';
            btnTon.style.color = '#FFFFFF';
            btnTon.style.fontWeight = '700';

            btnPzas.style.background = '#FFF7ED';
            btnPzas.style.borderColor = '#FED7AA';
            btnPzas.style.color = '#C2410C';
            btnPzas.style.fontWeight = '600';
        } else {
            btnPzas.style.background = '#EA580C';
            btnPzas.style.borderColor = '#EA580C';
            btnPzas.style.color = '#FFFFFF';
            btnPzas.style.fontWeight = '700';

            btnTon.style.background = '#FFF7ED';
            btnTon.style.borderColor = '#FED7AA';
            btnTon.style.color = '#C2410C';
            btnTon.style.fontWeight = '600';
        }
    }

    actualizarDashboard();
}

/**
 * Actualiza los KPIs, Gráficas y Top Artículos del Dashboard basados en el STOCK DISPONIBLE de RECUMX
 */
function actualizarDashboard() {
    let dataset = window.datosRecuperacionSQL || [];
    
    // Si aún no está en memoria, cargar desde sessionStorage
    if (!dataset || dataset.length === 0) {
        try {
            const cacheRecu = sessionStorage.getItem('siai_recuperacion_cache');
            if (cacheRecu) {
                const parsed = JSON.parse(cacheRecu);
                if (Array.isArray(parsed) && parsed.length > 0) {
                    dataset = parsed;
                    window.datosRecuperacionSQL = dataset;
                }
            }
        } catch (e) {}
    }

    const selectMat = document.getElementById('dash-select-material');
    const materialFiltro = selectMat ? selectMat.value.trim() : '';

    // Filtrar dataset si se seleccionó un tipo de material específico
    let listaFiltrada = dataset;
    if (materialFiltro) {
        listaFiltrada = dataset.filter(item => obtenerNombreMaterial(item) === materialFiltro);
    }

    // 1. Textos informativos de resumen
    const labelResumen = document.getElementById('dash-filtro-resumen');
    const labelConteo = document.getElementById('dash-conteo-registros');
    const titleG1 = document.getElementById('dash-chart1-title');
    const titleG2 = document.getElementById('dash-chart2-title');

    if (labelResumen) {
        labelResumen.textContent = materialFiltro 
            ? `Inventario RECUMX — Filtro: ${materialFiltro}`
            : `Inventario Disponible en Almacén RECUMX`;
    }

    if (labelConteo) {
        labelConteo.textContent = `${listaFiltrada.length.toLocaleString('es-MX')} artículos en existencia`;
    }

    if (titleG1) {
        titleG1.textContent = metricaGraficaDashboard === 'ton'
            ? 'Existencias por Tipo de Material en RECUMX (Toneladas)'
            : 'Existencias por Tipo de Material en RECUMX (Piezas)';
    }

    if (titleG2) {
        titleG2.textContent = 'Distribución Porcentual de Stock (RECUMX)';
    }

    // 2. Calcular 4 KPIs de Stock en RECUMX
    const kpiArticulos = document.getElementById('kpi-recu-articulos');
    const kpiDisponible = document.getElementById('kpi-recu-disponible');
    const kpiTotalPeso = document.getElementById('kpi-recu-totalpeso');
    const kpiToneladas = document.getElementById('kpi-recu-toneladas');

    let totalPiezas = 0;
    let totalTons = 0;

    listaFiltrada.forEach(item => {
        const cant = parseFloat(item.Disponible || item.DISPONIBLE || item.Cantidad || 0) || 0;
        const tot = parseFloat(item.Total || item.TOTAL || 0) || 0;
        totalPiezas += cant;
        totalTons += tot;
    });

    const pesoKg = totalTons * 1000;

    if (kpiArticulos) kpiArticulos.textContent = listaFiltrada.length.toLocaleString('es-MX');
    if (kpiDisponible) kpiDisponible.textContent = totalPiezas.toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    if (kpiTotalPeso) kpiTotalPeso.textContent = pesoKg.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' kg';
    if (kpiToneladas) kpiToneladas.textContent = totalTons.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 3 }) + ' Ton';

    // 3. Renderizar Gráficas de Inventario RECUMX
    renderizarGraficasDashboardStock(dataset, listaFiltrada, metricaGraficaDashboard);

    // 4. Renderizar Top 5 Artículos con Mayor Stock
    renderizarTopArticulosRECUMX(listaFiltrada);
}

/**
 * Renderiza las dos gráficas de Chart.js con datos del inventario de RECUMX
 */
function renderizarGraficasDashboardStock(fullDataset, datasetFiltrado, metrica) {
    if (typeof Chart === 'undefined') return;

    // ══════════════════════════════════════════════════
    // GRÁFICA 1: BARRAS POR TIPO DE MATERIAL EN RECUMX
    // ══════════════════════════════════════════════════
    const canvasBar = document.getElementById('chart-recu-articulos');
    if (canvasBar) {
        if (chartRecuArticulosInstance) {
            chartRecuArticulosInstance.destroy();
        }

        const datosFuente = datasetFiltrado && datasetFiltrado.length > 0 ? datasetFiltrado : fullDataset;
        const categoriasMap = {};

        datosFuente.forEach(item => {
            const mat = obtenerNombreMaterial(item);
            const val = metrica === 'ton' 
                ? (parseFloat(item.Total || item.TOTAL || 0) || 0)
                : (parseFloat(item.Disponible || item.DISPONIBLE || item.Cantidad || 0) || 0);

            if (!categoriasMap[mat]) categoriasMap[mat] = 0;
            categoriasMap[mat] += val;
        });

        // Ordenar categorías de mayor a menor
        const sortedCats = Object.entries(categoriasMap).sort((a, b) => b[1] - a[1]);
        const labels = sortedCats.map(c => c[0]);
        const dataValores = sortedCats.map(c => c[1]);

        chartRecuArticulosInstance = new Chart(canvasBar, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: metrica === 'ton' ? 'Toneladas (Tn)' : 'Piezas Físicas',
                    data: dataValores,
                    backgroundColor: 'rgba(234, 88, 12, 0.85)',
                    borderColor: '#EA580C',
                    borderWidth: 1.5,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                if (metrica === 'ton') {
                                    return ` Existencia: ${context.parsed.y.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 3 })} Ton`;
                                }
                                return ` Existencia: ${context.parsed.y.toLocaleString('es-MX')} piezas`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { 
                            font: { family: 'Outfit, sans-serif', size: 10, weight: '600' }, 
                            color: '#475569',
                            maxRotation: 25,
                            minRotation: 0
                        }
                    },
                    y: {
                        grid: { color: '#FFF7ED' },
                        ticks: { 
                            font: { family: 'Outfit, sans-serif', size: 11 }, 
                            color: '#64748b',
                            callback: function(value) {
                                return value.toLocaleString('es-MX');
                            }
                        }
                    }
                }
            }
        });
    }

    // ══════════════════════════════════════════════════
    // GRÁFICA 2: DISTRIBUCIÓN PORCENTUAL (DOUGHNUT) RECUMX
    // ══════════════════════════════════════════════════
    const canvasDonut = document.getElementById('chart-recu-peso');
    if (canvasDonut) {
        if (chartRecuPesoInstance) {
            chartRecuPesoInstance.destroy();
        }

        const datosFuente = datasetFiltrado && datasetFiltrado.length > 0 ? datasetFiltrado : fullDataset;
        const materialesMap = {};

        datosFuente.forEach(item => {
            const mat = obtenerNombreMaterial(item);
            const total = parseFloat(item.Total || item.TOTAL || 0) || 0;
            if (!materialesMap[mat]) materialesMap[mat] = 0;
            materialesMap[mat] += total;
        });

        const sorted = Object.entries(materialesMap).sort((a, b) => b[1] - a[1]);
        const top5 = sorted.slice(0, 6);
        const resto = sorted.slice(6).reduce((acc, curr) => acc + curr[1], 0);

        let labelsDonut = top5.map(item => item[0]);
        let dataDonut = top5.map(item => item[1]);

        if (resto > 0) {
            labelsDonut.push('Otros Materiales');
            dataDonut.push(resto);
        }

        if (labelsDonut.length === 0) {
            labelsDonut = ['Sin inventario'];
            dataDonut = [0];
        }

        chartRecuPesoInstance = new Chart(canvasDonut, {
            type: 'doughnut',
            data: {
                labels: labelsDonut,
                datasets: [{
                    data: dataDonut,
                    backgroundColor: [
                        '#EA580C',
                        '#F97316',
                        '#FB923C',
                        '#FDBA74',
                        '#FED7AA',
                        '#C2410C',
                        '#9A3412'
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: { font: { family: 'Outfit, sans-serif', size: 10, weight: '600' }, boxWidth: 12, color: '#334155' }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const totalGeneral = dataDonut.reduce((a, b) => a + b, 0);
                                const pct = totalGeneral > 0 ? ((context.parsed / totalGeneral) * 100).toFixed(1) : 0;
                                return ` ${context.label}: ${context.parsed.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 3 })} Ton (${pct}%)`;
                            }
                        }
                    }
                },
                cutout: '65%'
            }
        });
    }
}

/**
 * Renderiza los 5 artículos con mayor stock disponible en RECUMX
 */
function renderizarTopArticulosRECUMX(lista) {
    const tbody = document.getElementById('tbody-top-recu');
    if (!tbody) return;

    if (!lista || lista.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:18px; color:#94A3B8;">No hay artículos disponibles.</td></tr>`;
        return;
    }

    // Ordenar de mayor a menor según el peso total en toneladas
    const ordenados = [...lista].sort((a, b) => {
        const tA = parseFloat(a.Total || a.TOTAL || 0) || 0;
        const tB = parseFloat(b.Total || b.TOTAL || 0) || 0;
        return tB - tA;
    });

    const top5 = ordenados.slice(0, 5);

    const filasHtml = top5.map((item, idx) => {
        const art = String(item.Articulo || '').trim();
        const desc = String(item.Descripcion1 || '').trim();
        const mat = obtenerNombreMaterial(item);
        const pzas = parseFloat(item.Disponible || item.DISPONIBLE || 0) || 0;
        const pesoUnit = parseFloat(item.Peso || item.PESO || 0) || 0;
        const tons = parseFloat(item.Total || item.TOTAL || 0) || 0;

        return `
        <tr style="border-bottom: 1px solid #FFEDD5; transition: background 0.15s ease;" onmouseover="this.style.background='#FFF7ED'" onmouseout="this.style.background='transparent'">
            <td style="padding: 10px 14px; font-weight: 700; color: #0F172A; white-space: nowrap;">
                <span style="display: inline-block; width: 20px; color: #EA580C; font-weight: 800;">${idx + 1}.</span>
                <span class="badge badge-recu" style="background:#FFF7ED; color:#EA580C; border:1px solid #FED7AA; padding:2px 8px; border-radius:6px; font-weight:700;">${art}</span>
            </td>
            <td style="padding: 10px 14px; color: #334155; font-weight: 500; max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${desc}">
                ${desc}
            </td>
            <td style="padding: 10px 14px; white-space: nowrap;">
                <span style="background: #F8FAFC; color: #475569; padding: 3px 8px; border-radius: 6px; font-size: 0.8rem; font-weight: 600; border: 1px solid #E2E8F0;">${mat}</span>
            </td>
            <td style="padding: 10px 14px; text-align: right; font-weight: 700; color: #0F172A; white-space: nowrap;">
                ${pzas.toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
            </td>
            <td style="padding: 10px 14px; text-align: right; color: #64748B; font-size: 0.85rem; white-space: nowrap;">
                ${pesoUnit.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 4 })} kg
            </td>
            <td style="padding: 10px 14px; text-align: right; font-weight: 800; color: #EA580C; font-size: 0.95rem; white-space: nowrap;">
                ${tons.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 3 })} Ton
            </td>
        </tr>`;
    }).join('');

    tbody.innerHTML = filasHtml;
}

/**
 * Renderiza los registros en la tabla detallada de Recuperación
 */
function renderizarTablaRecuperacionSQL(lista) {
    const tbody = document.getElementById('tbody-recu-sql');
    if (!tbody) return;

    if (!lista || lista.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:28px; color:#64748b; font-size:0.95rem;">
            No se encontraron artículos disponibles con los criterios de búsqueda.
        </td></tr>`;
        return;
    }

    let sumaDisponible = 0;
    let sumaTotal = 0;

    const filasHtml = lista.map((item) => {
        const disponible = parseFloat(item.Disponible) || 0;
        const peso = parseFloat(item.Peso) || 0;
        const total = parseFloat(item.Total) || ((disponible * peso) / 1000);

        sumaDisponible += disponible;
        sumaTotal += total;

        return `
        <tr style="border-bottom: 1px solid #FED7AA; transition: background 0.15s;">
            <td style="padding: 10px 14px; text-align: center;"><span style="background: #FFEDD5; color: #9A3412; padding: 3px 8px; border-radius: 6px; font-weight: 700; font-size: 0.8rem; border: 1px solid #FDBA74;">${item.Almacen || 'RECUMX'}</span></td>
            <td style="padding: 10px 14px; font-weight: 700; color: #EA580C; font-size: 0.92rem;">${(item.Articulo || '-').trim()}</td>
            <td style="padding: 10px 14px; color: var(--text-main); font-size: 0.9rem;">${(item.Descripcion1 || '-').trim()}</td>
            <td style="padding: 10px 14px; text-align: center; color: var(--text-muted); font-size: 0.85rem; font-weight: 600;">${(item.Unidad || '-').trim()}</td>
            <td style="padding: 10px 14px; text-align: right; font-weight: 700; color: #EA580C; font-size: 0.95rem;">${disponible.toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</td>
            <td style="padding: 10px 14px; text-align: right; font-weight: 800; color: #EA580C; font-size: 0.95rem;">${total.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 4 })}</td>
        </tr>`;
    }).join('');

    // Fila de totales en el pie de tabla
    const filaTotales = `
    <tr style="background: #FFF7ED; color: #9A3412; font-weight: 800; border-top: 2px solid #EA580C;">
        <td colspan="4" style="padding: 12px 14px; text-align: right; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 0.05em; color: #9A3412;">TOTALES ACUMULADOS:</td>
        <td style="padding: 12px 14px; text-align: right; color: #EA580C; font-size: 1.05rem;">${sumaDisponible.toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</td>
        <td style="padding: 12px 14px; text-align: right; color: #EA580C; font-size: 1.05rem;">${sumaTotal.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 4 })}</td>
    </tr>`;

    tbody.innerHTML = filasHtml + filaTotales;
}

// Estado de filtros en Recuperación
let filtroMaterialActivo = 'todos';
let filtroStockActivo = 'todos';
let textoBusquedaActivo = '';
let listaFiltradaActual = [];

/**
 * Determina si un artículo pertenece a la categoría seleccionada
 */
function coincideConFiltroMaterial(item, filtro) {
    if (!filtro || filtro === 'todos') return true;

    const art = String(item.Articulo || '').trim().toUpperCase();
    const desc = String(item.Descripcion1 || '').trim().toUpperCase();
    const fam = String(item.Familia || '').trim().toUpperCase();
    const grp = String(item.Grupo || '').trim().toUpperCase();
    const lin = String(item.Linea || '').trim().toUpperCase();

    switch (filtro.toLowerCase()) {
        case 'curvos':
        case 'curvas':
        case 'accesorios':
            return (
                art.startsWith('CURVA') ||
                art.startsWith('CIMC') ||
                art.startsWith('CNPV') ||
                art.startsWith('COAL') ||
                desc.includes('CURVA') ||
                desc.includes('CODO') ||
                desc.includes('COPLE') ||
                desc.includes('CONECTOR') ||
                (fam.includes('ACCESORIOS') && !art.startsWith('VARS'))
            );

        case 'conduit':
            return (
                art.startsWith('TVSC') ||
                art.startsWith('TZSC') ||
                art.startsWith('TEMT') ||
                art.startsWith('TACT') ||
                art.startsWith('TCIMC') ||
                art.startsWith('TA2T') ||
                art.startsWith('TE2T') ||
                art.startsWith('T316') ||
                desc.includes('CONDUIT') ||
                desc.includes('EMT') ||
                desc.includes('IMC') ||
                fam.includes('CONDUIT')
            );

        case 'ptr':
        case 'rectangular':
            return (
                art.startsWith('TPTR') ||
                desc.includes('RECTANGULAR') ||
                desc.includes('PTR') ||
                lin.includes('PTR')
            );

        case 'cuadrado':
        case 'cuadrados':
            return (
                art.startsWith('TCUN') ||
                art.startsWith('TICU') ||
                desc.includes('CUADRADO')
            );

        case 'cedula':
        case 'conduccion':
            return (
                art.startsWith('TC30') ||
                art.startsWith('TC40') ||
                art.startsWith('TA53') ||
                art.startsWith('TL200') ||
                art.startsWith('TULFM') ||
                desc.includes('CED.') ||
                desc.includes('CEDULA') ||
                fam.includes('CONDUCCIÓN')
            );

        case 'pvc':
            return (
                art.startsWith('TPVC') ||
                art.startsWith('CNPV') ||
                art.startsWith('CURVA90PVC') ||
                desc.includes('PVC') ||
                fam.includes('PVC') ||
                grp.includes('PVC')
            );

        case 'unicanal':
            return (
                art.startsWith('UNIP') ||
                desc.includes('UNICANAL') ||
                fam.includes('UNICANAL')
            );

        case 'varillas':
        case 'varilla':
            return (
                art.startsWith('VARS') ||
                desc.includes('VARILLA') ||
                grp.includes('VARILLA')
            );

        case 'cintas':
        case 'cinta':
            return (
                art.startsWith('LACI') ||
                desc.includes('CINTA')
            );

        default:
            const fUpper = filtro.toUpperCase();
            return art.startsWith(fUpper) || art.includes(fUpper) || desc.includes(fUpper);
    }
}

/**
 * Aplica los filtros combinados en Recuperación
 */
function aplicarFiltrosRecuperacion() {
    if (!datosRecuperacionSQL || datosRecuperacionSQL.length === 0) {
        renderizarTablaRecuperacionSQL([]);
        return;
    }

    const texto = (textoBusquedaActivo || '').toLowerCase().trim();

    listaFiltradaActual = datosRecuperacionSQL.filter(item => {
        if (!coincideConFiltroMaterial(item, filtroMaterialActivo)) return false;

        const disp = parseFloat(item.Disponible) || 0;
        if (filtroStockActivo === 'con_stock' && disp <= 0) return false;
        if (filtroStockActivo === 'sin_stock' && disp > 0) return false;

        if (texto) {
            const art = String(item.Articulo || '').toLowerCase();
            const desc = String(item.Descripcion1 || '').toLowerCase();
            const alm = String(item.Almacen || '').toLowerCase();
            const uni = String(item.Unidad || '').toLowerCase();
            if (!art.includes(texto) && !desc.includes(texto) && !alm.includes(texto) && !uni.includes(texto)) {
                return false;
            }
        }

        return true;
    });

    renderizarTablaRecuperacionSQL(listaFiltradaActual);
}

/**
 * Selecciona una categoría para filtrar en Recuperación
 */
function seleccionarFiltro(tipo) {
    if (typeof seleccionarOpcion === 'function') {
        seleccionarOpcion('recuperacion');
    }
    filtroMaterialActivo = tipo || 'todos';
    aplicarFiltrosRecuperacion();
}

/**
 * Filtra por texto en Recuperación
 */
function filtrarRecuperacionSQL() {
    const input = document.getElementById('recu-sql-search');
    textoBusquedaActivo = input ? input.value.trim() : '';
    aplicarFiltrosRecuperacion();
}

/**
 * Exporta Recuperación a Excel
 */
function exportarRecuperacionExcel() {
    const datosAExportar = (listaFiltradaActual && listaFiltradaActual.length > 0) ? listaFiltradaActual : datosRecuperacionSQL;

    if (!datosAExportar || datosAExportar.length === 0) {
        alert('No hay datos para exportar con el filtro actual.');
        return;
    }

    if (typeof XLSX === 'undefined') {
        alert('La librería XLSX no está disponible.');
        return;
    }

    const dataExcel = datosAExportar.map((r, i) => {
        const disp = parseFloat(r.Disponible) || 0;
        const peso = parseFloat(r.Peso) || 0;
        const total = parseFloat(r.Total) || ((disp * peso) / 1000);
        return {
            '#': i + 1,
            'Almacén': r.Almacen || 'RECUMX',
            'Artículo': (r.Articulo || '').trim(),
            'Descripción': (r.Descripcion1 || '').trim(),
            'Unidad': (r.Unidad || '').trim(),
            'Disponible': disp,
            'Peso (Kg)': peso,
            'Total Peso (Kg)': total,
            'Familia': (r.Familia || '').trim(),
            'Grupo': (r.Grupo || '').trim()
        };
    });

    const ws = XLSX.utils.json_to_sheet(dataExcel);
    const wb = XLSX.utils.book_new();
    const sufijoFiltro = filtroMaterialActivo !== 'todos' ? `_${filtroMaterialActivo}` : '';
    XLSX.utils.book_append_sheet(wb, ws, 'Recuperacion_RECUMX');
    XLSX.writeFile(wb, `Recuperacion_RECUMX${sufijoFiltro}_${new Date().toISOString().split('T')[0]}.xlsx`);
}

// Inicialización de eventos al cargar el DOM
document.addEventListener('DOMContentLoaded', () => {
    // 1. Inicializar selectores del Dashboard RECUMX
    inicializarSelectoresDashboard();
    actualizarEstilosModoDashboard();

    // 2. Botones de Modo Dashboard (Por Mes / Por Semana)
    const btnDashMes = document.getElementById('btn-dash-modo-mes');
    if (btnDashMes) {
        btnDashMes.addEventListener('click', setDashboardModoMes);
    }

    const btnDashSemana = document.getElementById('btn-dash-modo-semana');
    if (btnDashSemana) {
        btnDashSemana.addEventListener('click', setDashboardModoSemana);
    }

    // 3. Selectores de cambio de mes y semana
    const selMes = document.getElementById('dash-select-mes');
    if (selMes) {
        selMes.addEventListener('change', (e) => {
            mesDashboardSeleccionado = e.target.value;
            actualizarSemanasDisponibles();
            actualizarDashboard();
        });
    }

    const selSemana = document.getElementById('dash-select-semana');
    if (selSemana) {
        selSemana.addEventListener('change', (e) => {
            semanaDashboardSeleccionada = e.target.value;
            actualizarDashboard();
        });
    }

    // 4. Buscador en tiempo real de Recuperación
    const inputSearch = document.getElementById('recu-sql-search');
    if (inputSearch) {
        inputSearch.addEventListener('input', filtrarRecuperacionSQL);
    }

    // 5. Botones de Recuperación
    const btnRefrescar = document.getElementById('btn-recu-sql-refresh');
    if (btnRefrescar) {
        btnRefrescar.addEventListener('click', () => cargarRecuperacionSQL(true));
    }

    const btnExportar = document.getElementById('btn-recu-sql-export');
    if (btnExportar) {
        btnExportar.addEventListener('click', exportarRecuperacionExcel);
    }

    // 6. Carga inicial
    cargarRecuperacionSQL();
    if (window.cargarTransferenciasSQL) {
        window.cargarTransferenciasSQL();
    }
});

// Exportaciones globales
window.cargarRecuperacionSQL = cargarRecuperacionSQL;
window.exportarRecuperacionExcel = exportarRecuperacionExcel;
window.seleccionarFiltro = seleccionarFiltro;
window.aplicarFiltrosRecuperacion = aplicarFiltrosRecuperacion;
window.actualizarDashboard = actualizarDashboard;
window.recargarDashboard = recargarDashboard;
window.setMetricaGraficaDashboard = setMetricaGraficaDashboard;
window.obtenerNombreMaterial = obtenerNombreMaterial;