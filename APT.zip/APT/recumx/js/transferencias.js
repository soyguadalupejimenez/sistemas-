/**
 * js/transferencias.js
 * Módulo de Transferencias de Recuperación (RECUMX -> IFMX / T1BMX)
 * Por defecto SIEMPRE muestra los movimientos del MES ACTUAL al ingresar.
 * Consulta en tiempo real: Inv + InvD + Art (Solo lectura SQL Server Conduit)
 */

let datosTransferenciasSQL = [];
let listaTransferenciasFiltrada = [];
let cargandoTransferencias = false;
let timestampUltimaCargaTransf = 0;

// Estado de filtros (Por defecto SIEMPRE 'mes' = Mes Actual)
let modoFiltroPeriodo = 'mes'; // 'mes' | 'hoy' | 'dia'
let filtroDiaActivo = '';
let filtroMesActivo = '';
let textoBusquedaTransfActivo = '';

/**
 * Obtiene el año y mes actual en formato YYYY-MM
 */
function getMesActualStr() {
    const hoy = new Date();
    const yyyy = hoy.getFullYear();
    const mm = String(hoy.getMonth() + 1).padStart(2, '0');
    return `${yyyy}-${mm}`;
}

/**
 * Obtiene la fecha de hoy en formato YYYY-MM-DD
 */
function getFechaHoyStr() {
    const hoy = new Date();
    const yyyy = hoy.getFullYear();
    const mm = String(hoy.getMonth() + 1).padStart(2, '0');
    const dd = String(hoy.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
}

/**
 * Retorna el nombre legible del mes en español
 */
function getNombreMesLegible(mesStr) {
    if (!mesStr) return '';
    const partes = mesStr.split('-');
    if (partes.length < 2) return mesStr;
    const nombres = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    const idx = parseInt(partes[1], 10) - 1;
    return `${nombres[idx] || partes[1]} ${partes[0]}`;
}

/**
 * Normaliza las propiedades de cada registro sin importar mayúsculas o minúsculas
 */
function normalizarItemTransferencia(raw) {
    const cantidad = parseFloat(raw.Cantidad ?? raw.CANTIDAD ?? raw.cantidad ?? 0) || 0;
    const peso = parseFloat(raw.Peso ?? raw.PESO ?? raw.peso ?? 0) || 0;
    const totalCalc = (cantidad * peso) / 1000.0;
    const total = parseFloat(raw.Total ?? raw.TOTAL ?? raw.total ?? totalCalc) || totalCalc;

    // Normalizar fecha a formato YYYY-MM-DD
    let fecha = String(raw.FechaEmision ?? raw.FECHAEMISION ?? raw.fechaemision ?? raw.Fecha ?? '-').trim();
    if (fecha.length > 10) {
        fecha = fecha.substring(0, 10);
    }

    return {
        MovID: String(raw.MovID ?? raw.MOVID ?? raw.movid ?? '-').trim(),
        FechaEmision: fecha,
        Concepto: String(raw.Concepto ?? raw.CONCEPTO ?? raw.concepto ?? '-').trim(),
        Usuario: String(raw.Usuario ?? raw.USUARIO ?? raw.usuario ?? '-').trim(),
        Referencia: String(raw.Referencia ?? raw.REFERENCIA ?? raw.referencia ?? '').trim(),
        Almacen: String(raw.Almacen ?? raw.ALMACEN ?? raw.almacen ?? 'RECUMX').trim(),
        AlmacenDestino: String(raw.AlmacenDestino ?? raw.ALMACENDESTINO ?? raw.almacendestino ?? '-').trim(),
        Articulo: String(raw.Articulo ?? raw.ARTICULO ?? raw.articulo ?? '-').trim(),
        Descripcion1: String(raw.Descripcion1 ?? raw.DESCRIPCION1 ?? raw.descripcion1 ?? raw.Descripcion ?? '-').trim(),
        Unidad: String(raw.Unidad ?? raw.UNIDAD ?? raw.unidad ?? 'PZA').trim(),
        Cantidad: cantidad,
        Peso: peso,
        Total: total
    };
}

/**
 * Consulta los datos de Transferencias desde api.php
 * Con inicio instantáneo desde caché local (Stale-While-Revalidate)
 * @param {boolean} forzar - Si es true, ignora caché y consulta SQL Server
 */
async function cargarTransferenciasSQL(forzar = false) {
    const ahora = Date.now();

    // Asegurar que el mes activo siempre esté fijado al mes actual por defecto
    if (!filtroMesActivo) {
        filtroMesActivo = getMesActualStr();
    }

    // 1. Carga instantánea desde memoria
    if (!forzar && datosTransferenciasSQL.length > 0 && (ahora - timestampUltimaCargaTransf) < 120000) {
        aplicarFiltrosTransferencias();
        return;
    }

    // 2. Carga instantánea desde sessionStorage
    if (!forzar && (!datosTransferenciasSQL || datosTransferenciasSQL.length === 0)) {
        try {
            const cacheTransf = sessionStorage.getItem('siai_transf_cache');
            if (cacheTransf) {
                const parsed = JSON.parse(cacheTransf);
                if (Array.isArray(parsed) && parsed.length > 0) {
                    datosTransferenciasSQL = parsed;
                    window.datosTransferenciasSQL = datosTransferenciasSQL;
                    aplicarFiltrosTransferencias();
                }
            }
        } catch (e) {}
    }

    if (cargandoTransferencias) return;
    cargandoTransferencias = true;

    const tbody = document.getElementById('tbody-transf-sql');
    if (tbody && (!datosTransferenciasSQL || datosTransferenciasSQL.length === 0)) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:32px; color:#64748B; font-weight:600;">
            <div style="display:inline-block; font-size:1.1rem; margin-bottom:8px;">Cargando...</div><br>
            Consultando transferencias de Recuperación en SQL Server (Conduit)...
        </td></tr>`;
    }

    try {
        const url = 'api.php?action=get_transferencias_sql' + (forzar ? '&forzar=1' : '');
        const response = await fetch(url, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const res = await response.json();

        if (res.success && Array.isArray(res.data)) {
            datosTransferenciasSQL = res.data.map(normalizarItemTransferencia);
            window.datosTransferenciasSQL = datosTransferenciasSQL;
            try {
                sessionStorage.setItem('siai_transf_cache', JSON.stringify(datosTransferenciasSQL));
            } catch (e) {}
            aplicarFiltrosTransferencias();
            if (window.actualizarDashboard) {
                window.actualizarDashboard();
            }
        } else {
            console.error('[Transferencias SQL] Error en respuesta:', res.error);
            if (tbody) {
                tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:24px; color:#EA580C; font-weight:600;">
                    Error al consultar transferencias en SQL Server: ${JSON.stringify(res.error || 'Sin datos')}
                </td></tr>`;
            }
        }
    } catch (err) {
        console.error('[Transferencias SQL] Excepción:', err);
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:24px; color:#EA580C; font-weight:600;">
                No se pudo conectar con el servidor: ${err.message}
            </td></tr>`;
        }
    } finally {
        cargandoTransferencias = false;
        timestampUltimaCargaTransf = Date.now();
    }
}

/**
 * Actualiza los estilos visuales de los botones de filtro de período
 */
function actualizarEstilosBotonesPeriodo() {
    const btnMes = document.getElementById('btn-transf-este-mes');
    const btnHoy = document.getElementById('btn-transf-hoy');

    const estiloActivo = {
        background: '#EA580C',
        borderColor: '#EA580C',
        color: '#FFFFFF',
        fontWeight: '700'
    };

    const estiloInactivo = {
        background: '#FFF7ED',
        borderColor: '#FED7AA',
        color: '#C2410C',
        fontWeight: '600'
    };

    function aplicarEstilo(btn, activo) {
        if (!btn) return;
        if (activo) {
            btn.style.background = estiloActivo.background;
            btn.style.borderColor = estiloActivo.borderColor;
            btn.style.color = estiloActivo.color;
            btn.style.fontWeight = estiloActivo.fontWeight;
        } else {
            btn.style.background = estiloInactivo.background;
            btn.style.borderColor = estiloInactivo.borderColor;
            btn.style.color = estiloInactivo.color;
            btn.style.fontWeight = estiloInactivo.fontWeight;
        }
    }

    aplicarEstilo(btnMes, modoFiltroPeriodo === 'mes');
    aplicarEstilo(btnHoy, modoFiltroPeriodo === 'hoy');
}

/**
 * Cambia al modo "Este Mes" (Por defecto)
 */
function seleccionarModoEsteMes() {
    modoFiltroPeriodo = 'mes';
    filtroMesActivo = getMesActualStr();
    filtroDiaActivo = '';

    const inputDia = document.getElementById('transf-filter-dia');
    if (inputDia) inputDia.value = '';

    actualizarEstilosBotonesPeriodo();
    aplicarFiltrosTransferencias();
}

/**
 * Cambia al modo "Hoy"
 */
function seleccionarModoHoy() {
    modoFiltroPeriodo = 'hoy';
    filtroDiaActivo = getFechaHoyStr();

    const inputDia = document.getElementById('transf-filter-dia');
    if (inputDia) inputDia.value = filtroDiaActivo;

    actualizarEstilosBotonesPeriodo();
    aplicarFiltrosTransferencias();
}

/**
 * Se activa cuando el usuario elige manualmente una fecha en el input date
 */
function onCambioInputDia() {
    const inputDia = document.getElementById('transf-filter-dia');
    const valor = inputDia ? inputDia.value.trim() : '';

    if (valor) {
        modoFiltroPeriodo = 'dia';
        filtroDiaActivo = valor;
    } else {
        // Si borra la fecha, vuelve automáticamente a mostrar el mes actual
        modoFiltroPeriodo = 'mes';
        filtroMesActivo = getMesActualStr();
        filtroDiaActivo = '';
    }

    actualizarEstilosBotonesPeriodo();
    aplicarFiltrosTransferencias();
}

/**
 * Aplica los filtros activos: Período/Fecha y Buscador de Texto
 */
function aplicarFiltrosTransferencias() {
    if (!datosTransferenciasSQL || datosTransferenciasSQL.length === 0) {
        renderizarTablaTransferenciasSQL([]);
        actualizarKpisTransferencias([]);
        actualizarResumenFiltro(0, 0);
        return;
    }

    const inputSearch = document.getElementById('transf-sql-search');
    textoBusquedaTransfActivo = inputSearch ? inputSearch.value.toLowerCase().trim() : '';

    if (!filtroMesActivo) {
        filtroMesActivo = getMesActualStr();
    }

    const hoyStr = getFechaHoyStr();

    listaTransferenciasFiltrada = datosTransferenciasSQL.filter(item => {
        const fecha = item.FechaEmision; // Formato YYYY-MM-DD

        // 1. Filtro de Fecha / Período
        if (modoFiltroPeriodo === 'mes') {
            if (!fecha.startsWith(filtroMesActivo)) {
                return false;
            }
        } else if (modoFiltroPeriodo === 'hoy') {
            if (!fecha.startsWith(hoyStr)) {
                return false;
            }
        } else if (modoFiltroPeriodo === 'dia') {
            if (filtroDiaActivo && !fecha.startsWith(filtroDiaActivo)) {
                return false;
            }
        }

        // 2. Filtro de Búsqueda de Texto
        if (textoBusquedaTransfActivo) {
            const m = item.MovID.toLowerCase();
            const a = item.Articulo.toLowerCase();
            const d = item.Descripcion1.toLowerCase();
            const dest = item.AlmacenDestino.toLowerCase();
            const u = item.Usuario.toLowerCase();
            const f = item.FechaEmision.toLowerCase();
            const ref = item.Referencia.toLowerCase();
            if (!m.includes(textoBusquedaTransfActivo) && 
                !a.includes(textoBusquedaTransfActivo) && 
                !d.includes(textoBusquedaTransfActivo) && 
                !dest.includes(textoBusquedaTransfActivo) && 
                !u.includes(textoBusquedaTransfActivo) && 
                !f.includes(textoBusquedaTransfActivo) && 
                !ref.includes(textoBusquedaTransfActivo)) {
                return false;
            }
        }

        return true;
    });

    renderizarTablaTransferenciasSQL(listaTransferenciasFiltrada);
    actualizarKpisTransferencias(listaTransferenciasFiltrada);
    actualizarResumenFiltro(listaTransferenciasFiltrada.length, datosTransferenciasSQL.length);
}

/**
 * Actualiza la etiqueta de resumen del filtro activo
 */
function actualizarResumenFiltro(filtrados, total) {
    const labelResumen = document.getElementById('transf-filtro-resumen');
    const labelConteo = document.getElementById('transf-conteo-registros');

    if (labelResumen) {
        if (modoFiltroPeriodo === 'mes') {
            const nombreMes = getNombreMesLegible(filtroMesActivo || getMesActualStr());
            labelResumen.textContent = `Mostrando transferencias de ${nombreMes} (Este Mes)`;
        } else if (modoFiltroPeriodo === 'hoy') {
            labelResumen.textContent = `Mostrando transferencias de Hoy (${getFechaHoyStr()})`;
        } else if (modoFiltroPeriodo === 'dia') {
            labelResumen.textContent = `Filtrando por día: ${filtroDiaActivo}`;
        }
    }

    if (labelConteo) {
        labelConteo.textContent = `${filtrados.toLocaleString('es-MX')} de ${total.toLocaleString('es-MX')} movimientos encontrados`;
    }
}

/**
 * Renderiza los registros en la tabla de transferencias (Sin Unidad ni Total, con Ruta alineada horizontalmente)
 */
function renderizarTablaTransferenciasSQL(lista) {
    const tbody = document.getElementById('tbody-transf-sql');
    if (!tbody) return;

    if (!lista || lista.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:28px; color:#64748B; font-size:0.95rem;">
            No se encontraron transferencias para el período o criterio seleccionado.
        </td></tr>`;
        return;
    }

    const filasHtml = lista.map((item) => {
        return `
        <tr style="border-bottom: 1px solid #FED7AA; transition: background 0.15s;">
            <td style="padding: 10px 14px; font-weight: 700; color: #EA580C; font-size: 0.88rem; white-space: nowrap;">${item.MovID}</td>
            <td style="padding: 10px 14px; text-align: center; color: #475569; font-size: 0.85rem; font-weight: 600; white-space: nowrap;">${item.FechaEmision}</td>
            <td style="padding: 10px 14px; text-align: center; white-space: nowrap;">
                <div style="display: inline-flex; align-items: center; justify-content: center; gap: 6px; white-space: nowrap;">
                    <span style="background: #FFF7ED; color: #C2410C; padding: 3px 8px; border-radius: 6px; font-weight: 700; font-size: 0.8rem; border: 1px solid #FED7AA; letter-spacing: 0.3px;">${item.Almacen}</span>
                    <span style="color: #EA580C; font-size: 0.95rem; font-weight: 800; line-height: 1;">&rarr;</span>
                    <span style="background: #FFEDD5; color: #9A3412; padding: 3px 8px; border-radius: 6px; font-weight: 800; font-size: 0.8rem; border: 1px solid #FDBA74; letter-spacing: 0.3px;">${item.AlmacenDestino}</span>
                </div>
            </td>
            <td style="padding: 10px 14px; font-weight: 700; color: #0F172A; font-size: 0.9rem; white-space: nowrap;">${item.Articulo}</td>
            <td style="padding: 10px 14px; color: #334155; font-size: 0.88rem;">${item.Descripcion1}</td>
            <td style="padding: 10px 14px; text-align: right; font-weight: 700; color: #EA580C; font-size: 0.92rem; white-space: nowrap;">${item.Cantidad.toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</td>
            <td style="padding: 10px 14px; text-align: center; color: #64748B; font-size: 0.82rem; white-space: nowrap;">${item.Usuario}</td>
        </tr>`;
    }).join('');

    tbody.innerHTML = filasHtml;
}

/**
 * Actualiza las tarjetas KPI con los totales del período filtrado
 */
function actualizarKpisTransferencias(lista) {
    const kpiMovimientos = document.getElementById('kpi-transf-movimientos');
    const kpiCantidad = document.getElementById('kpi-transf-cantidad');
    const kpiTotalPeso = document.getElementById('kpi-transf-totalpeso');

    let totalCantidad = 0;
    let totalPeso = 0;

    lista.forEach(item => {
        totalCantidad += item.Cantidad;
        totalPeso += item.Total;
    });

    if (kpiMovimientos) kpiMovimientos.textContent = lista.length.toLocaleString('es-MX');
    if (kpiCantidad) kpiCantidad.textContent = totalCantidad.toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    if (kpiTotalPeso) kpiTotalPeso.textContent = totalPeso.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 3 }) + ' Ton';
}

/**
 * Exporta las transferencias a Excel (.xlsx) considerando los filtros activos
 */
function exportarTransferenciasExcel() {
    const datos = (listaTransferenciasFiltrada && listaTransferenciasFiltrada.length > 0) ? listaTransferenciasFiltrada : datosTransferenciasSQL;

    if (!datos || datos.length === 0) {
        alert('No hay movimientos de transferencia para exportar.');
        return;
    }

    if (typeof XLSX === 'undefined') {
        alert('La librería XLSX no está disponible.');
        return;
    }

    const dataExcel = datos.map((r) => {
        return {
            'Folio': r.MovID,
            'Fecha Emisión': r.FechaEmision,
            'Concepto': r.Concepto,
            'Origen': r.Almacen,
            'Destino': r.AlmacenDestino,
            'Artículo': r.Articulo,
            'Descripción': r.Descripcion1,
            'Cantidad': r.Cantidad,
            'Usuario': r.Usuario,
            'Referencia': r.Referencia
        };
    });

    const ws = XLSX.utils.json_to_sheet(dataExcel);
    const wb = XLSX.utils.book_new();
    
    let sufijo = '';
    if (modoFiltroPeriodo === 'mes') sufijo = `_${filtroMesActivo}`;
    else if (modoFiltroPeriodo === 'dia' || modoFiltroPeriodo === 'hoy') sufijo = `_${filtroDiaActivo}`;

    XLSX.utils.book_append_sheet(wb, ws, 'Transferencias_RECUMX');
    XLSX.writeFile(wb, `Transferencias_RECUMX${sufijo}_${new Date().toISOString().split('T')[0]}.xlsx`);
}

// Inicialización de eventos al cargar el DOM
document.addEventListener('DOMContentLoaded', () => {
    // 1. Inicializar fecha y mes por defecto
    filtroMesActivo = getMesActualStr();
    modoFiltroPeriodo = 'mes';
    actualizarEstilosBotonesPeriodo();

    // 2. Botón Este Mes
    const btnEsteMes = document.getElementById('btn-transf-este-mes');
    if (btnEsteMes) {
        btnEsteMes.addEventListener('click', seleccionarModoEsteMes);
    }

    // 3. Botón Hoy
    const btnHoy = document.getElementById('btn-transf-hoy');
    if (btnHoy) {
        btnHoy.addEventListener('click', seleccionarModoHoy);
    }

    // 4. Selector de Día
    const inputDia = document.getElementById('transf-filter-dia');
    if (inputDia) {
        inputDia.addEventListener('change', onCambioInputDia);
        inputDia.addEventListener('input', onCambioInputDia);
    }

    // 5. Buscador en tiempo real
    const inputSearch = document.getElementById('transf-sql-search');
    if (inputSearch) {
        inputSearch.addEventListener('input', aplicarFiltrosTransferencias);
    }

    // 6. Botones superiores
    const btnRefresh = document.getElementById('btn-transf-sql-refresh');
    if (btnRefresh) {
        btnRefresh.addEventListener('click', () => cargarTransferenciasSQL(true));
    }

    const btnExport = document.getElementById('btn-transf-sql-export');
    if (btnExport) {
        btnExport.addEventListener('click', exportarTransferenciasExcel);
    }
});

// Exportaciones globales
window.cargarTransferenciasSQL = cargarTransferenciasSQL;
window.exportarTransferenciasExcel = exportarTransferenciasExcel;
window.aplicarFiltrosTransferencias = aplicarFiltrosTransferencias;
window.seleccionarModoEsteMes = seleccionarModoEsteMes;
window.seleccionarModoHoy = seleccionarModoHoy;
