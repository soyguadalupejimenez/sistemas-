<?php
/**
 * conexion.php
 * Conexión centralizada a Microsoft SQL Server (Intelisis / Conduit)
 * Compatible con sqlsrv_connect y con ODBC Driver 17 for SQL Server
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Cabeceras CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

/**
 * Conecta a Intelisis / Conduit en SQL Server
 * Con detección ultrarrápida y memoria de servidor activo
 * @return array ['tipo' => 'sqlsrv'|'odbc', 'conn' => resource]
 */
function ConectadoAIntelisisAWS2()
{
    static $conexionGlobal = null;
    if ($conexionGlobal !== null) {
        return $conexionGlobal;
    }

    $dbName = "Conduit";
    if (isset($_GET["ModoPruebas"]) && $_GET["ModoPruebas"] == "Si") {
        $dbName = "ConduitPruebas2";
    }

    // Servidores ordenados por probabilidad de éxito
    $servidores = [
        [
            'ip' => '44.206.26.155', // AWS Server prioritario (más rápido y disponible)
            'user' => 'sa',
            'pass' => 'Controlito0706*'
        ],
        [
            'ip' => '172.30.10.21', // Local intranet
            'user' => 'sa',
            'pass' => (isset($_GET["ModoPruebas"]) && $_GET["ModoPruebas"] == "Si") ? 'Santa0721+*' : 'Santa0721+'
        ]
    ];

    // Recuperar servidor y driver guardados en archivo temporal o sesión
    $cacheConnFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'siai_conn_fast.json';
    $cachedConnInfo = null;
    if (file_exists($cacheConnFile)) {
        $cachedConnInfo = @json_decode(@file_get_contents($cacheConnFile), true);
    }

    $servidorRecordado = $cachedConnInfo['ip'] ?? $_SESSION['siai_server_ip'] ?? null;
    $driverRecordado = $cachedConnInfo['driver'] ?? $_SESSION['siai_driver'] ?? null;
    $tipoRecordado = $cachedConnInfo['tipo'] ?? $_SESSION['siai_tipo'] ?? null;

    // Si ya tenemos el driver y servidor exacto probado, conectar directo
    if ($tipoRecordado === 'odbc' && $driverRecordado && $servidorRecordado && function_exists('odbc_connect')) {
        $pass = ($servidorRecordado === '44.206.26.155') ? 'Controlito0706*' : 'Santa0721+';
        $dsn = "Driver={{$driverRecordado}};Server={$servidorRecordado};Database={$dbName};LoginTimeout=2;ConnectionTimeout=2;TrustServerCertificate=yes;";
        $c = @odbc_connect($dsn, 'sa', $pass);
        if ($c) {
            $conexionGlobal = ['tipo' => 'odbc', 'conn' => $c];
            return $conexionGlobal;
        }
    }

    if ($tipoRecordado === 'sqlsrv' && $servidorRecordado && function_exists('sqlsrv_connect')) {
        $pass = ($servidorRecordado === '44.206.26.155') ? 'Controlito0706*' : 'Santa0721+';
        $info = [
            "Database" => $dbName,
            "UID" => 'sa',
            "PWD" => $pass,
            "CharacterSet" => "UTF-8",
            "LoginTimeout" => 2,
            "TrustServerCertificate" => true
        ];
        $c = @sqlsrv_connect($servidorRecordado, $info);
        if ($c) {
            $conexionGlobal = ['tipo' => 'sqlsrv', 'conn' => $c];
            return $conexionGlobal;
        }
    }

    if ($servidorRecordado) {
        usort($servidores, function($a, $b) use ($servidorRecordado) {
            return ($a['ip'] === $servidorRecordado) ? -1 : 1;
        });
    }

    // 1. Intentar con extensión nativa sqlsrv si está disponible
    if (function_exists('sqlsrv_connect')) {
        foreach ($servidores as $s) {
            $info = [
                "Database" => $dbName,
                "UID" => $s['user'],
                "PWD" => $s['pass'],
                "CharacterSet" => "UTF-8",
                "LoginTimeout" => 2,
                "TrustServerCertificate" => true
            ];
            $c = @sqlsrv_connect($s['ip'], $info);
            if ($c) {
                $_SESSION['siai_server_ip'] = $s['ip'];
                $_SESSION['siai_tipo'] = 'sqlsrv';
                @file_put_contents($cacheConnFile, json_encode(['ip' => $s['ip'], 'tipo' => 'sqlsrv']));
                $conexionGlobal = ['tipo' => 'sqlsrv', 'conn' => $c];
                return $conexionGlobal;
            }
        }
    }

    // 2. Intentar con ODBC Driver con timeout estricto de 2 segundos
    if (function_exists('odbc_connect')) {
        $drivers = [
            'ODBC Driver 17 for SQL Server',
            'ODBC Driver 18 for SQL Server',
            'SQL Server Native Client 11.0',
            'SQL Server'
        ];

        if ($driverRecordado) {
            usort($drivers, function($a, $b) use ($driverRecordado) {
                return ($a === $driverRecordado) ? -1 : 1;
            });
        }

        foreach ($servidores as $s) {
            foreach ($drivers as $d) {
                $dsn = "Driver={{$d}};Server={$s['ip']};Database={$dbName};LoginTimeout=2;ConnectionTimeout=2;TrustServerCertificate=yes;";
                $c = @odbc_connect($dsn, $s['user'], $s['pass']);
                if ($c) {
                    $_SESSION['siai_server_ip'] = $s['ip'];
                    $_SESSION['siai_driver'] = $d;
                    $_SESSION['siai_tipo'] = 'odbc';
                    @file_put_contents($cacheConnFile, json_encode(['ip' => $s['ip'], 'driver' => $d, 'tipo' => 'odbc']));
                    $conexionGlobal = ['tipo' => 'odbc', 'conn' => $c];
                    return $conexionGlobal;
                }
            }
        }
    }

    return false;
}

/**
 * Ejecuta una consulta SELECT y devuelve el array asociativo en UTF-8
 */
function dbSelect($connData, $sql, $params = [])
{
    if (!$connData || !isset($connData['conn'])) {
        return [
            "success" => false,
            "error" => "No hay conexión activa con la base de datos Conduit.",
            "data" => []
        ];
    }

    $tipo = $connData['tipo'];
    $conn = $connData['conn'];
    $registros = [];

    // Modo 1: sqlsrv
    if ($tipo === 'sqlsrv') {
        $stmt = sqlsrv_query($conn, $sql, $params);
        if ($stmt === false) {
            return [
                "success" => false,
                "error" => sqlsrv_errors(),
                "data" => []
            ];
        }

        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            foreach ($row as $k => $v) {
                if ($v instanceof DateTime) {
                    $row[$k] = $v->format('Y-m-d H:i:s');
                }
            }
            $registros[] = $row;
        }
        sqlsrv_free_stmt($stmt);
        return ["success" => true, "data" => $registros];
    }

    // Modo 2: ODBC
    if ($tipo === 'odbc') {
        $stmt = @odbc_exec($conn, $sql);
        if (!$stmt) {
            return [
                "success" => false,
                "error" => odbc_errormsg($conn),
                "data" => []
            ];
        }

        while ($row = odbc_fetch_array($stmt)) {
            $filaLimpia = [];
            foreach ($row as $k => $v) {
                // Asegurar codificación UTF-8 limpia
                if (is_string($v) && !mb_check_encoding($v, 'UTF-8')) {
                    $filaLimpia[$k] = utf8_encode($v);
                } else {
                    $filaLimpia[$k] = $v;
                }
            }
            $registros[] = $filaLimpia;
        }
        odbc_free_result($stmt);
        return ["success" => true, "data" => $registros];
    }

    return ["success" => false, "error" => "Tipo de conexión desconocido", "data" => []];
}

/**
 * Consulta de un solo dato escalar (primer valor)
 */
function mssql_cons($q)
{
    $connData = ConectadoAIntelisisAWS2();
    if (!$connData) return "";
    
    $res = dbSelect($connData, $q);
    if ($res['success'] && count($res['data']) > 0) {
        $primeraFila = $res['data'][0];
        return reset($primeraFila) ?: "";
    }
    return "";
}
?>
