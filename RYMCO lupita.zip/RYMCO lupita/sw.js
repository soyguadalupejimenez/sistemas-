/**
 * ============================================================
 *  RYMCO PWA — Service Worker
 *  Permite instalación como app y funcionamiento offline
 * ============================================================
 */

const CACHE_NAME = 'rymco-pwa-v2';
const CACHE_NAME_DYNAMIC = 'rymco-dynamic-v2';

// Archivos a guardar en cache para modo offline
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/inicio_usuario/bienvenidouser.html',
    '/inicio_usuario/styles.css',
    '/inicio_usuario/js/bitacora.js',
    '/inicio_usuario/js/ia_scanner.js',
    '/inicio_usuario/js/nav.js',
    '/inicio_usuario/js/inicio.js',
    '/firebase-config.js',
    '/manifest.json'
];

// ── INSTALACIÓN ───────────────────────────────────────────
self.addEventListener('install', (event) => {
    console.log('[SW RYMCO] Instalando Service Worker v2...');
    self.skipWaiting();
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return Promise.allSettled(
                STATIC_ASSETS.map(url =>
                    cache.add(url).catch(err =>
                        console.warn(`[SW RYMCO] No se pudo cachear: ${url}`, err)
                    )
                )
            );
        })
    );
});

// ── ACTIVACIÓN ────────────────────────────────────────────
self.addEventListener('activate', (event) => {
    console.log('[SW RYMCO] Activando Service Worker v2 y limpiando caches antiguas...');
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map(name => {
                    if (name !== CACHE_NAME && name !== CACHE_NAME_DYNAMIC) {
                        console.log('[SW RYMCO] Eliminando cache antigua:', name);
                        return caches.delete(name);
                    }
                })
            );
        }).then(() => {
            console.log('[SW RYMCO] ¡Activación completada!');
            return self.clients.claim();
        })
    );
});

// ── FETCH (Estrategia: Network First, Cache Fallback) ─────
self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    // No interceptar peticiones externas (Firebase, APIs, CDNs)
    if (!url.origin.includes(self.location.hostname) ||
        url.hostname.includes('googleapis') ||
        url.hostname.includes('firestore') ||
        url.hostname.includes('gstatic') ||
        url.hostname.includes('cdnjs') ||
        url.hostname.includes('jsdelivr') ||
        url.hostname.includes('fonts.googleapis') ||
        url.hostname.includes('generativelanguage')) {
        return; // dejar pasar sin interceptar
    }

    // Network First: Intentar obtener la versión más reciente del disco/red primero
    event.respondWith(
        fetch(event.request).then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
                const responseClone = networkResponse.clone();
                caches.open(CACHE_NAME_DYNAMIC).then(cache => {
                    cache.put(event.request, responseClone);
                });
            }
            return networkResponse;
        }).catch(() => {
            // Si no hay red/disco disponible (offline), usar cache
            return caches.match(event.request).then(cachedResponse => {
                if (cachedResponse) return cachedResponse;
                if (event.request.destination === 'document') {
                    return caches.match('/inicio_usuario/bienvenidouser.html');
                }
            });
        })
    );
});

// ── MENSAJE DE ACTUALIZACIÓN ──────────────────────────────
self.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
});
