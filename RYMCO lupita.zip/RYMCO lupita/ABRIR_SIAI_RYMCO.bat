@echo off
title SIAI RYMCO - Lanzador de Aplicacion
cd /d "%~dp0"

:: Forzar apertura en Google Chrome
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "%~dp0index.html"
    exit
)
if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" "%~dp0index.html"
    exit
)
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    start "" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" "%~dp0index.html"
    exit
)

:: Si no está en las rutas habituales, abrir con el navegador predeterminado
start "" "%~dp0index.html"
exit
