# 📘 MANUAL COMPLETO Y EXHAUSTIVO DEL SISTEMA SIAI (RYMCO S.A.)
## Documentación de Arquitectura, Interconexión de Módulos y Guía Detallada de Usuario

---

## 🏛️ 1. ARQUITECTURA GENERAL E INTERCONEXIÓN DEL SISTEMA

El **Sistema Integrado de Análisis de Inventarios (SIAI)** para **RYMCO S.A.** está diseñado bajo una arquitectura web modular interconectada en tiempo real a través de la nube de **Google Firebase (Cloud Firestore)** y ejecutado localmente mediante un servidor ligero Python en Google Chrome.

### 🔄 Diagrama del Flujo de Datos e Interconexión:
```
 [ 🔑 Inicio de Sesión ] (index.html + Firebase Auth)
          │
          ▼ (Valida Permisos y Rol)
 ┌─────────────────────────────────────────────────────────────┐
 │                💻 PANEL ADMINISTRADOR / USUARIO             │
 └──────────────────────────────┬──────────────────────────────┘
                                │
   ┌────────────────────────────┼────────────────────────────┐
   ▼                            ▼                            ▼
[ 📝 Bitácora Diaria ]   [ 📊 Dashboard KPI ]    [ 👥 Trabajadores ]
(Captura Piezas/Turno)  (Gráficas y Totales)    (Pase de Lista)
   │                            ▲                            │
   └─────────────┬──────────────┘                            │
                 ▼                                           │
  [ ☁️ Firebase Firestore ] ◄────────────────────────────────┘
  (Colección: registros_produccion)
                 │
                 ▼ (Lectura de Fechas: Lunes a Sábado)
 ┌─────────────────────────────────────────────────────────────┐
 │   🔄 BOTÓN DE TRANSFERENCIA SEMANAL A MÓDULOS DE PROCESOS   │
 └──────────────────────────────┬──────────────────────────────┘
                                │
  ┌──────────────────┬──────────┴──────────┬──────────────────┐
  ▼                  ▼                     ▼                  ▼
[ ♻️ Recuperación ] [ 🔧 Acondicionamiento ] [ 📐 Conformado ] [ ⚡ Re-Galvanizar ]
```

---

## 🔑 2. MÓDULO DE INICIO DE SESIÓN Y REGISTRO DE NUEVO MIEMBRO

### **Fichero principal:** `index.html` | **Lógica:** `script.js` | **Conexión:** `firebase-config.js` | **Colección:** `usuarios`

### 2.1. ¿Qué es exactamente esta pantalla (`index.html`)?
Es la **Puerta de Entrada y Control de Seguridad** del Sistema SIAI en **RYMCO S.A.** Permite autenticar de forma segura a todo el personal de la empresa, asignarles su nivel de permiso de acuerdo con su puesto de trabajo (**Administrador**, **Encargado** o **Trabajador**) y dar de alta nuevas cuentas en la nube de Firebase.

---

### 2.2. Desglose Exhaustivo de las 2 Vistas del Módulo:

#### 🔑 VISTA 1: "Inicio de Sesión de Miembros"
1. **Logotipo Oficial RYMCO S.A.:** Ubicado en la medalla circular a la izquierda con el sello *"RYMCO CALIDAD 360 - PRODUCTO TERMINADO"*.
2. **Campo 1: `Usuario o Correo`:** Permite ingresar tanto el correo electrónico registrado como el nombre de usuario sugerido.
3. **Campo 2: `Contraseña` (con función "Mostrar"):** Campo cifrado por seguridad con un botón alternador *"Mostrar"* para ver u ocultar el texto digitado.
4. **Botón Naranja `ACCESO`:**
   * Valida las credenciales contra la base de datos de Firebase.
   * Almacena los datos del perfil activo en el navegador mediante `localStorage` (`siai_usuario`).
   * Redirige al usuario según su nivel jerárquico:
     * Si es **Administrador** o **Encargado**: Abre la plataforma completa en `inicio_admin/bienvenidoadmin.html`.
     * Si es **Trabajador**: Abre el panel operativo en `inicio_usuario/bienvenidouser.html`.
5. **Enlace `¿No tienes cuenta? Regístrate aquí`:** Cambia dinámicamente el formulario hacia el alta de nuevo miembro sin necesidad de recargar la página.

---

---

#### 🌐 2.3. Conjugación Técnica entre Firebase Authentication y la Base de Datos (Cloud Firestore)

El sistema SIAI de **RYMCO S.A.** utiliza una **doble capa de seguridad en la nube de Google Firebase** para controlar el inicio de sesión y registro de miembros:

```
                          [ 💻 PANTALLA LOGIN / REGISTRO (index.html) ]
                                                │
                                                ▼
                                    [ 📜 script.js ]
                                                │
                    ┌───────────────────────────┴───────────────────────────┐
                    ▼                                                       ▼
  [ 🔒 CAPA 1: FIREBASE AUTHENTICATION ]               [ 🗄️ CAPA 2: CLOUD FIRESTORE (Base de Datos) ]
  • Proveedor: Correo electrónico / contraseña (🟢 Habilitado)    • Colección: usuarios
  • Proveedor: Teléfono (🟢 Habilitado)                          • Almacena: Nombre completo, Puesto (Rol),
  • Genera: Token JWT de sesión y UID único                       Número de Trabajador, Usuario Sugerido
                    │                                                       │
                    └───────────────────────────┬───────────────────────────┘
                                                ▼
                            [ 🍪 PERSISTENCIA DE SESIÓN LOCAL ]
                            • localStorage.setItem('siai_usuario')
                                                │
                                                ▼
                         [ 🚀 REDIRECCIÓN SEGÚN PUESTO (ROL) ]
                         • Administrador / Encargado ➔ bienvenidoadmin.html
                         • Trabajador ➔ bienvenidouser.html
```

##### ⚡ Pasos de la Conjugación Interna:

1. **Durante el Registro de un Nuevo Miembro:**
   * **Capa 1 (Firebase Auth):** El script ejecuta `firebase.auth().createUserWithEmailAndPassword(email, password)`. Firebase autentica la cuenta mediante los proveedores habilitados (**Correo electrónico/contraseña** y **Teléfono**) y genera un código identificador único (**UID**).
   * **Capa 2 (Cloud Firestore - Colección `usuarios`):** Usando el mismo **UID**, el script crea un documento en la base de datos resguardando: `nombreCompleto`, `numTrabajador`, `puesto` (*Administrador, Encargado o Trabajador*), `usuarioSugerido` y fecha de alta.

2. **Durante el Inicio de Sesión (Login):**
   * **Autenticación:** Al presionar **ACCESO**, `signInWithEmailAndPassword` verifica la clave cifrada en Firebase Auth.
   * **Lectura de Rol en Firestore:** Con el **UID** obtenido, el sistema consulta `db.collection('usuarios').doc(UID).get()`, lee el campo `puesto` y guarda la sesión en `localStorage` (`siai_usuario`).
   * **Redirección de Pantalla:** Dirige al usuario al panel de administración o de usuario según su rol de acceso autorizado.

---

---

## 📊 3. DASHBOARD PRINCIPAL Y PANEL DE CONTROL

### **Fichero principal:** `bienvenidoadmin.html` | **Lógica:** `inventario.js` | **Librería gráfica:** `Chart.js`

### 3.1. ¿Qué es exactamente el Dashboard Principal?
El **Dashboard Principal** es el centro de mando gerencial y análisis estratégico del Sistema SIAI en **RYMCO S.A.** Funciona como un tablero de control en tiempo real que consolida, calcula y grafica toda la información operativa ingresada por los supervisores y trabajadores en planta.

---

### 3.2. Desglose Exhaustivo de Componentes del Dashboard:

#### A. 🎴 Tarjetas KPI (Indicadores Clave de Desempeño Operacional)
Ubicadas en la parte superior del tablero, son las métricas más críticas para la toma de decisiones:

1. **Producción Total en Kilogramos ($\text{Kg}$):**
   * **¿Qué muestra?** La suma acumulada del peso total en kilogramos de toda la tubería y accesorios fabricados durante la jornada o semana activa.
   * **¿Cómo funciona?** El sistema toma la cantidad de piezas capturadas en la bitácora y la multiplica automáticamente por la matriz de pesos unitarios oficiales de RYMCO S.A. (ejemplo: *1/2" IMC = 2.85 kg/pieza*). La suma de todos los productos se refleja en formato legible con separadores de miles (ejemplo: `45,280 kg`).
   * **Valor para la empresa:** Permite calcular en segundos el tonelaje real producido para fletes, embarques y facturación.

2. **Piezas Totales Procesadas:**
   * **¿Qué muestra?** El contador total de unidades/tubos físicos manufacturados.
   * **¿Cómo funciona?** Suma todas las cantidades de piezas registradas por los tres turnos de trabajo.

3. **Nivel de Eficiencia y Productividad (%):**
   * **¿Qué muestra?** Un indicador porcentual que evalúa el rendimiento actual respecto a la capacidad esperada de la planta.
   * **Fórmula:** $\text{Eficiencia} = \left(\frac{\text{Producción Real}}{\text{Meta Establecida}}\right) \times 100$.

4. **Total del Turno Activo:**
   * **¿Qué muestra?** El acumulado exclusivo del turno operando en el momento actual (Mañana, Tarde o Noche).

---

#### B. 📈 Gráficas Interactivas de Análisis Visual (`Chart.js`)

1. **Gráfica de Tendencia de Producción Semanal (Lunes a Sábado):**
   * **Tipo de Gráfico:** Gráfico de líneas dinámico con nodos interactivos.
   * **¿Qué muestra?** El volumen de kilogramos producidos cada día de la semana activa (Lunes, Martes, Miércoles, Jueves, Viernes y Sábado).
   * **Interactividad:** Al pasar el cursor sobre cualquier nodo de la línea, se despliega una ventana (*tooltip*) indicando el día exacto, total de piezas y total de kilos.
   * **Valor para la empresa:** Identifica patrones de alta productividad y caídas por mantenimiento o insumos.

2. **Gráfica Comparativa de Rendimiento por Turnos:**
   * **Tipo de Gráfico:** Gráfico comparativo por cuadrilla.
   * **¿Qué muestra?** La distribución del volumen de trabajo entre los tres turnos:
     * 🌅 **Turno Mañana (1er. Turno)**
     * 🌇 **Turno Tarde (2do. Turno)**
     * 🌙 **Turno Noche (3er. Turno)**
   * **Valor para la empresa:** Permite evaluar el desempeño entre grupos de trabajo y equilibrar las cargas operativas.

---

#### C. 🌤️ Módulo Auxiliar de Clima y Condiciones de Planta
* **¿Qué muestra?** Temperatura actual y pronóstico del tiempo.
* **Aplicación en Planta:** En el procesamiento de acero, galvanizado y PVC, la temperatura ambiente influye en los tiempos de secado de pintura, reacciones químicas en tinas y confort térmico del personal.

---

### 3.3. ⏳ Regla Operativa Clave: Trabajo con 1 Día de Atraso (Desfasamiento de 24 Horas)
En la planta de producción de **RYMCO S.A.**, el Dashboard Principal está configurado intencionalmente para trabajar con **1 día de atraso**:

* **¿Por qué se trabaja con un día de atraso?**
  1. **Cierre de Turno Nocturno (3er. Turno):** El tercer turno opera durante la noche y termina en la madrugada del día siguiente. Para evitar que las métricas muestren datos incompletos o sesgados durante la jornada en curso, el sistema espera al cierre total del ciclo diario.
  2. **Auditoría y Verificación de Calidad:** Permite a los supervisores de planta validar, corregir o aprobar la captura de piezas antes de que se reflejen en los indicadores consolidados de la gerencia.

---

### 3.4. 📊 Lógica Comparativa de Gráficas (Semana Actual vs. Semana Anterior):
Todas las gráficas analíticas del Dashboard (`Chart.js`) están diseñadas bajo un modelo comparativo intersemanal:

* **Comparativa de Curvas (Semana Actual vs. Semana Anterior):**
  * **Línea/Barra Primaria (Semana Actual):** Representa la producción acumulada de Lunes a Sábado de la semana en curso.
  * **Línea/Barra de Referencia (Semana Anterior):** Muestra la curva de producción exacta de los mismos días de la semana pasada.
* **Propósito Gerencial:** Permite a la dirección de RYMCO S.A. saber de un vistazo si la eficiencia de esta semana superó o cayó respecto al desempeño de la semana previa, facilitando la toma de decisiones preventivas.

---

### 3.5. 🔄 Conexión Interna e Interconexión de Datos con Firebase:
```
[ 📝 Bitácora Diaria ] (Captura de datos)
         │
         ▼ (Sincronización en vivo)
[ ☁️ Firebase Firestore ] (Colección: registros_produccion)
         │
         ▼ (Función actualizarDashboardStats() en inventario.js)
[ 📊 DASHBOARD PRINCIPAL ]
   ├── Actualiza Tarjetas KPI (Kg, Piezas, Eficiencia)
   ├── Dibuja Gráfica Semanal (Lunes a Sábado)
   └── Dibuja Gráfica por Turnos (Mañana, Tarde, Noche)
```

---

## 📝 4. BITÁCORA DIARIA Y CAPTURA DE PRODUCCIÓN

### **Fichero principal:** `bitacora.js` | **Colección Firebase:** `registros_produccion`

### ¿Cómo funciona en detalle?
Es el motor principal de entrada de datos. Permite a los supervisores ingresar lo que se fabrica en planta.

### Desglose de Campos y su Funcionamiento:
1. **Selección de Turno:** Permite clasificar la producción entre **Mañana, Tarde o Noche**.
2. **Selección de Trabajador:** Despliega la lista de operadores activos para asignarles la responsabilidad del lote.
3. **Selección de Producto / Material:** Contiene el catálogo completo de productos de RYMCO S.A. (Tubería *Verde, Amarilla, Azul, EMT, IMC, PVC Pesado, PVC Ligero, Aluminio, Rígido, Unicanal*, etc.).
4. **Ingreso de Cantidad (Piezas):** El usuario escribe la cantidad numérica de piezas procesadas.
5. **Cálculo de Kilogramos Automático:** 
   * Cada producto tiene un **peso unitario exacto** configurado en la matriz `tablaGlobalProductos` (ejemplo: *1/2" IMC = 2.85 kg/pz*).
   * La fórmula interna ejecuta:  
     $$\text{Kilogramos Totales} = \text{Cantidad de Piezas} \times \text{Peso Unitario}$$
   * El resultado se muestra al instante en pantalla sin margen de error humano.
6. **Guardado y Sincronización:** Al hacer clic en **"Guardar Registro"**, los datos suben inmediatamente a la nube en Firebase Firestore dentro de la colección `registros_produccion`.

---

---

## 📊 5. REGISTRO DE PRODUCCIÓN (DATOS DE PRODUCCIÓN SEMANAL Y MENSUAL)

### **Fichero principal:** `bienvenidoadmin.html` | **Lógica:** `inventario.js` | **Colección Firebase:** `registros_produccion`

### 5.1. ¿Qué es exactamente "Registro de Producción"?
El apartado de **Registro de Producción (Datos Semanales)** es la **Gran Tabla de Acumulados y Consolidación de Planta**. Es la vista ejecutiva donde se agrupa, día por día y turno por turno, todo el volumen de producción que se ha generado a lo largo del mes y de la semana activa (de Lunes a Sábado).

---

### 5.2. Desglose Exhaustivo de Componentes:

#### A. 🎛️ Barra de Control y Filtros Superiores:
1. **Selector de Mes (`Agosto 2026 ▼`):** Permite cambiar de mes para consultar el historial de producciones de meses anteriores sin perder la vista actual.
2. **Filtro de Rango (`Todo el mes ▼`):** Permite filtrar si quieres ver la producción acumulada de todo el mes o únicamente de la semana en curso (Lunes a Sábado).
3. **Botón ☁️ "Subir datos":** Sincroniza manualmente cualquier borrador o registro pendiente hacia la base de datos en la nube (Firebase Firestore).
4. **Botón 🗑️ "Vaciar vista":** Limpia la vista previa en pantalla para evitar recargas pesadas en la memoria del navegador sin eliminar los datos guardados en la nube.

---

#### B. 📋 Tabla Central de Datos de Producción Semanal:
Organizada en un diseño de alto contraste con columnas estructuradas:

1. **DÍA y FECHA:**
   * Muestra la cronología del calendario de trabajo de RYMCO S.A. (ejemplo: *Sábado 01/08/2026, Lunes 03/08/2026, Martes 04/08/2026*, etc.).
2. **1ER. TURNO (Mañana):**
   * **PZ (Piezas):** Suma total de unidades producidas durante la mañana.
   * **KG (Kilos):** Tonelaje acumulado en color verde turquesa (`#34D399`).
3. **2DO. TURNO (Tarde):**
   * **PZ:** Piezas producidas en la tarde.
   * **KG:** Tonelaje acumulado en la tarde.
4. **3ER. TURNO (Noche):**
   * **PZ / KG:** Rendimiento del turno nocturno (si no hubo operaciones, muestra el indicador *"Sin turno"*).
5. **TOTAL DÍA (Columna Destacada en Verde Obscuro):**
   * **PZ:** La suma total de piezas manufacturadas en las 24 horas del día (1er Turno + 2do Turno + 3er Turno).
   * **KG:** El gran total de kilogramos del día.

---

#### C. 📊 Tarjetas Laterales de Totales Mensuales:
A la derecha de la tabla principal se ubican dos tarjetas de gran formato:
1. **PZ (TODO EL MES):** Muestra la cifra masiva acumulada de unidades procesadas en todo el mes (ejemplo: `377,458 piezas`).
2. **KG (TODO EL MES):** Muestra el tonelaje global acumulado en el mes (ejemplo: `657,356 kg` equivalentes a **657.3 toneladas**).

---

### 5.3. 🔄 Conexión e Interconexión con Firebase:
```
 [ 📝 Bitácora Diaria ] (Supervisor captura turno Mañana / Tarde / Noche)
           │
           ▼ (Guarda en Firebase)
 [ ☁️ Firebase Firestore ] (Colección: registros_produccion)
           │
           ▼ (Función obtenerMapaProduccionSemanal() en inventario.js)
 [ 📊 REGISTRO DE PRODUCCIÓN / DATOS SEMANALES ]
    ├── Agrupa piezas y kilos por Día y por Turno
    ├── Calcula la suma del TOTAL DÍA
    └── Suma las tarjetas globales: PZ (TODO EL MES) y KG (TODO EL MES)
```

### 5.2. Desglose Exhaustivo de Componentes:
1. **Tabla Comparativa Semanal por Turnos:**
   * Muestra la lista de productos manufacturados en la semana.
   * Divide la producción en columnas claras: **1er Turno (Mañana)**, **2do Turno (Tarde)** y **3er Turno (Noche)**.
   * Por cada turno, muestra dos datos clave:
     * **Piezas (Pz):** Número de unidades fabricadas.
     * **Kilos (Kg):** Tonelaje acumulado correspondiente a esas piezas.
   * **Columna "Total Día":** Suma automáticamente el rendimiento completo de las 24 horas del día (Turno 1 + Turno 2 + Turno 3).

2. **Herramientas de Auditoría y Corrección de Datos:**
   Cada fila de registro cuenta con dos botones de acción rápida:
   * ✏️ **Botón Editar (Lápiz Azul):** Permite al administrador corregir un número de piezas en caso de que un trabajador haya cometido un error de captura en la bitácora. Al editar, el sistema recalcula los kilogramos automáticamente y actualiza Firebase.
   * 🗑️ **Botón Eliminar (Bote de Basura Rojo):** Permite borrar de forma permanente registros duplicados o erróneos de la base de datos sin afectar el resto de la semana.

3. **Totales de Subtotal y Gran Total:**
   * En la parte inferior de cada bloque de proceso, muestra la fila de **SUBTOTAL** (suma de piezas y kilos del proceso).
   * Al final del día, muestra la tarjeta de **TOTAL TURNO** con los totales consolidados.

4. **Filtros de Búsqueda por Fecha y Proceso:**
   * Un selector desplegable que permite elegir entre ver los datos de hoy, de la semana en curso o consultar semanas pasadas.

---

## ♻️ 6. MÓDULO DE RECUPERACIÓN (MATERIAL RE-GALVANIZADO) Y PROCESOS ESPECIALES

### **Fichero principal:** `historial.js` | `recuperacion.js`

### 6.1. ¿Qué es exactamente "Recuperación"?
El apartado de **Recuperación** es un módulo de inventario especializado para gestionar el material derivado del proceso de **"Selección, Limpieza, Flejado y Empaque"** de tubos re-galvanizados en RYMCO S.A.

En las plantas de producción de tubería conduit y de acero, una parte del material requiere reprocesamiento (re-galvanizado) para cumplir con las normas de calidad. Este apartado lleva la contabilidad exacta de esos tubos recuperados listos para empaque o venta.

### 6.2. Desglose Exhaustivo de Componentes de la Tabla de Recuperación:
1. **Catálogo Completo de Productos de Recuperación:**
   * Una tabla estilizada que muestra la lista de todos los productos y calibres oficiales de la empresa (*1/2" Verde, 3/4" EMT, 1" IMC, PVC Pesado, Rígido, Unicanal*, etc.).

2. **Columnas de la Tabla de Recuperación:**
   * **Producto / Material:** Muestra el nombre del tipo de tubo en letras oscuras/negras con alto contraste.
   * **Cantidad (Pz) - Casilla Azul (`qty-input`):** Una casilla numérica redonda de color azul oscuro con texto blanco brillante donde se asigna la cantidad de piezas acumuladas de ese producto.
   * **Total (Kg) - Columna Numérica:** Muestra el peso total en kilogramos correspondiente a las piezas de recuperación.

3. **Fila de TOTAL GENERAL PROCESO (`tfoot`):**
   * Ubicada al pie de la tabla en una barra azul marino, suma en tiempo real el total de piezas recuperadas y el tonelaje total acumulado.

4. **🔄 El Botón Estrella: "Transferir Totales Semanales":**
   * **¿Qué hace?** Es una función inteligente desarrollada en JavaScript (`window.transferirA_Recuperacion()`).
   * **¿Cómo funciona paso a paso?**
     1. El sistema lee todos los registros de la bitácora almacenados en Firebase Firestore.
     2. Filtra automáticamente los registros que pertenecen a la **Semana Activa (Lunes a Sábado)** y cuyo proceso corresponde a *"Selección, Limpieza, Flejado y Empaque"*.
     3. Suma todas las piezas producidas de cada producto durante los 6 días de la semana.
     4. Llama a la tabla de Recuperación y **vacía los números de forma automática en las casillas correspondientes**.
     5. Guarda una foto fija del inventario consolidado de recuperación en Firebase (`estado_recuperacion`).
4. Filtra únicamente los productos que pertenecen al proceso del módulo.
5. Suma todas las piezas acumuladas de la semana por cada producto.
6. **Llena la tabla del módulo en segundos** y calcula el total general en kilogramos.
7. Guarda la foto fija del estado en Firebase (`estado_recuperacion`, `estado_acondicionamiento`, etc.).

---

## 👥 7. MÓDULO DE TRABAJADORES Y RENDIMIENTO

### **Fichero principal:** `bienvenidoadmin.html` | **Lógica:** `trabajadores.js` | **Colección Firebase:** `trabajadores` / `asistencia`

### 7.1. ¿Qué es exactamente "Trabajadores y Rendimiento"?
Es el centro de gestión de recursos humanos y evaluación de desempeño operativo de RYMCO S.A. Su objetivo es **medir la productividad individual y colectiva de los operarios de planta**, registrar la asistencia diaria por turno y relacionar las piezas fabricadas en la bitácora con los trabajadores responsables.

---

### 7.2. Desglose Exhaustivo Pestaña por Pestaña:

#### 📊 1. Pestaña: Dashboard de Control de Trabajadores
Muestra el resumen estadístico global del personal operativo:
* **Sección "DATOS DE PRODUCCIÓN ACTIVA":**
  * **TOTAL PIEZAS PRODUCIDAS:** Acumulado global de piezas procesadas por la plantilla.
  * **TOTAL KILOS PRODUCIDOS:** Tonelaje global atribuible al trabajo de los operarios.
  * **TRABAJADORES ACTIVOS:** Contador de empleados activos registrados en la plataforma.
  * **PROMEDIO PZ / TURNO:** Media matemática de piezas producidas por turno individual ($ \text{Promedio} = \frac{\text{Piezas Totales}}{\text{Turnos Trabajados}} $).
* **Sección "TENDENCIA DE PRODUCCIÓN POR MES":** Gráfica de línea comparativa mes a mes (Enero a Diciembre) para analizar si el desempeño del equipo humano aumenta o disminuye según la temporada.
* **Sección "RENDIMIENTO OPERACIONAL Y ASISTENCIA":**
  * **Asistencias Totales:** Contador de asistencias registradas.
  * **Faltas Totales:** Contador de inasistencias.
  * **Vacaciones Totales:** Registro de días de descanso o permisos autorizados.
  * **% Asistencia Global:** Porcentaje general de puntualidad respecto a la meta del 100%.
* **Sección "ANÁLISIS DE PROCESOS" y "Balance de Asistencia":** Gráficas de pastel que comparan cuántos trabajadores asistieron vs cuántos faltaron.

---

#### 📊 2. Pestaña: Rendimiento (Productividad Individual)
* **¿Qué hace?** Muestra el listado de operarios y calcula automáticamente **cuántas piezas y cuántos kilos ha producido cada trabajador individualmente**.
* **Valor:** Permite identificar a los operarios más productivos del mes para otorgar incentivos o bonos de productividad.

---

#### 📅 3. Pestaña: Asistencia Diaria (Pase de Lista Digital)
* **¿Qué hace?** Es el libro de asistencia digital de planta.
* **Botones de Registro Rápido:**
  * 🟢 **Asistió** (Presente en turno)
  * 🔴 **Faltó** (Inasistencia injustificada)
  * 🟡 **VAC** (Vacaciones / Permiso)
* **Sincronización en Nube:** Los datos de asistencia se guardan en Firebase para control de nómina y recursos humanos.

---

#### 🔍 4. Pestaña: Consulta Trabajador (Expediente Individual)
* **¿Qué hace?** Permite ingresar el nombre o número de un empleado para consultar su expediente completo, historial de asistencia de meses pasados y récord de producción acumulado.

---

## 💬 8. MÓDULO DE MENSAJES Y AVISOS INTERNOS

### **Fichero principal:** `bienvenidoadmin.html` | **Colección Firebase:** `avisos`

### 8.1. ¿Qué es exactamente "Mensajes y Avisos"?
Es el **canal oficial de comunicación interna y boletín de avisos** de RYMCO S.A. Permite que la dirección, gerencia o administradores publiquen anuncios importantes, alertas operativas o metas de producción para los supervisores y trabajadores de planta.

---

### 8.2. Desglose Exhaustivo de Componentes:
1. **📢 Tablón de Publicación de Avisos:**
   * **Título del Comunicado:** (ej. *"Mantenimiento Preventivo el Viernes"*, *"Meta de Producción Cumplida"*, *"Protocolos de Seguridad"*).
   * **Nivel de Prioridad:** Alta (Urgente - Rojo), Media (Informativo - Azul), Normal (General - Verde).
   * **Cuerpo del Mensaje:** Redacción del comunicado oficial.
2. **🔔 Notificaciones Emergentes y Campana Superior:**
   * Al publicar un aviso urgente, aparece un punto de alerta en el icono de la campana (🔔) en la barra superior.
3. **📜 Historial y Registro de Comunicados:**
   * Muro de anuncios pasados organizados por fecha y hora con opción para

## 📄 9. MÓDULO DE REPORTES EJECUTIVOS (PDF Y EXCEL)

### **Fichero principal:** `bienvenidoadmin.html` | **Librerías:** `html2pdf.bundle.min.js` | `xlsx.full.min.js`

### 9.1. ¿Qué es exactamente el Módulo de Reportes?
El módulo de **Reportes PDF y Excel** es el centro de documentación y exportación oficial de RYMCO S.A. Convierte toda la información almacenada en Firebase en documentos imprimibles y hojas de cálculo listas para presentar ante la dirección, auditorías contables o gerencia general.

---

### 9.2. Desglose Exhaustivo de Funciones:

#### 📄 A. Generación de Informes Oficiales en PDF:
* **Encabezado Membretado Institucional:** Incluye el logotipo oficial de **RYMCO S.A.**, título del informe, fecha y hora de emisión y nombre del administrador responsable.
* **Vista Previa en Hoja de Trabajo:** Muestra en pantalla el documento tal cual se va a descargar para poder revisarlo antes de guardar.
* **Consolidación por Turnos y Fechas:** Incluye tablas limpias con la suma total de piezas y kilos producidos por cada turno (Mañana, Tarde, Noche).
* **Descarga Automática (`html2pdf.js`):** Al presionar **"Descargar PDF"**, la librería convierte el HTML en un documento `.pdf` con calidad de imprenta y lo guarda automáticamente en la carpeta de **Descargas** de la laptop.

#### 📊 B. Exportación a Hojas de Cálculo de Excel (`.xlsx`):
* **Formatos Compatibles:** Genera archivos `.xlsx` compatibles con Microsoft Excel, Google Sheets y LibreOffice Calc.
* **Estructura por Pestañas:** Exporta las tablas de Bitácora, Recuperación, Acondicionamiento, Conformado y Re-Galvanizar organizadas en libros de cálculo.
* **Valor para la Empresa:** Permite al departamento de contabilidad y finanzas realizar fórmulas complejas, gráficos personalizados o cruces de costos de materia prima.

---

## ⚙️ 9. CONFIGURACIÓN DEL SISTEMA Y CIERRE MENSUAL

### **Fichero principal:** `configuracion.js` | `gestion_rymco.js`

### Desglose de Funciones:
* **Cierre Mensual:** Al finalizar el mes, el administrador presiona *"Ejecutar Cierre Mensual"*. El sistema archiva la producción del mes en la colección `reportes_mensuales` y reinicia las casillas operativas para el nuevo mes sin borrar el historial almacenado.
* **Mantenimiento de Datos:** Limpia borradores temporales del almacenamiento local.

---

## 💻 10. COMPONENTES TÉCNICOS Y EJECUTABLES EN LA LAPTOP

* **`EJECUTAR_SIAI_RYMCO.vbs` / `ABRIR_SIAI_RYMCO.bat`:**
  1. Levantan el servidor local en segundo plano en el puerto `8080` utilizando `python -m http.server 8080`.
  2. Detectan automáticamente la ruta de **Google Chrome** en Windows (`C:\Program Files\Google\Chrome\Application\chrome.exe`).
  3. Abren la aplicación exclusivamente en Chrome en una pestaña estándar para permitir recarga limpia de cambios.