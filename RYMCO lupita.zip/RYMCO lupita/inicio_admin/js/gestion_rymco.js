// ==============================================================================
//  gestion_rymco.js - Módulo Profesional de Reportes PDF e Inventario RYMCO
// ==============================================================================

// 1. Cierre mensual (Mueve datos a histórico y limpia vista local)
async function ejecutarCierreMensual() {
    if (!confirm("Esto archivará el reporte mensual y limpiará la vista activa del sistema. Los datos en Firebase permanecerán resguardados. ¿Continuar?")) return;
    
    if (typeof db !== 'undefined' && db !== null) {
        try {
            await db.collection("reportes_mensuales").add({
                fecha: new Date().toISOString(),
                total_kilos: document.getElementById('global-total') ? document.getElementById('global-total').innerText : '0',
                estado: 'procesado'
            });
        } catch (e) {
            console.warn("No se pudo guardar el reporte mensual en Firebase:", e);
        }
    }
    
    document.querySelectorAll('.qty-input').forEach(inp => {
        inp.value = '0';
        inp.dispatchEvent(new Event('input', { bubbles: true }));
    });
    
    if (typeof mostrarToast === 'function') mostrarToast("✅ Cierre mensual exitoso.", "ok");
    else alert("✅ Cierre mensual exitoso. Los datos históricos en Firebase permanecen intactos.");
    
    if (window.cargarPanelAdmin) window.cargarPanelAdmin();
    if (window.actualizarDashboardStats) window.actualizarDashboardStats();
    if (window.inicializarGraficos) window.inicializarGraficos();
}

async function limpiarDatosTotales() {
    await ejecutarCierreMensual();
}

// ==============================================================================
// 2. RENDERIZADOR AUTOMÁTICO DE REPORTES PDF Y MATERIALES (DATOS REALES DE FIREBASE)
// ==============================================================================
window.renderizarReportePDF = async function() {
    const elFiltro = document.getElementById('pdf-filtro-periodo') || document.getElementById('pdf-user-filtro-periodo');
    const filtroPeriodo = elFiltro ? elFiltro.value : 'todos';

    // 1. Obtener registros directamente de Firebase Firestore (Fuente de Verdad Real)
    let rawRecords = [];
    let firebaseConectado = false;

    if (typeof db !== 'undefined' && db !== null) {
        try {
            const snapProd = await db.collection('registros_produccion').get();
            snapProd.forEach(doc => {
                const d = doc.data();
                d.firebaseId = doc.id;
                rawRecords.push(d);
            });
            firebaseConectado = true;
        } catch(e) {
            console.warn("Error al consultar 'registros_produccion' en Firebase:", e);
        }

        try {
            const snapHist = await db.collection('historial_mensual').get();
            snapHist.forEach(doc => {
                const d = doc.data();
                d.firebaseId = doc.id;
                rawRecords.push(d);
            });
        } catch(e) { }
    }

    // Solo como respaldo de emergencia si no hay conexión a Firebase
    if (!firebaseConectado || rawRecords.length === 0) {
        const safeParse = (key) => {
            try {
                const val = localStorage.getItem(key);
                if (!val) return [];
                const parsed = JSON.parse(val);
                return Array.isArray(parsed) ? parsed : [];
            } catch(e) { return []; }
        };
        const localSources = [
            safeParse('rymco_db_admin'),
            safeParse('bitacora_offline'),
            safeParse('rymco_recu_historial')
        ];
        localSources.forEach(arr => arr.forEach(r => { if(r) rawRecords.push(r); }));
    }

    // 2. Desduplicar y aplicar filtros de fecha reales
    const normalizarF = window.normalizarFechaISO || (f => f ? String(f).split('T')[0] : null);
    const vaciarTS = parseInt(localStorage.getItem('rymco_vaciar_timestamp') || '0', 10);
    
    // Cálculo de fechas actuales para filtros
    const ahora = new Date();
    const hoyISO = ahora.toISOString().split('T')[0];
    const mesActualISO = hoyISO.substring(0, 7); // 'YYYY-MM'

    // Cálculo de rango de la semana actual (Lunes a Domingo)
    const diaSemana = ahora.getDay();
    const distanciaLunes = (diaSemana + 6) % 7;
    const lunes = new Date(ahora);
    lunes.setDate(ahora.getDate() - distanciaLunes);
    lunes.setHours(0, 0, 0, 0);
    const lunesISO = lunes.toISOString().split('T')[0];

    const domingo = new Date(lunes);
    domingo.setDate(lunes.getDate() + 6);
    domingo.setHours(23, 59, 59, 999);
    const domingoISO = domingo.toISOString().split('T')[0];

    const yaProcesados = new Set();
    let regFiltrados = [];

    rawRecords.forEach(r => {
        if (!r) return;
        if (window.esRegistroEliminado && window.esRegistroEliminado(r)) return;

        // Descartar registros ficticios / semillas de prueba
        if (r.producto === 'Producción General' || r.proceso === 'Preparación y/o Acondicionamiento de venta') return;

        // Filtrar si el sistema fue vaciado previamente
        if (vaciarTS > 0 && r.timestamp && r.timestamp < vaciarTS) return;

        const fiso = normalizarF(r.fecha) || hoyISO;
        const keyId = r.firebaseId || r.id || `${fiso}_${r.turno}_${r.producto}_${r.piezas}_${r.kilos}`;

        if (keyId && yaProcesados.has(keyId)) return;
        if (keyId) yaProcesados.add(keyId);

        // Filtro por período seleccionado
        if (filtroPeriodo === 'hoy') {
            if (fiso !== hoyISO) return;
        } else if (filtroPeriodo === 'mes') {
            if (!fiso.startsWith(mesActualISO)) return;
        } else if (filtroPeriodo === 'semana') {
            if (fiso < lunesISO || fiso > domingoISO) return;
        }

        regFiltrados.push(r);
    });

    // 3. Totales por Turno (Mañana, Tarde, Noche) y Gran Total
    let mananaPz = 0, mananaKg = 0;
    let tardePz = 0, tardeKg = 0;
    let nochePz = 0, nocheKg = 0;
    let grandPz = 0, grandKg = 0;

    const materialesMap = {};

    regFiltrados.forEach(r => {
        const parseN = window.parseNum || (v => parseFloat(String(v || 0).replace(/,/g, '')) || 0);
        const pz = Math.round(parseN(r.piezas || r.Piezas || r.qty || r.cantidad || 0));
        const kg = Math.round(parseN(r.kilos || r.Kilos || 0));
        const turnoNorm = window.normalizarTurno ? window.normalizarTurno(r.turno) : (r.turno || 'Mañana');
        const prodStr = String(r.producto || r.Producto || r.material || r.especificacion || 'Tubería Conduit').trim();
        const procStr = String(r.proceso || r.Proceso || 'Producción General').trim();

        if (turnoNorm === 'Mañana' || turnoNorm.toLowerCase().includes('mañ')) {
            mananaPz += pz; mananaKg += kg;
        } else if (turnoNorm === 'Tarde' || turnoNorm.toLowerCase().includes('tard')) {
            tardePz += pz; tardeKg += kg;
        } else if (turnoNorm === 'Noche' || turnoNorm.toLowerCase().includes('noch')) {
            nochePz += pz; nocheKg += kg;
        } else {
            mananaPz += pz; mananaKg += kg;
        }

        grandPz += pz;
        grandKg += kg;

        if (!materialesMap[prodStr]) {
            materialesMap[prodStr] = { producto: prodStr, proceso: procStr, piezas: 0, kilos: 0, turnos: new Set() };
        }
        materialesMap[prodStr].piezas += pz;
        materialesMap[prodStr].kilos += kg;
        if (r.turno) materialesMap[prodStr].turnos.add(r.turno);
    });

    const fmtNum = n => Number(n || 0).toLocaleString('es-MX');

    // Actualizar Tarjetas de Turnos (Admin y Operador)
    const updateText = (ids, val) => {
        ids.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.textContent = val;
        });
    };

    updateText(['pdf-manana-pz', 'pdf-user-manana-pz'], fmtNum(mananaPz));
    updateText(['pdf-manana-kg', 'pdf-user-manana-kg'], `${fmtNum(mananaKg)} kg`);

    updateText(['pdf-tarde-pz', 'pdf-user-tarde-pz'], fmtNum(tardePz));
    updateText(['pdf-tarde-kg', 'pdf-user-tarde-kg'], `${fmtNum(tardeKg)} kg`);

    updateText(['pdf-noche-pz', 'pdf-user-noche-pz'], fmtNum(nochePz));
    updateText(['pdf-noche-kg', 'pdf-user-noche-kg'], `${fmtNum(nocheKg)} kg`);

    updateText(['pdf-grand-total-pz', 'pdf-user-grand-total-pz'], fmtNum(grandPz));
    updateText(['pdf-grand-total-kg', 'pdf-user-grand-total-kg'], `${fmtNum(grandKg)} kg`);

    updateText(['pdf-tbl-total-pz', 'pdf-user-tbl-total-pz'], fmtNum(grandPz));
    updateText(['pdf-tbl-total-kg', 'pdf-user-tbl-total-kg'], `${fmtNum(grandKg)} kg`);

    // Fecha y Hora de Emisión
    const now = new Date();
    const tsText = `Fecha de emisión: ${now.toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`;
    updateText(['pdf-report-timestamp', 'pdf-user-report-timestamp'], tsText);

    // Filter Label
    const filterNames = { todos: 'Todo el Historial', mes: 'Mes Actual', semana: 'Semana Actual', hoy: 'Día de Hoy' };
    updateText(['pdf-report-filter-label', 'pdf-user-report-filter-label'], `Filtro: ${filterNames[filtroPeriodo] || 'General'}`);

    // Renderizar Filas de Tabla de Materiales
    const renderTbody = (tbodyId) => {
        const tbody = document.getElementById(tbodyId);
        if (!tbody) return;

        const listaMat = Object.values(materialesMap).sort((a, b) => b.kilos - a.kilos);

        if (listaMat.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align:center; padding: 2.5rem; color: #94A3B8; font-weight: 600; font-size: 0.95rem;">
                        No hay materiales en inventario registrados actualmente.
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = listaMat.map((m, idx) => {
            const pct = grandPz > 0 ? ((m.piezas / grandPz) * 100).toFixed(1) : (grandKg > 0 ? ((m.kilos / grandKg) * 100).toFixed(1) : '0');
            const turnosStr = Array.from(m.turnos).join(', ') || 'Mañana, Tarde';
            const bgRow = idx % 2 === 1 ? 'background: #F8FAFC;' : 'background: #FFFFFF;';
            return `
                <tr style="border-bottom: 1px solid #E2E8F0; ${bgRow}">
                    <td style="padding: 10px 14px; font-weight: 700; color: #64748B;">${idx + 1}</td>
                    <td style="padding: 10px 14px; font-weight: 700; color: #1E293B;">${m.producto}</td>
                    <td style="padding: 10px 14px; color: #475569; font-size: 0.85rem;">${m.proceso}</td>
                    <td style="padding: 10px 14px; text-align: center; font-weight: 700; color: #2563EB;">${fmtNum(m.piezas)}</td>
                    <td style="padding: 10px 14px; text-align: right; font-weight: 700; color: #16A34A;">${fmtNum(m.kilos)} kg</td>
                    <td style="padding: 10px 14px; text-align: center; font-size: 0.82rem; color: #64748B;">${turnosStr}</td>
                    <td style="padding: 10px 14px; text-align: right; font-weight: 700; color: #4338CA;">${pct}%</td>
                </tr>
            `;
        }).join('');
    };

    renderTbody('pdf-materiales-tbody');
    renderTbody('pdf-user-materiales-tbody');
};

// ==============================================================================
// 3. DESCARGA Y EXPORTACIÓN EN FORMATO PDF PROFESIONAL
// ==============================================================================
window.generarReportePDF = function() {
    window.renderizarReportePDF();
};

window.descargarPDFReporte = function(isUserMode = false) {
    const targetId = isUserMode ? 'pdf-user-report-document-wrapper' : 'pdf-report-document-wrapper';
    const element = document.getElementById(targetId);
    if (!element) return;

    if (typeof html2pdf === 'undefined') {
        alert("La librería de generación de PDF se está cargando. Por favor, reintenta en un momento.");
        return;
    }

    const fechaStr = new Date().toISOString().split('T')[0];
    const opt = {
        margin: [0.3, 0.3, 0.3, 0.3],
        filename: `Reporte_Oficial_Materiales_RYMCO_${fechaStr}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, logging: false },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    html2pdf().set(opt).from(element).save();
};

window.imprimirReportePDF = function() {
    window.print();
};

// Ejecución inicial automática al cargar el script
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (window.renderizarReportePDF) window.renderizarReportePDF();
    }, 200);
});
