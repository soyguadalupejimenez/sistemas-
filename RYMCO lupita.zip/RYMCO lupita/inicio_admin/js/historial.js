// ─── Tabla de productos (compartida por los 4 módulos) ───────────────────────
const tablaGlobalProductos = [
    // ── VERDE ────────────────────────────────────────────
    { producto: '1/2" verde', valor: 1.262 },
    { producto: '3/4" verde', valor: 1.672 },
    { producto: '1" Verde', valor: 3.2 },
    { producto: '1 1/4" verde', valor: 4.135 },
    { producto: '1 1/2" verde', valor: 4.91 },
    { producto: '2" verde', valor: 6.24 },
    { producto: '2 1/2" Verde', valor: 9.80 },
    { producto: '3" verde', valor: 11.93 },
    { producto: '3 1/2" Verde', valor: 15.84 },
    { producto: '4" Verde', valor: 17.83 },

    // ── AMARILLA ─────────────────────────────────────────
    { producto: '1/2" Amarilla', valor: 2.154 },
    { producto: '3/4" Amarilla', valor: 2.721 },
    { producto: '1" Amarilla', valor: 4.143 },
    { producto: '1 1/4" Amarilla', valor: 5.254 },
    { producto: '1½" Amarilla', valor: 6.2 },
    { producto: '2" Amarilla', valor: 9.379 },
    { producto: '2 1/2" Amarilla', valor: 16.186 },
    { producto: '3" Amarilla', valor: 19.267 },
    { producto: '4" Amarilla', valor: 24.992 },

    // ── AZUL ─────────────────────────────────────────────
    { producto: '1/2" azul', valor: 0.90 },
    { producto: '1½" azul', valor: 0.9 },

    // ── EMT ──────────────────────────────────────────────
    { producto: '1/2" EMT', valor: 1.36 },
    { producto: '3/4" EMT', valor: 2.09 },
    { producto: '1" EMT', valor: 3.06 },
    { producto: '1 1/4" EMT', valor: 4.55 },
    { producto: '1 1/2" EMT', valor: 5.283 },
    { producto: '2" EMT', valor: 6.71 },
    { producto: '2 1/2" EMT', valor: 9.8 },
    { producto: '3" EMT', valor: 11.93 },
    { producto: '3 1/2" EMT', valor: 15.84 },
    { producto: '4" EMT', valor: 17.83 },

    // ── IMC ──────────────────────────────────────────────
    { producto: '1/2" IMC', valor: 2.85 },
    { producto: '3/4" IMC', valor: 3.81 },
    { producto: '1" IMC', valor: 5.47 },
    { producto: '1 1/4" IMC', valor: 7.10 },
    { producto: '1 1/2" IMC', valor: 8.21 },
    { producto: '2" IMC', valor: 11.6 },
    { producto: '2 1/2" IMC', valor: 20.004 },
    { producto: '3" IMC', valor: 24.046 },
    { producto: '3 1/2" IMC', valor: 28.068 },
    { producto: '4" IMC', valor: 31.752 },

    // ── PVC PESADO (V Y G) ────────────────────────────────
    { producto: '1/2" PVC Pesado', valor: 0.49 },
    { producto: '3/4" PVC Pesado', valor: 0.61 },
    { producto: '1" PVC Pesado', valor: 0.78 },
    { producto: '1 1/4" PVC Pesado', valor: 1.05 },
    { producto: '1 1/2" PVC Pesado', valor: 1.45 },
    { producto: '2" PVC Pesado', valor: 2.15 },
    { producto: '2 1/2" PVC Pesado', valor: 3.1 },
    { producto: '3" PVC Pesado', valor: 3.90 },
    { producto: '4" PVC Pesado', valor: 5.3 },

    // ── PVC LIGERO ────────────────────────────────────────
    { producto: '1/2" PVC LIGERO', valor: 0.24 },
    { producto: '3/4" PVC LIGERO', valor: 0.32 },
    { producto: '1" PVC LIGERO', valor: 0.49 },
    { producto: '1 1/4" PVC LIGERO', valor: 0.74 },
    { producto: '1 1/2" PVC LIGERO', valor: 0.92 },
    { producto: '2" PVC LIGERO', valor: 1.462 },

    // ── ALUMINIO ──────────────────────────────────────────
    { producto: '1/2" Aluminio', valor: 1.34 },
    { producto: '3/4" Aluminio', valor: 1.78 },
    { producto: '1" Aluminio', valor: 2.70 },
    { producto: '1 1/4" Aluminio', valor: 3.25 },
    { producto: '1 1/2" Aluminio', valor: 4.02 },
    { producto: '2" Aluminio', valor: 5.38 },
    { producto: '2 1/2" Aluminio', valor: 8.50 },
    { producto: '3" Aluminio', valor: 11.17 },
    { producto: '3 1/2" Aluminio', valor: 15.58 },
    { producto: '4" Aluminio', valor: 28.59 },

    // ── RÍGIDO 3.05 MTS ───────────────────────────────────
    { producto: '1/2" rig a 3.05', valor: 3.72 },
    { producto: '3/4" rig a 3.05', valor: 4.94 },
    { producto: '1" rig a 3.05', valor: 7.303 },
    { producto: '1 1/4" rig a 3.05', valor: 9.888 },
    { producto: '1 1/2" rig a 3.05', valor: 11.93 },
    { producto: '2" rig a 3.05', valor: 15.876 },
    { producto: '2 1/2" rig a 3.05', valor: 25.36 },
    { producto: '3" rig a 3.05', valor: 32.98 },
    { producto: '3 1/2" rig a 3.05', valor: 39.917 },
    { producto: '4" rig a 3.05', valor: 46.72 },
    { producto: '6" rig a 3.05', valor: 87.60 },

    // ── RÍGIDO 3.20 MTS ───────────────────────────────────
    { producto: '1/2" rig a 3.20', valor: 4.06 },
    { producto: '3/4" rig a 3.20', valor: 5.39 },
    { producto: '1" rig a 3.20', valor: 7.85 },
    { producto: '1 1/4" rig a 3.20', valor: 10.98 },
    { producto: '1 1/2" rig a 3.20', valor: 13 },
    { producto: '2" rig a 3.20', valor: 17.34 },
    { producto: '2 1/2" rig a 3.20', valor: 27.59 },
    { producto: '3" rig a 3.20', valor: 36.19 },
    { producto: '3 1/2" rig a 3.20', valor: 43.38 },
    { producto: '4" rig a 3.20', valor: 51.38 },

    // ── ESPECIALES ────────────────────────────────────────
    { producto: '1 1/4" especial', valor: 3.496 },
    { producto: '1 1/4" ESP. A 1.5 MTS', valor: 1.748 },
    { producto: '1 1/4" ESP. A 2 MTS', valor: 0.49 },
    { producto: '1 1/4" ESP. A 3 MTS', valor: 1.748 },
    { producto: '1 1/4" ESP. A 4 MTS', valor: 4.637 },

    // ── PVC GRIS ──────────────────────────────────────────
    { producto: '1/2" PVC GRIS TA', valor: 0.61 },
    { producto: '3/4" PVC GRIS', valor: 0.61 },
    { producto: '3/4" PVC GRIS TA', valor: 0.78 },
    { producto: '1" PVC GRIS TA', valor: 5.3 },
    { producto: '1 1/4" PVC GRIS TA', valor: 0.49 },
    { producto: '1 1/2" PVC GRIS TA', valor: 1.032 },
    // ── PVC C40 ───────────────────────────────────────────
    { producto: '1/2" PVC C40', valor: 2.15 },
    { producto: '3/4" PVC C40', valor: 0.9 },
    { producto: '1" PVC C40', valor: 3.9 },
    { producto: '1 1/4" PVC C40', valor: 0.9 },
    { producto: '1 1/2" PVC C40', valor: 0.9 },
    { producto: '2" PVC C40', valor: 1.78 },
    { producto: '2 1/2" PVC C40', valor: 2.7 },
    { producto: '3" PVC C40', valor: 5.38 },
    { producto: '4" PVC C40', valor: 11.17 },

    // ── PVC C80 ───────────────────────────────────────────
    { producto: '1/2" PVC C80', valor: 3.25 },
    { producto: '3/4" PVC C80', valor: 4.02 },
    { producto: '1" PVC C80', valor: 28.59 },
    { producto: '1 1/4" PVC C80', valor: 0.9 },
    { producto: '1 1/2" PVC C80', valor: 8.1024 },
    { producto: '2" PVC C80', valor: 0.753 },
    { producto: '2 1/2" PVC C80', valor: 0.998 },
    { producto: '3" PVC C80', valor: 1.484 },
    { producto: '4" PVC C80', valor: 2.015 },

    // ── ORTOPEDICO ────────────────────────────────────────
    { producto: '3/4" Ortopedico', valor: 2.406 },
    { producto: '1" Ortopedico', valor: 3.4 },

    // ── A53 ───────────────────────────────────────────────
    { producto: '1/2" A53', valor: 1.45 },

    // ── VARILLA ROSCADA ───────────────────────────────────
    { producto: '1/4" varilla roscada', valor: 0.5442 },
    { producto: '1/2" varilla roscada', valor: 2.389 },

    // ── TA53 ──────────────────────────────────────────────
    { producto: 'TA53 1/2" (CED-40) Galvanizado Ros', valor: 8.1024 },
    { producto: 'TA53 1" (CED-40) Negro Liso', valor: 15.9872 },
    { producto: 'TA53 4" (CED-40) Negro Liso', valor: 102.62 },
    { producto: 'TA53 4" (CED-40) Rojo Ranurado', valor: 102.62 },

    // ── UNICANAL ──────────────────────────────────────────
    { producto: 'Unicanal sólido 4x2 c.16', valor: 3.059 },
    { producto: 'Unicanal perforado 4x2 c.16', valor: 3.059 },
    { producto: 'Unicanal sólido 4x4 c.16', valor: 4.88 },
    { producto: 'Unicanal perforado 4x4 c.16', valor: 4.88 },
    { producto: 'Unicanal sólido 4x2 c.14', valor: 4.46 },
    { producto: 'Unicanal perforado 4x2 c.14', valor: 4.46 },
    { producto: 'Unicanal sólido 4x4 c.14', valor: 6.84 },
    { producto: 'Unicanal perforado 4x4 c.14', valor: 5.60 }
];

// ─── Normalización robusta de nombres de producto ─────────────────────────────
// Convierte: ½→1/2, ¾→3/4, ¼→1/4, elimina comillas dobles y simples, espacios extras y pasa a minúsculas
function normalizarProducto(s) {
    return String(s || '')
        .toLowerCase()
        .replace(/(\d)\s*\u00BD/g, '$1 1/2')
        .replace(/(\d)\s*\u00BE/g, '$1 3/4')
        .replace(/(\d)\s*\u00BC/g, '$1 1/4')
        .replace(/\u00BD/g, '1/2')
        .replace(/\u00BE/g, '3/4')
        .replace(/\u00BC/g, '1/4')
        .replace(/[\u201C\u201D\u201E\u2018\u2019\u0022"]/g, '') // Eliminar comillas dobles y tipográficas
        .replace(/['']/g, '')                                  // Eliminar comillas simples
        .replace(/\s+/g, ' ')                                  // espacios múltiples → uno solo
        .trim();
}

function normalizarFechaISO(fechaRaw) {
    if (!fechaRaw) return '';
    let str = String(fechaRaw).trim();
    if (str.includes('T')) str = str.split('T')[0];

    const matchDMY = str.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/);
    if (matchDMY) {
        const d = String(matchDMY[1]).padStart(2, '0');
        const m = String(matchDMY[2]).padStart(2, '0');
        const y = matchDMY[3];
        return `${y}-${m}-${d}`;
    }

    const matchYMD = str.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
    if (matchYMD) {
        const y = matchYMD[1];
        const m = String(matchYMD[2]).padStart(2, '0');
        const d = String(matchYMD[3]).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }

    return str;
}

function obtenerFechasSemanaActiva(datos) {
    let target = new Date();
    let maxFechaStr = "";
    if (Array.isArray(datos)) {
        datos.forEach(r => {
            const fiso = normalizarFechaISO(r?.fecha);
            if (fiso && fiso > maxFechaStr) maxFechaStr = fiso;
        });
    }

    if (maxFechaStr) {
        const parts = maxFechaStr.split('-');
        if (parts.length === 3) {
            target = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
        }
    }

    const martes = (typeof window.getMartesSemanaActiva === 'function') ? window.getMartesSemanaActiva(target) : new Date(target);
    martes.setHours(0, 0, 0, 0);

    const lunesFin = new Date(martes);
    lunesFin.setDate(martes.getDate() + 6);
    lunesFin.setHours(23, 59, 59, 999);

    const formatISO = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return {
        fechaLunesISO: formatISO(martes),
        fechaSabadoISO: formatISO(lunesFin)
    };
}

// ─── Helpers para leer datos de producción (Firebase + localStorage + Offline + Drafts + Historial Mensual) ──────────
// Lee TODAS las fuentes posibles de datos para garantizar la suma total de la semana sin perder registros
async function leerDatosAdmin() {
    let rawDatos = [];

    // 1. Leer de Firebase
    if (typeof db !== 'undefined' && db !== null) {
        try {
            const snap = await db.collection('registros_produccion').get();
            snap.forEach(doc => {
                const data = doc.data();
                data.firebaseId = doc.id;
                rawDatos.push(data);
            });
        } catch (e) { }
    }

    // Comentado para forzar que sea 100% Firebase

    // 6. Desduplicar por ID único de registro
    const idsVistos = new Set();
    const datos = [];
    rawDatos.forEach(r => {
        if (!r || !r.fecha) return;
        if (window.esRegistroEliminado && window.esRegistroEliminado(r)) return;
        const fechaNorm = normalizarFechaISO(r.fecha);
        if (!fechaNorm) return;

        const regId = r.firebaseId || r.id || '';
        if (regId && idsVistos.has(regId)) return;
        if (regId) idsVistos.add(regId);

        datos.push({ ...r, fecha: fechaNorm });
    });

    return datos;
}

// ─── Módulo genérico: inyecta tabla + calcula + guarda + carga ─────────────────
function crearModulo({ tbodyId, prefix, materiales, storageKey, firestoreDoc, validProcesos, tabTarget }) {
    const tbody = document.getElementById(tbodyId);

    // Inyectar filas
    if (tbody) {
        tbody.innerHTML = '';
        materiales.forEach((item, index) => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="color: #000000 !important; font-weight: 700; font-size: 0.9rem; padding: 10px 16px;">${item.producto}</td>
                <td style="text-align:center; padding: 10px 16px;">
                    <input type="number" class="qty-input" id="${prefix}-qty-${index}" min="0" value="0">
                </td>
                <td class="numeric" id="${prefix}-kg-${index}" style="color: #000000 !important; font-weight: 800; font-size: 0.95rem; padding: 10px 16px; text-align: right;">0</td>
            `;
            tbody.appendChild(tr);

            const inp = document.getElementById(`${prefix}-qty-${index}`);
            if (inp) inp.addEventListener('input', () => calcFila(index));
        });
    }

    const parseVal = (id) => {
        const val = document.getElementById(id)?.value;
        return window.parseNum ? window.parseNum(val) : (parseFloat(String(val || 0).replace(/,/g, '')) || 0);
    };

    function calcFila(index, skipGuardar = false) {
        const qty = parseVal(`${prefix}-qty-${index}`);
        const kg = Math.round(materiales[index].valor * qty);
        const kdEl = document.getElementById(`${prefix}-kg-${index}`);
        if (kdEl) {
            kdEl.innerText = kg.toLocaleString('es-MX');
            kdEl.style.color = '#000000';
            kdEl.style.fontWeight = '800';
        }
        calcGlobal();
        if (!skipGuardar) guardar();
    }

    function calcGlobal() {
        let totPz = 0, totKg = 0;
        materiales.forEach((item, i) => {
            const qty = parseVal(`${prefix}-qty-${i}`);
            totPz += qty;
            totKg += item.valor * qty;
        });
        const qtyId = prefix === 'historial' ? 'global-qty' : `${prefix}-global-qty`;
        const totId = prefix === 'historial' ? 'global-total' : `${prefix}-global-total`;
        const elQty = document.getElementById(qtyId);
        const elTot = document.getElementById(totId);
        if (elQty) elQty.innerText = Math.round(totPz).toLocaleString('es-MX');
        if (elTot) elTot.innerText = Math.round(totKg).toLocaleString('es-MX');
    }

    async function guardar() {
        const estado = [];
        materiales.forEach((_, i) => {
            const qty = parseVal(`${prefix}-qty-${i}`);
            if (qty > 0) estado.push({ index: i, qty });
        });
        localStorage.setItem(storageKey, JSON.stringify(estado));
        if (typeof db !== 'undefined' && db !== null) {
            try {
                await db.collection('configuraciones').doc(firestoreDoc).set({
                    estado,
                    ultimaActualizacion: firebase.firestore.FieldValue.serverTimestamp()
                });
            } catch (e) { }
        }
        if (window.actualizarDashboardStats) window.actualizarDashboardStats();
        if (window.actualizarVistaMódulos) window.actualizarVistaMódulos();
        if (prefix === 'historial' && window.actualizarPanelRecuperacion) window.actualizarPanelRecuperacion();
    }

    async function cargar() {
        let estado = null;
        if (typeof db !== 'undefined' && db !== null) {
            try {
                const snap = await db.collection('configuraciones').doc(firestoreDoc).get();
                if (snap.exists) estado = snap.data().estado;
            } catch (e) { }
        }
        if (!estado) estado = JSON.parse(localStorage.getItem(storageKey)) || [];

        estado.forEach(item => {
            const inp = document.getElementById(`${prefix}-qty-${item.index}`);
            if (inp) {
                inp.value = item.qty || 0;
                const kdEl = document.getElementById(`${prefix}-kg-${item.index}`);
                if (kdEl) kdEl.innerText = Math.round(materiales[item.index].valor * item.qty).toLocaleString('es-MX');
            }
        });
        calcGlobal();
        if (window.actualizarDashboardStats) window.actualizarDashboardStats();
    }

    // Normalización de proceso para comparaciones robustas
    const normalizarProceso = p => String(p || '').toLowerCase().trim();

    // Exponer función de transferencia global
    const fnName = `transferirA_${prefix.charAt(0).toUpperCase() + prefix.slice(1)}`;
    window[fnName] = async function (silencioso = false) {
        const datos = await leerDatosAdmin();
        if (!datos || datos.length === 0) {
            if (!silencioso) alert('No hay datos en Registro de Producción.');
            return;
        }

        const { fechaLunesISO, fechaSabadoISO } = obtenerFechasSemanaActiva(datos);
        const validNorm = validProcesos.map(p => normalizarProceso(p));

        // Filtrar registros acumulados del proceso pertenecientes a la semana activa (Lunes a Sábado)
        let registrosModulo = datos.filter(r => {
            if (!r || !r.proceso) return false;
            const fiso = normalizarFechaISO(r.fecha);
            const enProceso = validNorm.includes(normalizarProceso(r.proceso));
            const enSemana = fiso ? (fiso >= fechaLunesISO && fiso <= fechaSabadoISO) : true;
            return enProceso && enSemana;
        });

        // Fallback: Si no hay registros estrictamente en esa semana, usar todos los registros del proceso
        if (registrosModulo.length === 0) {
            registrosModulo = datos.filter(r => r && r.proceso && validNorm.includes(normalizarProceso(r.proceso)));
        }

        if (registrosModulo.length === 0 && !silencioso) {
            alert(`No se encontraron registros de producción para este proceso.`);
            return;
        }

        // Agrupar piezas totales acumuladas de Lunes a Sábado por cada producto de materiales
        const totalesPorProducto = {};
        registrosModulo.forEach(registro => {
            const prodNorm = normalizarProducto(registro.producto || registro.Producto || '');
            const pzVal = parseInt(registro.piezas || registro.Piezas || registro.qty || registro.cantidad || 0) || 0;
            totalesPorProducto[prodNorm] = (totalesPorProducto[prodNorm] || 0) + pzVal;
        });

        let transferidos = 0;
        materiales.forEach((m, idx) => {
            const prodNorm = normalizarProducto(m.producto);
            const inp = document.getElementById(`${prefix}-qty-${idx}`);
            if (inp) {
                if (totalesPorProducto.hasOwnProperty(prodNorm)) {
                    // Establecer la suma total acumulada semanal de este producto
                    inp.value = totalesPorProducto[prodNorm];
                    calcFila(idx, true);
                    transferidos++;
                } else if (!silencioso) {
                    inp.value = 0;
                    calcFila(idx, true);
                }
            }
        });

        calcGlobal();
        await guardar();
        if (window.actualizarDashboardStats) window.actualizarDashboardStats();

        if (!silencioso) {
            if (transferidos > 0) {
                alert(`✅ Transferencia semanal exitosa (${transferidos} producto(s) actualizados con los totales acumulados de la semana del Lunes al Sábado).`);
                // Navegar directamente al historial y activar el tab correcto
                if (window.showAdminPanel) window.showAdminPanel('historial-container');
                // Activar el item del menú
                document.querySelectorAll('.admin-nav-item').forEach(l => l.classList.remove('active'));
                const menuHistorial = document.getElementById('menu-historial');
                if (menuHistorial) menuHistorial.classList.add('active');
                // Activar el tab específico directamente
                const targetBtn = document.querySelector(`.historial-tab-btn[data-tab="${tabTarget}"]`);
                const targetPanel = document.getElementById(tabTarget);
                if (targetBtn && targetPanel) {
                    document.querySelectorAll('.historial-tab-btn').forEach(b => b.classList.remove('active'));
                    document.querySelectorAll('.historial-tab-content').forEach(c => c.classList.remove('active'));
                    targetBtn.classList.add('active');
                    targetPanel.classList.add('active');
                    // Sync dropdown select
                    const selectEl = document.getElementById('historial-tab-select');
                    if (selectEl) selectEl.value = tabTarget;
                }
            } else {
                alert('No se encontraron productos coincidentes para actualizar en la semana activa.');
            }
        }
    };

    // Inicializar
    cargar();
}

// ─── DOMContentLoaded ──────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {

    // Recuperación → proceso "Selección, Limpieza, Flejado y Empaque"
    crearModulo({
        tbodyId: 'inventory-body',
        prefix: 'historial',
        materiales: tablaGlobalProductos,
        storageKey: 'rymco_recuperacion_db',
        firestoreDoc: 'estado_recuperacion',
        validProcesos: ['Selección, Limpieza, Flejado y Empaque'],
        tabTarget: 'tab-recuperacion'
    });

    // Acondicionamiento → "Preparación y/o Acondicionamiento de venta"
    crearModulo({
        tbodyId: 'acondicionamiento-body',
        prefix: 'acond',
        materiales: tablaGlobalProductos,
        storageKey: 'rymco_acondicionamiento_db',
        firestoreDoc: 'estado_acondicionamiento',
        validProcesos: ['Preparación y/o Acondicionamiento de venta'],
        tabTarget: 'tab-tabla1'
    });

    // Conformado → "Conformado, Rimado y Pintura"
    crearModulo({
        tbodyId: 'conformado-body',
        prefix: 'conformado',
        materiales: tablaGlobalProductos,
        storageKey: 'rymco_conformado_db',
        firestoreDoc: 'estado_conformado',
        validProcesos: ['Conformado, Rimado y Pintura'],
        tabTarget: 'tab-tabla2'
    });

    // Re-Galvanizar → "Selección de tubo para re-galvanizar"
    crearModulo({
        tbodyId: 'regalvanizar-body',
        prefix: 'regalvanizar',
        materiales: tablaGlobalProductos,
        storageKey: 'rymco_regalvanizar_db',
        firestoreDoc: 'estado_regalvanizar',
        validProcesos: ['Selección de tubo para re-galvanizar'],
        tabTarget: 'tab-tabla3'
    });

    // Alias globales para invocación externa desde inventario.js
    window.transferirA_Recuperacion = window.transferirA_Historial;
    window.transferirA_Acondicionamiento = window.transferirA_Acond;
    window.transferirA_ReGalvanizar = window.transferirA_Regalvanizar;

});