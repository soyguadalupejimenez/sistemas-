// ==========================================================================
// RECUPERACIÓN – RYMCO S.A.
// Muestra datos de bitácora, historial de movimientos, respaldos por año/mes/semana
// ==========================================================================

const PROCESO_RECUPERACION = 'Selección, Limpieza, Flejado y Empaque';

// ── 1. Obtener todos los registros del proceso de Recuperación de la semana activa ────────────────
function obtenerRegistrosRecuperacion() {
    let rawDatos = [];
    // Comentado para forzar que sea 100% Firebase

    if (Array.isArray(window.cacheRegistrosFirebase)) {
        window.cacheRegistrosFirebase.forEach(r => rawDatos.push(r));
    }

    const normalizarFechaISO = (typeof window !== 'undefined' && window.normalizarFechaISO) ? window.normalizarFechaISO : ((f) => f ? String(f).split('T')[0] : null);

    const vistos = new Set();
    const unicos = [];
    rawDatos.forEach(r => {
        if (!r) return;
        const proc = String(r.proceso || r.Proceso || '').toLowerCase();
        if (proc !== 'selección, limpieza, flejado y empaque' && !proc.includes('recuperaci')) return;
        if (window.esRegistroEliminado && window.esRegistroEliminado(r)) return;

        const fiso = normalizarFechaISO(r.fecha);
        const keyId = r.firebaseId || r.id || (fiso + '_' + (r.producto||'') + '_' + (r.piezas||''));
        if (keyId && vistos.has(keyId)) return;
        if (keyId) vistos.add(keyId);
        unicos.push({ ...r, fecha: fiso || r.fecha });
    });

    return unicos;
}

// ── 2. Calcular kilos de la semana actual ─────────────────────────────────────
function obtenerKilosSemanaActual() {
    const registros = obtenerRegistrosRecuperacion();
    return registros.reduce((sum, r) => sum + (parseFloat(r.kilos) || 0), 0);
}

// ── 3. Renderizar tabla de datos actuales de la semana activa ─────────────────
function renderTablaRecuperacionActual() {
    const tbody = document.getElementById('tbody-recu-actual');
    if (!tbody) return;

    const registros = obtenerRegistrosRecuperacion();
    const hoy = new Date();
    const lunes = (typeof window.getLunesSemanaActiva === 'function') ? window.getLunesSemanaActiva(hoy) : new Date(hoy);
    const sabado = new Date(lunes);
    sabado.setDate(lunes.getDate() + 5);

    const mesesNombres = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    const rangoTexto = `Semana del Lunes ${lunes.getDate()} al Sábado ${sabado.getDate()} de ${mesesNombres[lunes.getMonth()]} de ${lunes.getFullYear()}`;

    const elSub = document.getElementById('recu-semana-subtitulo');
    if (elSub) elSub.textContent = rangoTexto;

    let totalPz = 0, totalKg = 0;

    if (registros.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3" style="text-align:center; padding:24px; color:#94a3b8;">No hay registros acumulados en Recuperación para la semana activa.</td></tr>`;
    } else {
        const ordenados = [...registros].sort((a, b) => (a.fecha || '').localeCompare(b.fecha || ''));

        tbody.innerHTML = ordenados.map(r => {
            const pz = parseInt(r.piezas || 0);
            const kg = parseFloat(r.kilos || 0);
            totalPz += pz;
            totalKg += kg;

            return `<tr style="border-bottom:1px solid #e2e8f0; transition:background 0.2s;">
                <td style="padding:11px 14px; font-weight:700; color:#000000 !important; font-size:0.95rem;">${r.producto || '-'}</td>
                <td style="padding:11px 14px; text-align:center; font-weight:700; color:#0284c7 !important; font-size:0.95rem;">${pz.toLocaleString('es-MX')}</td>
                <td style="padding:11px 14px; text-align:center; color:#059669 !important; font-weight:700; font-size:0.95rem;">${kg.toLocaleString('es-MX', {minimumFractionDigits:0, maximumFractionDigits:3})} kg</td>
            </tr>`;
        }).join('');

        // Fila TOTALES SEMANALES COMPLETOS (Lunes a Sábado)
        tbody.innerHTML += `<tr style="background:#07222e; color:white; font-weight:700; border-top:2px solid var(--accent, #06B6D4);">
            <td style="padding:12px 14px; text-align:right; text-transform:uppercase; font-size:0.85rem; letter-spacing:.05em; color:#FFFFFF;">TOTAL RECUPERACIÓN:</td>
            <td style="padding:12px 14px; text-align:center; color:#fef08a; font-size:1.1rem; font-weight:800;">${totalPz.toLocaleString('es-MX')} pz</td>
            <td style="padding:12px 14px; text-align:center; color:#fef08a; font-size:1.1rem; font-weight:800;">${totalKg.toLocaleString('es-MX', {minimumFractionDigits:0, maximumFractionDigits:3})} kg</td>
        </tr>`;
    }

    // Actualizar tarjetas de resumen
    const elPz = document.getElementById('recu-total-piezas');
    const elKg = document.getElementById('recu-total-kilos');
    const elSem = document.getElementById('recu-kilos-semana');
    const elDash = document.getElementById('dash-recuperacion-semana');

    if (elPz) elPz.textContent = totalPz.toLocaleString('es-MX') + ' pz';
    if (elKg) elKg.textContent = totalKg.toLocaleString('es-MX', {minimumFractionDigits:0, maximumFractionDigits:3}) + ' kg';
    if (elSem) elSem.textContent = totalKg.toLocaleString('es-MX', {minimumFractionDigits:0, maximumFractionDigits:3}) + ' kg';
    if (elDash) elDash.textContent = totalKg.toLocaleString('es-MX', {minimumFractionDigits:0, maximumFractionDigits:3}) + ' kg';

    return { totalPz, totalKg, kilosSem: totalKg };
}

// ── 4. Historial de movimientos (Audit Log) ───────────────────────────────────
function registrarMovimientoRecu(accion, detalle, piezas, kilos) {
    const historial = JSON.parse(localStorage.getItem('rymco_recu_historial')) || [];
    historial.unshift({
        fechaHora: new Date().toLocaleString('es-MX'),
        accion,
        detalle,
        piezas: piezas || 0,
        kilos: kilos || 0
    });
    if (historial.length > 200) historial.splice(200);
    localStorage.setItem('rymco_recu_historial', JSON.stringify(historial));
}

function renderHistorialMovimientos() {
    const tbody = document.getElementById('tbody-recu-historial');
    if (!tbody) return;

    const historial = JSON.parse(localStorage.getItem('rymco_recu_historial')) || [];
    if (historial.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:20px; color:#94a3b8;">Sin movimientos registrados.</td></tr>';
        return;
    }

    const accionColor = { 'Transferencia': '#38bdf8', 'Respaldo guardado': '#34d399', 'Limpieza': '#f87171', 'Carga inicial': '#818cf8' };
    tbody.innerHTML = historial.map(m => {
        const color = accionColor[m.accion] || '#94a3b8';
        return `<tr style="border-bottom:1px solid rgba(255,255,255,0.08); transition:background 0.2s;">
            <td style="padding:10px 12px; font-size:0.85rem; color:#94a3b8; white-space:nowrap;">${m.fechaHora}</td>
            <td style="padding:10px 12px;"><span style="background:${color}25; color:${color}; border:1px solid ${color}50; padding:3px 10px; border-radius:12px; font-size:0.8rem; font-weight:700;">${m.accion}</span></td>
            <td style="padding:10px 12px; font-size:0.88rem; color:#ffffff;">${m.detalle}</td>
            <td style="padding:10px 12px; text-align:center; font-weight:700; color:#38bdf8;">${(m.piezas||0).toLocaleString('es-MX')}</td>
            <td style="padding:10px 12px; text-align:center; color:#34d399; font-weight:700;">${(m.kilos||0).toLocaleString('es-MX', {minimumFractionDigits:0, maximumFractionDigits:3})} kg</td>
        </tr>`;
    }).join('');
}

// ── 5. Guardar respaldo completo de la semana ─────────────────────────────────
async function procesarRespaldoAdmin() {
    const anioEl = document.getElementById('respaldo-anio');
    const mesEl = document.getElementById('respaldo-mes');
    const semanaEl = document.getElementById('respaldo-semana');

    const anio = anioEl ? anioEl.value : new Date().getFullYear().toString();
    const mes = mesEl ? mesEl.value : '-';
    const semana = semanaEl ? semanaEl.value : '-';

    const registros = obtenerRegistrosRecuperacion();
    if (registros.length === 0) {
        alert('⚠️ No hay registros del proceso de Recuperación en la semana activa para respaldar.');
        return;
    }

    // Construir el objeto de respaldo con el total acumulado de la semana
    const totPz = registros.reduce((s, r) => s + parseInt(r.piezas || 0), 0);
    const totKg = registros.reduce((s, r) => s + parseFloat(r.kilos || 0), 0);

    const id = `recu_${anio}_${mes}_${semana.replace(/\s+/g, '')}`.toLowerCase();
    const obj = {
        id, anio, mes, semana,
        tipoRespaldo: 'Semana Completa (Lunes a Sábado)',
        fechaDeCierre: new Date().toLocaleString('es-MX'),
        timestamp: new Date().toISOString(),
        totalPiezasSemana: totPz,
        totalKilosSemana: totKg,
        registrosGuardados: registros.map(r => ({
            producto: r.producto || '-',
            piezas: parseInt(r.piezas || 0),
            kilos: parseFloat(r.kilos || 0),
            turno: r.turno || '-',
            fecha: r.fecha || '-',
            trabajadores: r.trabajadores || r.trabajador || '-',
            seccion: 'Recuperación Semanal'
        }))
    };

    // Guardar local
    const hist = JSON.parse(localStorage.getItem('rymco_historico_admin_global')) || {};
    hist[id] = obj;
    localStorage.setItem('rymco_historico_admin_global', JSON.stringify(hist));

    // Guardar en Firebase
    if (typeof db !== 'undefined' && db !== null) {
        try {
            await db.collection('respaldos_recuperacion').doc(id).set(obj, { merge: true });
        } catch (e) {
            console.warn('No se pudo guardar respaldo en Firebase:', e);
        }
    }

    // Registrar movimiento en historial
    registrarMovimientoRecu('Respaldo guardado', `Semanal ${anio} – ${mes} (${semana}) · ${registros.length} registros acumulados`, totPz, totKg);

    alert(`✅ Respaldo Semanal Guardado: ${anio} – ${mes} (${semana})\n📦 Total acumulado de la semana: ${registros.length} registros · ${totPz.toLocaleString('es-MX')} pz · ${totKg.toLocaleString('es-MX', {minimumFractionDigits:0})} kg`);

    actualizarSelectorDeArchivos();
    renderHistorialMovimientos();
}

// ── 6. Selector de archivos ───────────────────────────────────────────────────
async function actualizarSelectorDeArchivos() {
    const selector = document.getElementById('selector-historico-admin');
    if (!selector) return;

    let hist = JSON.parse(localStorage.getItem('rymco_historico_admin_global')) || {};

    // Intentar cargar de Firebase
    if (typeof db !== 'undefined' && db !== null) {
        try {
            const snap = await db.collection('respaldos_recuperacion').get();
            snap.forEach(doc => {
                const data = doc.data();
                if (data && data.id) hist[data.id] = data;
            });
            localStorage.setItem('rymco_historico_admin_global', JSON.stringify(hist));
        } catch (e) {
            console.warn('No se pudieron cargar respaldos de Firebase:', e);
        }
    }

    const valor = selector.value;
    selector.innerHTML = '<option value="">-- Selecciona un respaldo guardado para revisar --</option>';
    Object.values(hist).sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || '')).forEach(item => {
        const opt = document.createElement('option');
        opt.value = item.id;
        opt.textContent = `${item.anio || ''} – ${item.mes} (${item.semana}) · Cierre: ${item.fechaDeCierre}`;
        selector.appendChild(opt);
    });
    selector.value = valor;
}

// ── 7. Cargar tabla de respaldo histórico ─────────────────────────────────────
function cargarTablaHistoricaAdmin() {
    const selector = document.getElementById('selector-historico-admin');
    const tbody = document.querySelector('#tabla-archivo-recuperacion tbody');
    if (!tbody || !selector) return;

    const clave = selector.value;
    if (!clave) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:20px; color:#777;">Selecciona un respaldo para visualizar.</td></tr>';
        return;
    }

    const hist = JSON.parse(localStorage.getItem('rymco_historico_admin_global')) || {};
    const archivo = hist[clave];
    tbody.innerHTML = '';

    if (archivo && archivo.registrosGuardados && archivo.registrosGuardados.length > 0) {
        let totPz = 0, totKg = 0;
        archivo.registrosGuardados.forEach(r => {
            totPz += parseInt(r.piezas || 0);
            totKg += parseFloat(r.kilos || 0);
            const tr = document.createElement('tr');
            tr.style.borderBottom = '1px solid rgba(255,255,255,0.08)';
            tr.innerHTML = `
                <td style="padding:10px 12px; font-weight:700; color:#000000 !important;">${r.producto || '-'}</td>
                <td style="padding:10px 12px; text-align:center; font-weight:700; color:#0284c7 !important;">${(r.piezas||0).toLocaleString('es-MX')}</td>
                <td style="padding:10px 12px; text-align:center; color:#059669 !important; font-weight:700;">${(r.kilos||0).toLocaleString('es-MX', {minimumFractionDigits:0, maximumFractionDigits:3})} kg</td>
                <td style="padding:10px 12px; color:#475569 !important;">${r.seccion || 'Recuperación'}</td>`;
            tbody.appendChild(tr);
        });

        const trTot = document.createElement('tr');
        trTot.style.cssText = 'background:#07222e; color:white; font-weight:700; border-top:2px solid var(--accent, #06B6D4);';
        trTot.innerHTML = `
            <td style="padding:12px; text-align:right; text-transform:uppercase; font-size:0.85rem; letter-spacing:.05em; color:#FFFFFF;">TOTAL RESPALDO:</td>
            <td style="padding:12px; text-align:center; color:#fef08a; font-size:1.1rem; font-weight:800;">${totPz.toLocaleString('es-MX')}</td>
            <td style="padding:12px; text-align:center; color:#fef08a; font-size:1.1rem; font-weight:800;">${totKg.toLocaleString('es-MX', {minimumFractionDigits:0, maximumFractionDigits:3})} kg</td>
            <td style="padding:12px;">–</td>`;
        tbody.appendChild(trTot);
    } else {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:20px; color:#f87171;">El respaldo seleccionado no contiene registros válidos.</td></tr>';
    }
}

// ── 8. Función de transferencia desde Control Inventario ─────────────────────
window.enviarARecuperacion = function() {
    const local = JSON.parse(localStorage.getItem('rymco_db_admin')) || [];
    const recu = local.filter(r => r.proceso === PROCESO_RECUPERACION);

    if (recu.length === 0) {
        alert('⚠️ No hay registros del proceso "Selección, Limpieza, Flejado y Empaque" para transferir a Recuperación.');
        return;
    }

    const totPz = recu.reduce((s, r) => s + parseInt(r.piezas || 0), 0);
    const totKg = recu.reduce((s, r) => s + parseFloat(r.kilos || 0), 0);

    if (confirm(`¿Transferir ${recu.length} registros a Recuperación?\n📦 ${totPz.toLocaleString('es-MX')} pz · ${totKg.toLocaleString('es-MX', {minimumFractionDigits:0})} kg`)) {
        registrarMovimientoRecu('Transferencia', `Desde Control Inventario · ${recu.length} registros`, totPz, totKg);
        renderHistorialMovimientos();
        renderTablaRecuperacionActual();
        alert(`✅ Transferencia exitosa. Se registraron ${recu.length} movimientos en el historial de Recuperación.`);
    }
};

// ── 9. Función principal de actualización del panel ──────────────────────────
window.actualizarPanelRecuperacion = function() {
    renderTablaRecuperacionActual();
    renderHistorialMovimientos();
    actualizarSelectorDeArchivos();
};

// ── 10. Inicialización ─────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    // Botón Actualizar dentro de Recuperación
    const btnActualizar = document.getElementById('btn-recu-actualizar');
    if (btnActualizar) {
        btnActualizar.addEventListener('click', () => {
            renderTablaRecuperacionActual();
            renderHistorialMovimientos();
            actualizarSelectorDeArchivos();
        });
    }

    // Botón Vaciar vista dentro de Recuperación (Silencioso e Instantáneo)
    const btnVaciarRecu = document.getElementById('btn-recu-vaciar');
    if (btnVaciarRecu) {
        btnVaciarRecu.addEventListener('click', () => {
            // Limpiar inputs del panel de recuperación
            const inputsRecu = document.querySelectorAll('#recuperacion-container input');
            inputsRecu.forEach(inp => inp.value = '');

            // Guardar timestamp de vaciado para ocultar la vista activa
            const clearedIds = new Set(JSON.parse(localStorage.getItem('rymco_control_inventario_cleared_ids') || '[]'));
            const recuRegs = (typeof obtenerRegistrosRecuperacion === 'function') ? obtenerRegistrosRecuperacion() : [];
            recuRegs.forEach(r => {
                const id = r.id || r.firebaseId;
                if (id) clearedIds.add(id);
            });
            localStorage.setItem('rymco_control_inventario_cleared_ids', JSON.stringify(Array.from(clearedIds)));
            localStorage.setItem('rymco_control_inventario_cleared_at', Date.now().toString());

            renderTablaRecuperacionActual();
            renderHistorialMovimientos();
            const elDash = document.getElementById('dash-recuperacion-semana');
            if (elDash) elDash.textContent = '0 kg';
        });
    }

    // Botón "🔄 Recuperación" en Control Inventario
    const btnEnviarRecu = document.getElementById('btn-admin-enviar-recuperacion');
    if (btnEnviarRecu) {
        btnEnviarRecu.addEventListener('click', window.enviarARecuperacion);
    }

    // Carga inicial de la card del dashboard
    const kilosSem = obtenerKilosSemanaActual();
    const elDash = document.getElementById('dash-recuperacion-semana');
    if (elDash) elDash.textContent = kilosSem.toLocaleString('es-MX', {minimumFractionDigits:0, maximumFractionDigits:3}) + ' kg';

    // Registro del primer acceso si aplica
    actualizarSelectorDeArchivos();
});