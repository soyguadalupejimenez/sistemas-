const tablaPesos = [
    // ── VERDE ────────────────────────────────────────────
    { producto: '1/2" verde', valor: 1.262 },
    { producto: '3/4" verde', valor: 1.672 },
    { producto: '1" Verde', valor: 3.2 },
    { producto: '1 1/4" verde', valor: 4.135 },
    { producto: '1 1/2" verde', valor: 4.91 },
    { producto: '2" verde', valor: 6.24 },
    { producto: '2 1/2" Verde', valor: 9.80 },
    { producto: '3" verde', valor: 11.93 },
    { producto: '3 1/2" Verde', valor: 15.84 },
    { producto: '4" Verde', valor: 17.83 },

    // ── AMARILLA ─────────────────────────────────────────
    { producto: '1/2" Amarilla', valor: 2.154 },
    { producto: '3/4" Amarilla', valor: 2.721 },
    { producto: '1" Amarilla', valor: 4.143 },
    { producto: '1 1/4" Amarilla', valor: 5.254 },
    { producto: '1½" Amarilla', valor: 6.2 },
    { producto: '2" Amarilla', valor: 9.379 },
    { producto: '2 1/2" Amarilla', valor: 16.186 },
    { producto: '3" Amarilla', valor: 19.267 },
    { producto: '4" Amarilla', valor: 24.992 },

    // ── AZUL ─────────────────────────────────────────────
    { producto: '1/2" azul', valor: 0.90 },
    { producto: '1½" azul', valor: 0.9 },

    // ── EMT ──────────────────────────────────────────────
    { producto: '1/2" EMT', valor: 1.36 },
    { producto: '3/4" EMT', valor: 2.09 },
    { producto: '1" EMT', valor: 3.06 },
    { producto: '1 1/4" EMT', valor: 4.55 },
    { producto: '1 1/2" EMT', valor: 5.283 },
    { producto: '2" EMT', valor: 6.71 },
    { producto: '2 1/2" EMT', valor: 9.8 },
    { producto: '3" EMT', valor: 11.93 },
    { producto: '3 1/2" EMT', valor: 15.84 },
    { producto: '4" EMT', valor: 17.83 },

    // ── IMC ──────────────────────────────────────────────
    { producto: '1/2" IMC', valor: 2.85 },
    { producto: '3/4" IMC', valor: 3.81 },
    { producto: '1" IMC', valor: 5.47 },
    { producto: '1 1/4" IMC', valor: 7.10 },
    { producto: '1 1/2" IMC', valor: 8.21 },
    { producto: '2" IMC', valor: 11.6 },
    { producto: '2 1/2" IMC', valor: 20.004 },
    { producto: '3" IMC', valor: 24.046 },
    { producto: '3 1/2" IMC', valor: 28.068 },
    { producto: '4" IMC', valor: 31.752 },

    // ── PVC PESADO (V Y G) ────────────────────────────────
    { producto: '1/2" PVC Pesado', valor: 0.49 },
    { producto: '3/4" PVC Pesado', valor: 0.61 },
    { producto: '1" PVC Pesado', valor: 0.78 },
    { producto: '1 1/4" PVC Pesado', valor: 1.05 },
    { producto: '1 1/2" PVC Pesado', valor: 1.45 },
    { producto: '2" PVC Pesado', valor: 2.15 },
    { producto: '2 1/2" PVC Pesado', valor: 3.1 },
    { producto: '3" PVC Pesado', valor: 3.90 },
    { producto: '4" PVC Pesado', valor: 5.3 },

    // ── PVC LIGERO ────────────────────────────────────────
    { producto: '1/2" PVC LIGERO', valor: 0.24 },
    { producto: '3/4" PVC LIGERO', valor: 0.32 },
    { producto: '1" PVC LIGERO', valor: 0.49 },
    { producto: '1 1/4" PVC LIGERO', valor: 0.74 },
    { producto: '1 1/2" PVC LIGERO', valor: 0.92 },
    { producto: '2" PVC LIGERO', valor: 1.462 },

    // ── ALUMINIO ──────────────────────────────────────────
    { producto: '1/2" Aluminio', valor: 1.34 },
    { producto: '3/4" Aluminio', valor: 1.78 },
    { producto: '1" Aluminio', valor: 2.70 },
    { producto: '1 1/4" Aluminio', valor: 3.25 },
    { producto: '1 1/2" Aluminio', valor: 4.02 },
    { producto: '2" Aluminio', valor: 5.38 },
    { producto: '2 1/2" Aluminio', valor: 8.50 },
    { producto: '3" Aluminio', valor: 11.17 },
    { producto: '3 1/2" Aluminio', valor: 15.58 },
    { producto: '4" Aluminio', valor: 28.59 },

    // ── RÍGIDO 3.05 MTS ───────────────────────────────────
    { producto: '1/2" rig a 3.05', valor: 3.72 },
    { producto: '3/4" rig a 3.05', valor: 4.94 },
    { producto: '1" rig a 3.05', valor: 7.303 },
    { producto: '1 1/4" rig a 3.05', valor: 9.888 },
    { producto: '1 1/2" rig a 3.05', valor: 11.93 },
    { producto: '2" rig a 3.05', valor: 15.876 },
    { producto: '2 1/2" rig a 3.05', valor: 25.36 },
    { producto: '3" rig a 3.05', valor: 32.98 },
    { producto: '3 1/2" rig a 3.05', valor: 39.917 },
    { producto: '4" rig a 3.05', valor: 46.72 },
    { producto: '6" rig a 3.05', valor: 87.60 },

    // ── RÍGIDO 3.20 MTS ───────────────────────────────────
    { producto: '1/2" rig a 3.20', valor: 4.06 },
    { producto: '3/4" rig a 3.20', valor: 5.39 },
    { producto: '1" rig a 3.20', valor: 7.85 },
    { producto: '1 1/4" rig a 3.20', valor: 10.98 },
    { producto: '1 1/2" rig a 3.20', valor: 13 },
    { producto: '2" rig a 3.20', valor: 17.34 },
    { producto: '2 1/2" rig a 3.20', valor: 27.59 },
    { producto: '3" rig a 3.20', valor: 36.19 },
    { producto: '3 1/2" rig a 3.20', valor: 43.38 },
    { producto: '4" rig a 3.20', valor: 51.38 },

    // ── ESPECIALES ────────────────────────────────────────
    { producto: '1 1/4" especial', valor: 3.496 },
    { producto: '1 1/4" ESP. A 1.5 MTS', valor: 1.748 },
    { producto: '1 1/4" ESP. A 2 MTS', valor: 2.331 },
    { producto: '1 1/4" ESP. A 3 MTS', valor: 3.496 },
    { producto: '1 1/4" ESP. A 4 MTS', valor: 4.637 },

    // ── PVC GRIS ──────────────────────────────────────────
    { producto: '1/2" PVC GRIS TA', valor: 0.61 },
    { producto: '3/4" PVC GRIS', valor: 0.61 },
    { producto: '3/4" PVC GRIS TA', valor: 0.78 },
    { producto: '1" PVC GRIS TA', valor: 5.3 },
    { producto: '1 1/4" PVC GRIS TA', valor: 0.49 },
    { producto: '1 1/2" PVC GRIS TA', valor: 1.032 },
    // ── PVC C40 ───────────────────────────────────────────
    { producto: '1/2" PVC C40', valor: 2.15 },
    { producto: '3/4" PVC C40', valor: 0.9 },
    { producto: '1" PVC C40', valor: 3.9 },
    { producto: '1 1/4" PVC C40', valor: 0.9 },
    { producto: '1 1/2" PVC C40', valor: 0.9 },
    { producto: '2" PVC C40', valor: 1.78 },
    { producto: '2 1/2" PVC C40', valor: 2.7 },
    { producto: '3" PVC C40', valor: 5.38 },
    { producto: '4" PVC C40', valor: 11.17 },

    // ── PVC C80 ───────────────────────────────────────────
    { producto: '1/2" PVC C80', valor: 3.25 },
    { producto: '3/4" PVC C80', valor: 4.02 },
    { producto: '1" PVC C80', valor: 28.59 },
    { producto: '1 1/4" PVC C80', valor: 0.9 },
    { producto: '1 1/2" PVC C80', valor: 8.1024 },
    { producto: '2" PVC C80', valor: 0.753 },
    { producto: '2 1/2" PVC C80', valor: 0.998 },
    { producto: '3" PVC C80', valor: 1.484 },
    { producto: '4" PVC C80', valor: 2.015 },

    // ── ORTOPEDICO ────────────────────────────────────────
    { producto: '3/4" Ortopedico', valor: 2.406 },
    { producto: '1" Ortopedico', valor: 3.4 },

    // ── A53 ───────────────────────────────────────────────
    { producto: '1/2" A53', valor: 1.45 },

    // ── VARILLA ROSCADA ───────────────────────────────────
    { producto: '1/4" varilla roscada', valor: 0.5442 },
    { producto: '1/2" varilla roscada', valor: 2.389 },

    // ── TA53 ──────────────────────────────────────────────
    { producto: 'TA53 1/2" (CED-40) Galvanizado Ros', valor: 8.1024 },
    { producto: 'TA53 1" (CED-40) Negro Liso', valor: 15.9872 },
    { producto: 'TA53 4" (CED-40) Negro Liso', valor: 102.62 },
    { producto: 'TA53 4" (CED-40) Rojo Ranurado', valor: 102.62 },

    // ── UNICANAL ──────────────────────────────────────────
    { producto: 'Unicanal sólido 4x2 c.16', valor: 3.059 },
    { producto: 'Unicanal perforado 4x2 c.16', valor: 3.059 },
    { producto: 'Unicanal sólido 4x4 c.16', valor: 4.88 },
    { producto: 'Unicanal perforado 4x4 c.16', valor: 4.88 },
    { producto: 'Unicanal sólido 4x2 c.14', valor: 4.46 },
    { producto: 'Unicanal perforado 4x2 c.14', valor: 4.46 },
    { producto: 'Unicanal sólido 4x4 c.14', valor: 6.84 },
    { producto: 'Unicanal perforado 4x4 c.14', valor: 5.60 }
];

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('bitacora-form');
    const inputFecha = document.getElementById('fecha');
    const selectTurno = document.getElementById('turno');
    const selectProceso = document.getElementById('proceso');
    const inputProducto = document.getElementById('producto');
    const inputPiezas = document.getElementById('piezas');
    const inputTrabajador = document.getElementById('trabajador');
    const trabajadoresContainer = document.getElementById('trabajadores-lista-container');
    const trabajadoresTbody = document.getElementById('trabajadores-tbody');
    const btnFinalizarTurno = document.getElementById('btn-finalizar-turno');

    let trabajadoresActivos = {}; // Key: "Turno|Proceso", Value: Array of worker names/IDs
    let registrosTemporalesOperador = [];
    let editandoRegistroId = null;

    function getFechaTrabajoAtrasada(date = new Date()) {
        const hoy = new Date(date);
        const diaSemana = hoy.getDay(); // 0=Dom, 1=Lun, 2=Mar, ..., 6=Sáb
        let diasRestar = 1; // Por defecto: ayer
        if (diaSemana === 1) diasRestar = 2; // Lunes -> Sábado (domingo NO se trabaja)
        if (diaSemana === 0) diasRestar = 2; // Domingo -> Sábado
        const fecha = new Date(hoy);
        fecha.setDate(hoy.getDate() - diasRestar);
        const yyyy = fecha.getFullYear();
        const mm = String(fecha.getMonth() + 1).padStart(2, '0');
        const dd = String(fecha.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
    }

    function guardarBorradoresLocal() {
        try {
            localStorage.setItem('rymco_bitacora_draft_registros', JSON.stringify(registrosTemporalesOperador || []));
            localStorage.setItem('rymco_bitacora_draft_trabajadores', JSON.stringify(trabajadoresActivos || {}));
        } catch (e) {
            console.warn("No se pudo guardar borrador en localStorage:", e);
        }
    }

    function cargarBorradoresLocal() {
        try {
            const rawRegs = localStorage.getItem('rymco_bitacora_draft_registros');
            if (rawRegs) {
                const regs = JSON.parse(rawRegs);
                if (Array.isArray(regs)) {
                    // Filtrar registros válidos
                    registrosTemporalesOperador = regs.filter(r => r && r.producto && Number(r.piezas) > 0);
                }
            }
            const rawTrabs = localStorage.getItem('rymco_bitacora_draft_trabajadores');
            if (rawTrabs) {
                const trabs = JSON.parse(rawTrabs);
                if (trabs && typeof trabs === 'object' && !Array.isArray(trabs)) {
                    trabajadoresActivos = trabs;
                }
            }
        } catch(e) {
            console.warn("Error leyendo borrador previo:", e);
            registrosTemporalesOperador = [];
            trabajadoresActivos = {};
        }
    }

    cargarBorradoresLocal();
    actualizarHistorialPantallaOperador();

    // Guardar borrador al minimizar, cambiar de pestaña o cerrar el navegador sin subir los datos aún
    document.addEventListener('visibilitychange', guardarBorradoresLocal);
    window.addEventListener('pagehide', guardarBorradoresLocal);
    window.addEventListener('beforeunload', guardarBorradoresLocal);

    if (inputFecha) {
        if (!inputFecha.value) {
            inputFecha.value = getFechaTrabajoAtrasada();
        }
    }

    // --- MANEJO DE TRABAJADORES ---
    const btnAgregarTrabajador = document.getElementById('btn-agregar-trabajador');

    if (btnAgregarTrabajador) {
        btnAgregarTrabajador.addEventListener('click', () => {
            agregarTrabajadorActivo();
        });
    }

    if (inputTrabajador) {
        inputTrabajador.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                agregarTrabajadorActivo();
            }
        });
    }

    function agregarTrabajadorActivo() {
        const turno = selectTurno.value;
        const proceso = selectProceso.value;
        if (!turno) {
            alert("Debe seleccionar primero su turno.");
            selectTurno.focus();
            return;
        }
        if (!proceso) {
            alert("Debe seleccionar primero su proceso.");
            selectProceso.focus();
            return;
        }

        const trabVal = inputTrabajador.value.trim();
        if (!trabVal) {
            alert("Por favor ingrese el número del trabajador.");
            inputTrabajador.focus();
            return;
        }
        if (!/^\d+$/.test(trabVal)) {
            alert('El número del trabajador debe contener solo dígitos.');
            inputTrabajador.focus();
            return;
        }
        if (trabVal.length > 5) {
            alert('El número del trabajador no puede tener más de 5 dígitos.');
            inputTrabajador.focus();
            return;
        }

        const key = `${turno}|${proceso}`;
        if (!trabajadoresActivos[key]) {
            trabajadoresActivos[key] = [];
        }

        if (trabajadoresActivos[key].includes(trabVal)) {
            alert("Este trabajador ya está asignado a este turno y proceso.");
            return;
        }

        trabajadoresActivos[key].push(trabVal);
        inputTrabajador.value = '';
        guardarBorradoresLocal();
        actualizarHistorialPantallaOperador();
    }

    window.eliminarTrabajadorActivo = (turno, proceso, nombre) => {
        const key = `${turno}|${proceso}`;
        if (trabajadoresActivos[key]) {
            trabajadoresActivos[key] = trabajadoresActivos[key].filter(w => w !== nombre);
            if (trabajadoresActivos[key].length === 0) {
                delete trabajadoresActivos[key];
            }
            guardarBorradoresLocal();
            actualizarHistorialPantallaOperador();
        }
    };

    // Normaliza texto: quita comillas, convierte ½→1/2, minúsculas
    function normText(s) {
        return String(s || '')
            .toLowerCase()
            .replace(/["""]/g, '')
            .replace(/½/g, '1/2')
            .replace(/\s+/g, ' ')
            .trim();
    }

    // Permite emparejar "11/4", "11/2", "21/2", "31/2" sin espacios
    function normCompact(s) {
        let str = normText(s);
        str = str.replace(/^(\d)(\d\/\d)/, '$1 $2');
        return str.replace(/\s+/g, '').trim();
    }

    function buscarProductoCoincidente(val) {
        if (!val) return null;
        const normV = normText(val);
        const compV = normCompact(val);

        // 1. Coincidencia exacta
        let match = tablaPesos.find(p => normText(p.producto) === normV);
        if (match) return match;

        // 2. Coincidencia sin espacio (ej. 11/4 verde -> 1 1/4" verde)
        match = tablaPesos.find(p => normCompact(p.producto) === compV);
        if (match) return match;

        return null;
    }

    if (inputProducto) {
        // Índice de elemento activo en el dropdown
        let autocompleteIdx = -1;

        function buildAutocomplete(val) {
            let listCont = document.getElementById("autocomplete-list");
            listCont.innerHTML = "";
            autocompleteIdx = -1;
            if (!val) return;

            const normVal = normText(val);
            const compVal = normCompact(val);
            const palabras = normVal.split(' ').filter(Boolean);

            const filtrados = tablaPesos.filter(p => {
                const normProd = normText(p.producto);
                const compProd = normCompact(p.producto);
                const coincidePalabras = palabras.every(pal => normProd.includes(pal));
                const coincideCompacto = compProd.includes(compVal);
                return coincidePalabras || coincideCompacto;
            });

            filtrados.forEach((p, i) => {
                const div = document.createElement("DIV");
                div.innerHTML = `<b>${p.producto}</b>`;
                div.dataset.idx = i;
                div.addEventListener("click", () => {
                    inputProducto.value = p.producto;
                    inputProducto.dataset.peso = p.valor;
                    listCont.innerHTML = "";
                    autocompleteIdx = -1;
                });
                listCont.appendChild(div);
            });
        }

        inputProducto.addEventListener("input", function() {
            buildAutocomplete(this.value);
            const match = buscarProductoCoincidente(this.value);
            if (match) {
                inputProducto.dataset.peso = match.valor;
            }
        });

        inputProducto.addEventListener("blur", function() {
            const match = buscarProductoCoincidente(this.value);
            if (match) {
                this.value = match.producto;
                this.dataset.peso = match.valor;
            }
        });

        // Navegación con flechas del teclado
        inputProducto.addEventListener("keydown", function(e) {
            const listCont = document.getElementById("autocomplete-list");
            const items = listCont.querySelectorAll("div");
            if (!items.length) return;

            if (e.key === "ArrowDown") {
                e.preventDefault();
                autocompleteIdx = (autocompleteIdx + 1) % items.length;
                items.forEach((it, i) => it.classList.toggle("autocomplete-active", i === autocompleteIdx));
                items[autocompleteIdx].scrollIntoView({ block: "nearest" });
            } else if (e.key === "ArrowUp") {
                e.preventDefault();
                autocompleteIdx = (autocompleteIdx - 1 + items.length) % items.length;
                items.forEach((it, i) => it.classList.toggle("autocomplete-active", i === autocompleteIdx));
                items[autocompleteIdx].scrollIntoView({ block: "nearest" });
            } else if (e.key === "Enter" && autocompleteIdx >= 0) {
                e.preventDefault();
                items[autocompleteIdx].click();
            } else if (e.key === "Escape") {
                listCont.innerHTML = "";
                autocompleteIdx = -1;
            }
        });
    }

    // --- REGISTRO DE PRODUCTOS ---
    if(form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();

            // 1. Haber seleccionado su turno
            if (!selectTurno.value) {
                alert('Debe seleccionar primero su turno.');
                selectTurno.focus();
                return;
            }

            // 2. Haber seleccionado su proceso
            if (!selectProceso.value) {
                alert('Debe seleccionar primero su proceso.');
                selectProceso.focus();
                return;
            }

            // Validaciones de producto y piezas
            const prodTexto = inputProducto.value.trim();
            if (!prodTexto) {
                alert('Por favor seleccione un producto.');
                inputProducto.focus();
                return;
            }

            const matchProd = buscarProductoCoincidente(prodTexto);
            if (!matchProd) {
                alert('El producto ingresado no existe en las tablas / catálogo de productos. Por favor seleccione un producto de la lista.');
                inputProducto.focus();
                return;
            }

            // Asegurar nombre oficial y peso real del producto
            inputProducto.value = matchProd.producto;
            inputProducto.dataset.peso = matchProd.valor;

            const rawPz = String(inputPiezas.value || '').replace(/,/g, '').trim();
            const pzas = parseInt(rawPz, 10);
            if (!rawPz || isNaN(pzas) || pzas <= 0) {
                alert('Por favor ingrese un número de piezas válido.');
                inputPiezas.focus();
                return;
            }

            const pesoUnidad = !isNaN(parseFloat(matchProd.valor)) ? parseFloat(matchProd.valor) : 1.2;
            let calcKilos = Math.round(pesoUnidad * pzas);
            if (isNaN(calcKilos) || calcKilos < 0) calcKilos = Math.round(1.2 * pzas);

            const fechaFinal = (inputFecha && inputFecha.value) ? inputFecha.value : getFechaTrabajoAtrasada();

            const nuevoRegistro = {
                id: Date.now() + '_' + Math.random().toString(36).substr(2, 6),
                fecha: fechaFinal,
                turno: selectTurno.value,
                proceso: selectProceso.value,
                producto: matchProd.producto || inputProducto.value,
                especificacion: document.getElementById('especificacion') ? document.getElementById('especificacion').value.trim() : "",
                piezas: pzas,
                kilos: calcKilos
            };

            registrosTemporalesOperador.push(nuevoRegistro);
            guardarBorradoresLocal();
            actualizarHistorialPantallaOperador();

            // Limpiar solo los campos de producto y piezas (mantener turno y proceso)
            inputProducto.value = '';
            inputPiezas.value = '';
            if (document.getElementById('especificacion')) {
                document.getElementById('especificacion').value = '';
            }
            delete inputProducto.dataset.peso;
            inputProducto.focus();
        });
    }

    // --- RENDERIZADO DEL HISTORIAL Y EDICIÓN EN CALIENTE ---
    function actualizarHistorialPantallaOperador() {
        const container = document.getElementById('history-container-operador');
        if(!container) return;

        const selectTurno = document.getElementById('turno');
        const selectProceso = document.getElementById('proceso');
        const activeTurno = (selectTurno && selectTurno.value) ? selectTurno.value : 'Mañana';
        const activeProceso = (selectProceso && selectProceso.value) ? selectProceso.value : 'Selección, Limpieza, Flejado y Empaque';

        // Obtener combinaciones únicas de Turno|Proceso
        const combinaciones = new Set();
        if (activeTurno && activeProceso) {
            combinaciones.add(`${activeTurno}|${activeProceso}`);
        }
        combinaciones.add(`Mañana|${activeProceso}`);

        registrosTemporalesOperador.forEach(r => {
            if (r && r.turno && r.proceso) {
                combinaciones.add(`${r.turno}|${r.proceso}`);
            }
        });
        Object.keys(trabajadoresActivos).forEach(key => {
            if (trabajadoresActivos[key] && trabajadoresActivos[key].length > 0) {
                combinaciones.add(key);
            }
        });

        container.innerHTML = "";
        const listaTurnos = ["Mañana", "Tarde", "Noche"];
        const emojisTurno = { "Mañana": "🌅", "Tarde": "☀️", "Noche": "🌙" };
        const clasesTurno = { "Mañana": "mañana", "Tarde": "tarde", "Noche": "noche" };

        listaTurnos.forEach(t => {
            const combinacionesTurno = Array.from(combinaciones).filter(c => c.startsWith(t + "|"));
            if(combinacionesTurno.length === 0) return;

            const divTurno = document.createElement('div');
            divTurno.className = 'turno-card-block';
            divTurno.innerHTML = `<div class="turno-header-title ${clasesTurno[t]}">${emojisTurno[t]} Turno ${t}</div>`;

            combinacionesTurno.forEach(comb => {
                const parts = comb.split('|');
                const proc = parts[1];
                const key = comb;

                const divProceso = document.createElement('div');
                divProceso.className = 'proceso-sub-group';

                const listWorkers = trabajadoresActivos[key] || [];
                let workersHtml = '';
                if (listWorkers.length > 0) {
                    workersHtml = `<div class="trabajadores-badge-list">
                        <span style="font-weight: 600; color: #4b5563; margin-right: 5px;">👷 Trabajadores:</span>`;
                    listWorkers.forEach(w => {
                        workersHtml += `<span class="badge">${w} <span class="remove-worker" onclick="eliminarTrabajadorActivo('${t}', '${proc}', '${w}')">✕</span></span>`;
                    });
                    workersHtml += `</div>`;
                } else {
                    workersHtml = `<div class="trabajadores-badge-list" style="border-color: #fca5a5; background: #fef2f2;">
                        <span style="font-weight: 600; color: #dc2626;">⚠️ Sin trabajadores asignados en este proceso. Agrega al menos uno desde el panel superior.</span>
                    </div>`;
                }

                let subTablaHtml = `<div class="proceso-label-title">🛠️ ${proc}</div>
                    ${workersHtml}
                    <table class="corporate-table">
                        <thead><tr><th>#</th><th>Producto</th><th>Piezas</th><th>Acción</th></tr></thead><tbody>`;

                const registrosDelProceso = registrosTemporalesOperador.filter(r => r.turno === t && r.proceso === proc);

                if (registrosDelProceso.length === 0) {
                    subTablaHtml += `<tr><td colspan="4" style="text-align:center;color:#64748b;font-style:italic;">No hay productos registrados aún en este turno y proceso.</td></tr>`;
                } else {
                    registrosDelProceso.forEach((r, i) => {
                        if (editandoRegistroId === r.id) {
                            // Generar dropdown de productos
                            let optionsHtml = '';
                            tablaPesos.forEach(p => {
                                const selected = p.producto === r.producto ? 'selected' : '';
                                const safeVal = p.producto.replace(/"/g, '&quot;');
                                optionsHtml += `<option value="${safeVal}" ${selected}>${p.producto}</option>`;
                            });


                            subTablaHtml += `<tr style="background-color: #fff7ed;">
                                <td>${i+1}</td>
                                <td>
                                    <div style="display:flex; flex-direction:column; gap:4px;">
                                        <label style="font-size:0.7rem; color:#64748b; font-weight:600;">Producto:</label>
                                        <select id="edit-prod-${r.id}" class="edit-select" style="max-width: 250px;">
                                            ${optionsHtml}
                                        </select>
                                    </div>
                                </td>
                                <td>
                                    <div style="display:flex; flex-direction:column; gap:4px;">
                                        <label style="font-size:0.7rem; color:#64748b; font-weight:600;">Piezas:</label>
                                        <input type="number" id="edit-piezas-${r.id}" class="edit-input" style="width: 80px;" value="${r.piezas}" min="1">
                                    </div>
                                </td>
                                <td colspan="1">
                                    <div style="display:flex; flex-direction:row; gap:8px; align-items:center;">
                                        <div style="display:flex; flex-direction:column; gap:4px;">
                                            <label style="font-size:0.7rem; color:#64748b; font-weight:600;">Turno:</label>
                                            <select id="edit-turno-${r.id}" class="edit-select">
                                                <option value="Mañana" ${r.turno === 'Mañana' ? 'selected' : ''}>Mañana</option>
                                                <option value="Tarde" ${r.turno === 'Tarde' ? 'selected' : ''}>Tarde</option>
                                                <option value="Noche" ${r.turno === 'Noche' ? 'selected' : ''}>Noche</option>
                                            </select>
                                        </div>
                                        <div style="display:flex; flex-direction:column; gap:4px;">
                                            <label style="font-size:0.7rem; color:#64748b; font-weight:600;">Proceso:</label>
                                            <select id="edit-proceso-${r.id}" class="edit-select" style="max-width: 250px;">
                                                <option value="Selección, Limpieza, Flejado y Empaque" ${r.proceso === 'Selección, Limpieza, Flejado y Empaque' ? 'selected' : ''}>Selección, Limpieza, Flejado y Empaque</option>
                                                <option value="Preparación y/o Acondicionamiento de venta" ${r.proceso === 'Preparación y/o Acondicionamiento de venta' ? 'selected' : ''}>Preparación y/o Acondicionamiento de venta</option>
                                                <option value="Conformado, Rimado y Pintura" ${r.proceso === 'Conformado, Rimado y Pintura' ? 'selected' : ''}>Conformado, Rimado y Pintura</option>
                                                <option value="Selección de tubo para re-galvanizar" ${r.proceso === 'Selección de tubo para re-galvanizar' ? 'selected' : ''}>Selección de tubo para re-galvanizar</option>
                                            </select>
                                        </div>
                                        <div style="margin-top:16px;">
                                            <button class="btn-save-inline" onclick="guardarEdicionRegistro('${r.id}')">✓ Guardar</button>
                                            <button class="btn-cancel-inline" onclick="cancelarEdicionRegistro()">✕</button>
                                        </div>
                                    </div>
                                </td>
                            </tr>`;
                        } else {
                            subTablaHtml += `<tr>
                                <td>${i+1}</td>
                                <td><b>${r.producto}</b></td>
                                <td style="font-weight:700;">${r.piezas.toLocaleString('es-MX')} pz</td>
                                <td>
                                    <span style="color:#0284c7;cursor:pointer;margin-right:15px;font-weight:600;" onclick="comenzarEdicionRegistro('${r.id}')">✏️ Editar</span>
                                    <span style="color:#ef4444;cursor:pointer;font-weight:600;" onclick="eliminarRegistroTemporal('${r.id}')">✕ Eliminar</span>
                                </td>
                            </tr>`;
                        }
                    });
                }
                subTablaHtml += `</tbody></table>`;
                divProceso.innerHTML = subTablaHtml;
                divTurno.appendChild(divProceso);
            });
            container.appendChild(divTurno);
        });
    }

    window.comenzarEdicionRegistro = (id) => {
        editandoRegistroId = id;
        actualizarHistorialPantallaOperador();
    };

    window.cancelarEdicionRegistro = () => {
        editandoRegistroId = null;
        actualizarHistorialPantallaOperador();
    };

    window.guardarEdicionRegistro = (id) => {
        const prodVal = document.getElementById(`edit-prod-${id}`).value;
        const piezasVal = parseInt(String(document.getElementById(`edit-piezas-${id}`).value || '').replace(/,/g, '').trim(), 10);
        const turnoVal = document.getElementById(`edit-turno-${id}`).value;
        const procesoVal = document.getElementById(`edit-proceso-${id}`).value;

        if (!prodVal) return alert("Seleccione un producto.");
        if (isNaN(piezasVal) || piezasVal <= 0) return alert("Ingrese un número de piezas válido.");

        const rIndex = registrosTemporalesOperador.findIndex(r => r.id === id);
        if (rIndex !== -1) {
            const prodObj = tablaPesos.find(p => p.producto === prodVal);
            const peso = prodObj ? prodObj.valor : 1.2;
            
            registrosTemporalesOperador[rIndex].producto = prodVal;
            registrosTemporalesOperador[rIndex].piezas = piezasVal;
            registrosTemporalesOperador[rIndex].turno = turnoVal;
            registrosTemporalesOperador[rIndex].proceso = procesoVal;
            registrosTemporalesOperador[rIndex].kilos = Math.round(peso * piezasVal);
        }

        editandoRegistroId = null;
        guardarBorradoresLocal();
        actualizarHistorialPantallaOperador();
    };

    window.eliminarRegistroTemporal = (id) => {
        registrosTemporalesOperador = registrosTemporalesOperador.filter(r => r.id !== id);
        guardarBorradoresLocal();
        actualizarHistorialPantallaOperador();
    };

    // --- ENVIAR DATOS A LA NUBE ---
    if(btnFinalizarTurno) {
        btnFinalizarTurno.addEventListener('click', async () => {
            if(registrosTemporalesOperador.length === 0) return alert("No hay datos para enviar.");
            if(confirm("¿Enviar todos los registros a la base de datos empresarial (Nube)?")) {
                const originalText = btnFinalizarTurno.innerHTML;
                btnFinalizarTurno.innerHTML = '⏳ Subiendo...';
                btnFinalizarTurno.disabled = true;
                btnFinalizarTurno.style.opacity = '0.7';

                try {
                    function calcularMetadatosFecha(fechaStr) {
                        if (!fechaStr) return { semana: 1, semanaClave: 'Semana 1', diaSemana: '' };
                        const parts = fechaStr.split('-');
                        const dateObj = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
                        const diasNombres = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
                        const diaSemana = diasNombres[dateObj.getDay()];

                        const dayOfWeek = dateObj.getDay();
                        const diffLunes = (dayOfWeek === 0 ? -6 : 1 - dayOfWeek);
                        const lunes = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate() + diffLunes);
                        
                        const primerDiaMes = new Date(dateObj.getFullYear(), dateObj.getMonth(), 1);
                        let primerLunes = new Date(primerDiaMes);
                        if (primerLunes.getDay() === 0) {
                            primerLunes.setDate(2);
                        } else if (primerLunes.getDay() > 1) {
                            primerLunes.setDate(1 + (8 - primerLunes.getDay()));
                        }
                        
                        const diffWeeks = Math.floor(Math.round((lunes - primerLunes) / (1000 * 60 * 60 * 24)) / 7) + 1;
                        const numSemana = Math.max(1, diffWeeks);

                        return {
                            semana: numSemana,
                            semanaClave: `Semana ${numSemana}`,
                            diaSemana: diaSemana,
                            semanaAnio: `${dateObj.getFullYear()}-W${String(numSemana).padStart(2, '0')}`
                        };
                    }

                    // Mapear registros inyectándoles los trabajadores activos de cada respectivo turno y proceso
                    const registrosFinales = registrosTemporalesOperador.map(registro => {
                        const key = `${registro.turno}|${registro.proceso}`;
                        const workersList = trabajadoresActivos[key] || [];
                        const meta = calcularMetadatosFecha(registro.fecha);
                        return {
                            ...registro,
                            ...meta,
                            id: registro.id || (Date.now() + '_' + Math.random().toString(36).substr(2, 9)),
                            trabajadores: workersList.length > 0 ? workersList.join(', ') : 'N/A'
                        };
                    });

                    // 1. Guardar SIEMPRE localmente para evitar pérdidas
                    let dbAdminLocal = JSON.parse(localStorage.getItem('rymco_db_admin')) || [];
                    dbAdminLocal = [...dbAdminLocal, ...registrosFinales];
                    localStorage.setItem('rymco_db_admin', JSON.stringify(dbAdminLocal));

                    let guardadoNubeExitoso = false;

                    // 2. Intentar guardar en Firebase Firestore si está disponible
                    if (typeof db !== 'undefined' && db !== null) {
                        try {
                            const promesasGuardado = registrosFinales.map(registro => {
                                const cleanReg = JSON.parse(JSON.stringify(registro));
                                const ts = (typeof firebase !== 'undefined' && firebase.firestore && firebase.firestore.FieldValue)
                                    ? firebase.firestore.FieldValue.serverTimestamp()
                                    : new Date().toISOString();
                                return db.collection("registros_produccion").add({
                                    ...cleanReg,
                                    timestamp: ts
                                });
                            });

                            const timeout = new Promise((_, reject) => 
                                setTimeout(() => reject(new Error('TIMEOUT_FIREBASE: El servidor de Firebase no respondió en 10 segundos.')), 10000)
                            );

                            await Promise.race([Promise.all(promesasGuardado), timeout]);
                            guardadoNubeExitoso = true;
                        } catch (errNube) {
                            console.error("Error al transmitir a Firebase Cloud:", errNube);
                            alert("⚠️ Error en Firebase Nube: " + (errNube.message || errNube) + "\n\nComprueba las Reglas (Rules) de tu consola de Firebase.");
                        }
                    }

                    // Limpiar todo tras éxito (local y memoria borrador)
                    registrosTemporalesOperador = [];
                    trabajadoresActivos = {};
                    localStorage.removeItem('rymco_bitacora_draft_registros');
                    localStorage.removeItem('rymco_bitacora_draft_trabajadores');
                    localStorage.removeItem('rymco_deleted_ids');
                    actualizarHistorialPantallaOperador();

                    // Actualización en tiempo real de gráficas y métricas
                    if (window.actualizarVistaMódulos) await window.actualizarVistaMódulos();
                    if (window.inicializarGraficos) await window.inicializarGraficos();
                    if (window.actualizarDashboardStats) await window.actualizarDashboardStats();
                    if (window.actualizarPanelRecuperacion) await window.actualizarPanelRecuperacion();

                    if (guardadoNubeExitoso) {
                        alert("✅ Datos transmitidos y guardados con éxito en la Nube (Firebase) y en Almacenamiento Local.");
                    } else {
                        alert("✅ Datos guardados correctamente en Almacenamiento Local (Modo Offline).");
                    }
                } catch(error) {
                    console.error("Error guardando registros: ", error);
                    alert("❌ Ocurrió un error inesperado al procesar los registros.");
                } finally {
                    btnFinalizarTurno.innerHTML = originalText;
                    btnFinalizarTurno.disabled = false;
                    btnFinalizarTurno.style.opacity = '1';
                }
            }
        });
    }
});