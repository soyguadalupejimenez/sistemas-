/**
 * =======================================================
 * RYMCO S.A. DE C.V. - LUPITA IA (ASISTENTE VIRTUAL)
 * Módulo Independiente de Inteligencia Artificial
 * =======================================================
 */

(function () {
    'use strict';

    // SVG Maestro Reutilizable del Robot 3D
    const BOT_SVG_DEFS = `
    <svg style="display: none;" id="botGlobalDefsSvg">
        <defs>
            <g id="botMasterAvatar">
                <radialGradient id="mGold" cx="35%" cy="30%" r="70%">
                    <stop offset="0%" stop-color="#FDE047" />
                    <stop offset="45%" stop-color="#F59E0B" />
                    <stop offset="100%" stop-color="#D97706" />
                </radialGradient>
                <linearGradient id="mHead" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#FFFFFF" />
                    <stop offset="70%" stop-color="#E2E8F0" />
                    <stop offset="100%" stop-color="#CBD5E1" />
                </linearGradient>
                <linearGradient id="mBlue" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stop-color="#3B82F6" />
                    <stop offset="100%" stop-color="#1D4ED8" />
                </linearGradient>
                <linearGradient id="mCyan" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#67E8F9" />
                    <stop offset="100%" stop-color="#00F2FE" />
                </linearGradient>
                <filter id="mGlow" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="1.5" result="blur" />
                    <feMerge>
                        <feMergeNode in="blur" />
                        <feMergeNode in="SourceGraphic" />
                    </feMerge>
                </filter>
                <path d="M 50 6 C 73 6 92 23 92 45 C 92 60 83 73 70 80 L 73 92 L 59 84 C 56 85 53 85 50 85 C 27 85 8 68 8 45 C 8 23 27 6 50 6 Z" fill="url(#mGold)"/>
                <circle cx="50" cy="45" r="35" fill="#F8FAFC" opacity="0.95"/>
                <g transform="translate(8, 12)">
                    <rect width="18" height="12" rx="3.5" fill="#2563EB"/>
                    <line x1="3.5" y1="4.5" x2="13.5" y2="4.5" stroke="#FFFFFF" stroke-width="1.6" stroke-linecap="round"/>
                    <line x1="3.5" y1="8" x2="10" y2="8" stroke="#93C5FD" stroke-width="1.6" stroke-linecap="round"/>
                </g>
                <g transform="translate(72, 8)">
                    <circle cx="9" cy="9" r="8" fill="#EF4444" stroke="#FFFFFF" stroke-width="1.5"/>
                    <text x="9" y="13" font-family="'Outfit', sans-serif" font-weight="900" font-size="10" fill="#FFFFFF" text-anchor="middle">!</text>
                </g>
                <path d="M 30 43 C 30 27 70 27 70 43" fill="none" stroke="url(#mBlue)" stroke-width="4" stroke-linecap="round"/>
                <rect x="27" y="31" width="46" height="38" rx="19" fill="url(#mHead)"/>
                <rect x="32" y="37" width="36" height="24" rx="11" fill="#0B132B"/>
                <path d="M 38 48 C 38 43 43 43 43 48" fill="none" stroke="url(#mCyan)" stroke-width="2.6" stroke-linecap="round" filter="url(#mGlow)"/>
                <path d="M 57 48 C 57 43 62 43 62 48" fill="none" stroke="url(#mCyan)" stroke-width="2.6" stroke-linecap="round" filter="url(#mGlow)"/>
                <path d="M 46 52 Q 50 56 54 52" fill="none" stroke="url(#mCyan)" stroke-width="2.2" stroke-linecap="round" filter="url(#mGlow)"/>
                <rect x="23" y="38" width="6" height="13" rx="3" fill="#3B82F6"/>
                <rect x="71" y="38" width="6" height="13" rx="3" fill="#3B82F6"/>
                <path d="M 73 47 Q 70 60 59 58" fill="none" stroke="#2563EB" stroke-width="2.2" stroke-linecap="round"/>
                <circle cx="58" cy="58" r="2.8" fill="#FBBF24"/>
            </g>
        </defs>
    </svg>`;

    // Renderizar la estructura del Chatbot en el DOM
    function injectChatbotHTML() {
        if (document.getElementById('aiChatWindow')) return;

        // Inyectar definiciones SVG
        const defsDiv = document.createElement('div');
        defsDiv.innerHTML = BOT_SVG_DEFS;
        document.body.appendChild(defsDiv);

        // Estructura completa del widget
        const widgetContainer = document.createElement('div');
        widgetContainer.id = 'aiChatbotAppContainer';
        widgetContainer.innerHTML = `
            <!-- Botón flotante -->
            <div class="ai-chat-trigger-wrap">
                <div class="ai-trigger-tooltip" id="aiTriggerTooltip">
                    <span>💬 ¡Hola! <strong>¿Tienes dudas de planta?</strong></span>
                </div>
                <button type="button" class="ai-chat-trigger" id="aiChatTriggerBtn" onclick="window.toggleChatbotIA()" aria-label="Abrir Asistente Virtual">
                    <span class="ai-trigger-badge">1</span>
                    <svg viewBox="0 0 100 100" class="ai-trigger-avatar-svg">
                        <use href="#botMasterAvatar" />
                    </svg>
                </button>
            </div>

            <!-- Ventana de Chat IA -->
            <div class="ai-chat-window" id="aiChatWindow" style="display: none;">
                <div class="ai-chat-header">
                    <div class="ai-header-info">
                        <div class="ai-header-avatar">
                            <svg viewBox="0 0 100 100" style="width: 100%; height: 100%;">
                                <use href="#botMasterAvatar" />
                            </svg>
                        </div>
                        <div class="ai-header-title-box">
                            <div class="ai-header-title">
                                <span>Lupita IA</span>
                                <span class="ai-header-badge">RYMCO</span>
                            </div>
                            <div class="ai-header-subtitle">
                                <span class="ai-header-status-dot"></span>
                                <span>En línea • Asistente de Planta 24/7</span>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="ai-chat-close" onclick="window.toggleChatbotIA()" aria-label="Cerrar chat">&times;</button>
                </div>

                <div class="ai-chat-body" id="aiChatBody">
                    <!-- Mensaje de bienvenida inicial -->
                    <div class="chat-msg-row bot">
                        <div class="chat-bot-avatar-mini">
                            <svg viewBox="0 0 100 100" style="width: 22px; height: 22px;">
                                <use href="#botMasterAvatar" />
                            </svg>
                        </div>
                        <div class="chat-bubble bot" id="aiChatGreetingText">
                            ¡Hola! 👋 Soy <strong>Lupita</strong>, tu <strong>Asistente Virtual de Planta RYMCO</strong>.<br><br>
                            Estoy aquí para ayudarte con información de la empresa <strong>RYMCO</strong> (productos, turnos, áreas, misión), <strong>equipo de seguridad (EPP)</strong>, <strong>días de pago</strong>, <strong>días festivos</strong> o <strong>permisos</strong>.
                        </div>
                    </div>

                    <!-- Sugerencias rápidas -->
                    <div class="chat-quick-suggestions" id="chatQuickChips">
                        <div class="quick-chip" onclick="window.preguntarIA('¿Qué es RYMCO y a qué se dedica la empresa?')">🏢 Sobre RYMCO</div>
                        <div class="quick-chip" onclick="window.preguntarIA('¿Qué productos y tuberías fabricamos en RYMCO?')">🏭 Productos y Tubería</div>
                        <div class="quick-chip" onclick="window.preguntarIA('¿Cuáles son los horarios de los turnos?')">⏰ Turnos y Horarios</div>
                        <div class="quick-chip" onclick="window.preguntarIA('¿Qué equipo de protección EPP necesito?')">🦺 Equipo EPP</div>
                        <div class="quick-chip" onclick="window.preguntarIA('¿Cuándo son los días de pago de nómina?')">💵 Días de Pago</div>
                        <div class="quick-chip" onclick="window.preguntarIA('¿Qué días festivos oficiales hay en la empresa?')">🇲🇽 Días Festivos</div>
                        <div class="quick-chip" onclick="window.preguntarIA('¿Qué hago si falla una máquina en línea?')">⚙️ Falla de Máquina</div>
                        <div class="quick-chip" onclick="window.preguntarIA('¿Cómo pido un permiso laboral o justificante?')">📋 Permisos Laborales</div>
                    </div>
                </div>

                <div class="ai-chat-footer">
                    <input type="text" class="ai-chat-input" id="aiChatInput" placeholder="Pregúntale a Lupita IA..." onkeypress="window.handleChatKeyPress(event)">
                    <button type="button" class="ai-send-btn" onclick="window.enviarMensajeChatIA()" aria-label="Enviar mensaje">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="22" y1="2" x2="11" y2="13"></line>
                            <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                        </svg>
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(widgetContainer);
        actualizarSaludoUsuario();
    }

    // Obtener información del usuario en sesión
    function getUsuarioInfo() {
        let nombreCompleto = 'Trabajador';
        let primerNombre = 'Compañero';
        let puesto = 'Operador de Planta';
        let numTrabajador = 'TRAB-000';
        let email = 'No registrado';
        let username = 'usuario';

        try {
            const raw = localStorage.getItem('siai_usuario');
            if (raw) {
                const u = JSON.parse(raw);
                if (u.nombre_completo && u.nombre_completo.trim() !== '') {
                    nombreCompleto = u.nombre_completo.trim();
                    primerNombre = nombreCompleto.split(' ')[0];
                }
                if (u.puesto) puesto = u.puesto;
                if (u.num_trabajador) numTrabajador = u.num_trabajador;
                if (u.email) email = u.email;
                if (u.username) username = u.username;
            }
        } catch (e) { }

        const topLabel = document.getElementById('topUserLabel');
        if (topLabel && topLabel.textContent && topLabel.textContent !== 'Trabajador') {
            nombreCompleto = topLabel.textContent.trim();
            primerNombre = nombreCompleto.split(' ')[0];
        }

        return { nombreCompleto, primerNombre, puesto, numTrabajador, email, username };
    }

    // Actualizar saludo personalizado en el DOM
    function actualizarSaludoUsuario() {
        const user = getUsuarioInfo();
        const greetingEl = document.getElementById('aiChatGreetingText');
        if (greetingEl) {
            greetingEl.innerHTML = `¡Hola, <strong style="color: #FBBF24;">${user.primerNombre}</strong>! 👋 Soy <strong>Lupita</strong>, tu <strong>Asistente Virtual de Planta RYMCO</strong>.<br><br>` +
                `Estoy lista para responderte cualquier duda sobre la empresa <strong>RYMCO</strong> (historia, productos, turnos, comedores, áreas de planta), ` +
                `<strong>equipo de seguridad (EPP)</strong>, <strong>días de pago</strong>, <strong>días festivos</strong> o <strong>permisos</strong>. ¿En qué te puedo apoyar hoy?`;
        }
        const tooltipEl = document.getElementById('aiTriggerTooltip');
        if (tooltipEl) {
            tooltipEl.innerHTML = `<span>💬 ¡Hola <strong>${user.primerNombre}</strong>! ¿En qué te ayudo?</span>`;
        }
    }

    // Mostrar u ocultar ventana del chat
    function toggleChatbotIA() {
        const win = document.getElementById('aiChatWindow');
        const tooltip = document.getElementById('aiTriggerTooltip');
        if (!win) return;
        if (win.style.display === 'none' || win.style.display === '') {
            win.style.display = 'flex';
            if (tooltip) tooltip.style.display = 'none';

            actualizarSaludoUsuario();

            const input = document.getElementById('aiChatInput');
            if (input) setTimeout(() => input.focus(), 150);
        } else {
            win.style.display = 'none';
        }
    }

    function handleChatKeyPress(event) {
        if (event.key === 'Enter') {
            enviarMensajeChatIA();
        }
    }

    function preguntarIA(textoPregunta) {
        const input = document.getElementById('aiChatInput');
        if (input) input.value = textoPregunta;
        enviarMensajeChatIA();
    }

    function enviarMensajeChatIA() {
        const input = document.getElementById('aiChatInput');
        const chatBody = document.getElementById('aiChatBody');
        if (!input || !chatBody) return;

        const userText = input.value.trim();
        if (!userText) return;

        // 1. Agregar burbuja del usuario
        const userRow = document.createElement('div');
        userRow.className = 'chat-msg-row user';
        userRow.innerHTML = `<div class="chat-bubble user">${escapeHTML(userText)}</div>`;
        chatBody.appendChild(userRow);
        input.value = '';

        chatBody.scrollTop = chatBody.scrollHeight;

        // 2. Mostrar indicador de escribiendo con avatar
        const typingRow = document.createElement('div');
        typingRow.className = 'ai-typing-indicator';
        typingRow.id = 'aiTypingIndicator';
        typingRow.innerHTML = `
            <div class="chat-bot-avatar-mini">
                <svg viewBox="0 0 100 100" style="width: 22px; height: 22px;">
                    <use href="#botMasterAvatar" />
                </svg>
            </div>
            <div class="typing-bubble">
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
            </div>
        `;
        chatBody.appendChild(typingRow);
        chatBody.scrollTop = chatBody.scrollHeight;

        // 3. Generar respuesta inteligente con conocimiento de planta
        setTimeout(() => {
            const indicator = document.getElementById('aiTypingIndicator');
            if (indicator) indicator.remove();

            const botResponse = procesarPreguntaTrabajador(userText);
            const botRow = document.createElement('div');
            botRow.className = 'chat-msg-row bot';
            botRow.innerHTML = `
                <div class="chat-bot-avatar-mini">
                    <svg viewBox="0 0 100 100" style="width: 22px; height: 22px;">
                        <use href="#botMasterAvatar" />
                    </svg>
                </div>
                <div class="chat-bubble bot">${botResponse}</div>
            `;
            chatBody.appendChild(botRow);
            chatBody.scrollTop = chatBody.scrollHeight;
        }, 600);
    }

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g,
            tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
        );
    }

    // ==========================================
    // BASE DE CONOCIMIENTO EXTENDIDA: RYMCO S.A.
    // ==========================================
    function procesarPreguntaTrabajador(query) {
        const q = query.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        const user = getUsuarioInfo();

        // 1. Identidad del usuario / Mi nombre
        if (q.includes('como me llamo') || q.includes('cual es mi nombre') || q.includes('quien soy') || q.includes('sabes mi nombre') || q.includes('mi perfil') || q.includes('mis datos') || q.includes('mi puesto') || q.includes('mi usuario')) {
            return `👤 <strong>Tus Datos de Trabajador en RYMCO:</strong><br><br>
            • 📛 <strong>Nombre:</strong> ${user.nombreCompleto}<br>
            • 💼 <strong>Puesto / Rol:</strong> ${user.puesto}<br>
            • 🆔 <strong>No. de Empleado:</strong> ${user.numTrabajador}<br>
            • ✉️ <strong>Correo:</strong> ${user.email}<br>
            • 🏢 <strong>Empresa:</strong> RYMCO S.A. de C.V.<br><br>
            ¡Es un honor tenerte en nuestro equipo de planta, <strong>${user.primerNombre}</strong>! 🤝`;
        }

        // 2. Sobre la empresa RYMCO (Quiénes somos, Historia, Giro)
        if (q.includes('que es rymco') || q.includes('quienes somos') || q.includes('la empresa') || q.includes('a que se dedica') || q.includes('historia de rymco') || q.includes('sobre la empresa') || q.includes('acerca de rymco') || q.includes('giro de la empresa')) {
            return `🏢 <strong>Acerca de RYMCO S.A. de C.V.:</strong><br><br>
            <strong>RYMCO</strong> es una empresa mexicana líder en la <strong>fabricación, transformación y comercialización de tubería conduit de acero</strong> y perfiles metálicos de alta calidad para canalización eléctrica y conducción estructural.<br><br>
            • 🌟 <strong>Presencia:</strong> Abastecemos proyectos industriales, comerciales y residenciales en todo México con certificación nacional e internacional.<br>
            • 🏭 <strong>Compromiso:</strong> Seguridad en el trabajo, excelencia en manufactura, calidad total y satisfacción de nuestros colaboradores y clientes.`;
        }

        // 3. Misión, Visión y Valores de RYMCO
        if (q.includes('mision') || q.includes('vision') || q.includes('valores') || q.includes('filosofia') || q.includes('politica de calidad') || q.includes('principios')) {
            return `🎯 <strong>Misión, Visión y Valores de RYMCO:</strong><br><br>
            • 🚀 <strong>Misión:</strong> Fabricar y suministrar soluciones de tubería conduit y acero con los más altos estándares de calidad, resistencia y seguridad, impulsando el desarrollo industrial de México.<br><br>
            • 👁️ <strong>Visión:</strong> Ser el referente y fabricante número uno en canalización eléctrica de acero, reconocidos por nuestra innovación, procesos sustentables y talento humano.<br><br>
            • ⭐ <strong>Valores Fundamentales:</strong><br>
            1. 🦺 <strong>Seguridad:</strong> Nada está por encima de la integridad de nuestra gente.<br>
            2. 💎 <strong>Calidad Total:</strong> Cada tubo que sale de planta cumple normas estrictas.<br>
            3. 🤝 <strong>Trabajo en Equipo:</strong> Colaboración, respeto y apoyo mutuo.<br>
            4. ⏱️ <strong>Puntualidad y Disciplina:</strong> Eficiencia y compromiso.<br>
            5. 💡 <strong>Mejora Continua:</strong> Innovamos procesos y herramientas día con día.`;
        }

        // 4. Productos y Tubería Fabricada en RYMCO
        if (q.includes('producto') || q.includes('fabrica') || q.includes('tuber') || q.includes('tubo') || q.includes('conduit') || q.includes('emt') || q.includes('pared delgada') || q.includes('pared gruesa') || q.includes('cedula 40') || q.includes('galvaniz') || q.includes('cople') || q.includes('fleje')) {
            return `🏭 <strong>Catálogo de Productos y Tubería RYMCO:</strong><br><br>
            En nuestras líneas de producción fabricamos:<br>
            • 🔹 <strong>Tubo Conduit Pared Delgada (EMT):</strong> Galvanizado por inmersión o electrolítico, ligero y resistente para instalaciones eléctricas ocultas o visibles.<br>
            • 🔹 <strong>Tubo Conduit Pared Gruesa (RMC / GRC):</strong> Tubería de alta resistencia con roscado en extremos y coples, ideal para ambientes corrosivos o de alto riesgo.<br>
            • 🔹 <strong>Tubería Cédula 40:</strong> Tubería de acero al carbón para usos mecánicos, industriales y de conducción estructural.<br>
            • 🔹 <strong>Accesorios y Conexiones:</strong> Coples roscados, conectores rectos y curvos, flejes de sujeción y protecciones galvanizadas.<br><br>
            ✅ <em>Todos los lotes se someten a control de calidad y pruebas de aplastamiento y galvanizado.</em>`;
        }

        // 5. Horarios, Turnos y Checador
        if (q.includes('turno') || q.includes('horario') || q.includes('a que hora') || q.includes('jornada') || q.includes('checador') || q.includes('entrada') || q.includes('salida') || q.includes('tolerancia')) {
            return `⏰ <strong>Horarios de Turnos y Jornadas en Planta RYMCO:</strong><br><br>
            • 🌅 <strong>Turno Matutino:</strong> 06:00 hrs a 14:00 hrs.<br>
            • 🌆 <strong>Turno Vespertino:</strong> 14:00 hrs a 21:30 hrs.<br>
            • 🌙 <strong>Turno Nocturno:</strong> 21:30 hrs a 06:00 hrs.<br><br>
            ⏱️ <strong>Reglas de Asistencia:</strong><br>
            • Registra tu entrada en el checador con tu huella o credencial.<br>
            • Tienes una <strong>tolerancia de 10 minutos</strong> al inicio de tu turno.<br>
            • Cada turno cuenta con <strong>30 minutos de comida</strong> en los horarios programados por supervisor.`;
        }

        // 6. Instalaciones, Áreas de Planta y Servicios al Personal
        if (q.includes('comedor') || q.includes('comida') || q.includes('almuerzo') || q.includes('enfermer') || q.includes('medico') || q.includes('transporte') || q.includes('estacionamiento') || q.includes('bano') || q.includes('vestidor') || q.includes('casillero') || q.includes('planta') || q.includes('instalacion') || q.includes('patio')) {
            return `🏢 <strong>Instalaciones y Servicios al Personal en RYMCO:</strong><br><br>
            • 🍽️ <strong>Comedor de Planta:</strong> Servicio de alimentos calientes en horarios escalonados de turno.<br>
            • 🏥 <strong>Servicio Médico / Enfermería:</strong> Atención de primeros auxilios y chequeos de salud ubicada junto a Recursos Humanos.<br>
            • 🚌 <strong>Transporte de Personal:</strong> Rutas oficiales en turnos matutino, vespertino y nocturno.<br>
            • 🚿 <strong>Vestidores y Casilleros:</strong> Espacios asignados para resguardo de pertenencias y cambio de ropa de trabajo.<br>
            • 🚛 <strong>Patio de Maniobras y Almacén:</strong> Área exclusiva para montacargas y carga de transporte pesado (porta EPP completo al transitar).`;
        }

        // 7. Prestaciones, Nómina, Pagos y Beneficios
        if (q.includes('prestacion') || q.includes('beneficio') || q.includes('aguinaldo') || q.includes('vacacion') || q.includes('prima') || q.includes('utilidad') || q.includes('seguro') || q.includes('imss') || q.includes('sueldo') || q.includes('quincena') || q.includes('pago') || q.includes('nomina')) {
            return `💵 <strong>Pagos, Nómina y Prestaciones de Ley en RYMCO:</strong><br><br>
            • 💳 <strong>Fechas de Pago:</strong> Días <strong>15 y último día de cada mes</strong> (si cae en fin de semana, se anticipa al viernes).<br>
            • 🏥 <strong>Seguridad Social:</strong> Afiliación formal al <strong>IMSS</strong> e <strong>INFONAVIT</strong> desde el primer día laboral.<br>
            • 🎁 <strong>Aguinaldo:</strong> Pago anual conforme a la Ley Federal del Trabajo antes del 20 de Diciembre.<br>
            • 🏖️ <strong>Vacaciones y Prima Vacacional:</strong> Conforme al esquema legal por antigüedad laboral.<br>
            • 🥾 <strong>Dotación de Uniformes y EPP:</strong> Entrega periódica de calzado con casquillo, casco y equipo de seguridad sin costo.`;
        }

        // 8. Equipo de Protección Personal (EPP) y Seguridad
        if (q.includes('epp') || q.includes('seguridad') || q.includes('casco') || q.includes('bota') || q.includes('proteccion') || q.includes('lente') || q.includes('guante') || q.includes('chaleco')) {
            return `🦺 <strong>Equipo de Protección Personal Obligatorio (EPP):</strong><br><br>
            En todas las áreas de producción y almacén de RYMCO debes portar:<br>
            • 🪖 <strong>Casco de seguridad</strong> con barbiquejo ajustado.<br>
            • 🥽 <strong>Lentes de policarbonato</strong> con protección contra esquirlas.<br>
            • 🎧 <strong>Protección auditiva</strong> en líneas de rolado, corte y roscado.<br>
            • 🥾 <strong>Botas con casquillo de acero</strong> o dieléctrico.<br>
            • 🧤 <strong>Guantes de carnaza / anticorte</strong> para maniobra de flejes y tubos.<br><br>
            ⚠️ <em>Si tu equipo sufre desgaste o daño, solicita tu cambio inmediato en Almacén de Seguridad.</em>`;
        }

        // 9. Días Festivos Oficiales
        if (q.includes('festivo') || q.includes('feriado') || q.includes('descanso') || q.includes('puente') || q.includes('dia festivo') || q.includes('dias festivos') || q.includes('asueto')) {
            return `🇲🇽 <strong>Días Festivos Oficiales en RYMCO:</strong><br><br>
            • <strong>1 de Enero:</strong> Año Nuevo.<br>
            • <strong>1er Lunes de Febrero:</strong> Conmemoración de la Constitución Mexicana (5 de Feb).<br>
            • <strong>3er Lunes de Marzo:</strong> Natalicio de Benito Juárez (21 de Mar).<br>
            • <strong>1 de Mayo:</strong> Día Internacional del Trabajo.<br>
            • <strong>16 de Septiembre:</strong> Día de la Independencia de México.<br>
            • <strong>3er Lunes de Noviembre:</strong> Conmemoración de la Revolución Mexicana (20 de Nov).<br>
            • <strong>25 de Diciembre:</strong> Navidad.<br><br>
            📅 <em>Puedes consultar detalles en el módulo de <strong>Calendario de Planta</strong>.</em>`;
        }

        // 10. Protocolo 5S, Orden y Limpieza
        if (q.includes('5s') || q.includes('orden') || q.includes('limpieza') || q.includes('clasificar') || q.includes('estandarizar') || q.includes('disciplina')) {
            return `🧹 <strong>Programa 5S en Planta RYMCO:</strong><br><br>
            Mantener tu área limpia y organizada previene accidentes y eleva la calidad:<br>
            1. 🗑️ <strong>Seiri (Clasificar):</strong> Separa lo útil de lo innecesario; retira rebabas y sobrantes.<br>
            2. 📦 <strong>Seiton (Ordenar):</strong> Un lugar para cada herramienta y cada herramienta en su lugar.<br>
            3. ✨ <strong>Seiso (Limpiar):</strong> Limpia tu máquina y línea al inicio y fin de tu turno.<br>
            4. 📏 <strong>Seiketsu (Estandarizar):</strong> Mantén pasillos y señalamientos despejados.<br>
            5. 🤝 <strong>Shitsuke (Disciplina):</strong> Cumple siempre con las normas de seguridad.`;
        }

        // 11. Fallas en Maquinaria y Protocolo LOTO
        if (q.includes('falla') || q.includes('maquina') || q.includes('descompus') || q.includes('paro') || q.includes('loto') || q.includes('mantenimiento') || q.includes('linea') || q.includes('averia')) {
            return `⚙️ <strong>Protocolo de Falla de Maquinaria y Bloqueo (LOTO):</strong><br><br>
            1. 🛑 <strong>Presiona el Paro de Emergencia</strong> si existe riesgo físico inmediato.<br>
            2. 🚫 <strong>No intentes destrabar partes mecánicas ni intervenir tableros eléctricos.</strong><br>
            3. 📢 <strong>Avisa de inmediato a tu Supervisor de Turno</strong>.<br>
            4. 🔒 El personal de <strong>Mantenimiento</strong> colocará candado y tarjeta de bloqueo (LOTO) antes de reparar.`;
        }

        // 12. Permisos, Faltas, Justificantes e Incapacidades IMSS
        if (q.includes('permiso') || q.includes('falta') || q.includes('incapacidad') || q.includes('retardo') || q.includes('justificante') || q.includes('recursos humanos') || q.includes('rh')) {
            return `📋 <strong>Gestión de Permisos y Faltas con Recursos Humanos:</strong><br><br>
            • 📝 <strong>Permiso Programado:</strong> Debe solicitarse con al menos 48 horas de anticipación con visto bueno de tu supervisor.<br>
            • 🏥 <strong>Incapacidad Médica IMSS:</strong> Debes entregar la hoja original expedida por el IMSS en RH dentro de las primeras 24 horas.<br>
            • 📞 <strong>Aviso de Ausencia:</strong> Notifica a tu supervisor antes del inicio de turno para coordinar cobertura de línea.`;
        }

        // 13. Emergencias, Sismos, Evacuación y Primeros Auxilios
        if (q.includes('emergencia') || q.includes('accidente') || q.includes('sismo') || q.includes('temblor') || q.includes('fuego') || q.includes('incendio') || q.includes('evacua') || q.includes('punto de reunion') || q.includes('botiquin')) {
            return `🚨 <strong>Protocolo de Emergencia y Evacuación en RYMCO:</strong><br><br>
            1. 🦺 <strong>Mantén la calma:</strong> Camina, no corras, no empujes.<br>
            2. 🚪 <strong>Sigue las rutas de evacuación verdes</strong> hacia el <strong>Punto de Reunión Oficial</strong> en el patio exterior.<br>
            3. 🧯 <strong>Extintores:</strong> Disponibles en columnas señalizadas de todas las naves.<br>
            4. 🏥 <strong>Primeros Auxilios:</strong> La brigada de emergencias y enfermería atenderán de inmediato cualquier contingencia.`;
        }

        // 14. Saludos personalizados
        if (q.includes('hola') || q.includes('buenos dias') || q.includes('buenas tardes') || q.includes('buenas noches') || q.includes('que tal') || q.includes('oye') || q.includes('lupita') || q.includes('como estas')) {
            return `¡Hola, <strong>${user.primerNombre}</strong>! 👋 Es un gran gusto saludarte.<br><br>
            Soy <strong>Lupita</strong>, tu asistente de planta en RYMCO. ¿En qué tema de la empresa, seguridad, turnos, pagos o procesos puedo orientarte hoy? 😊`;
        }

        // 15. Agradecimientos y despedidas
        if (q.includes('gracias') || q.includes('muchas gracias') || q.includes('perfecto') || q.includes('excelente') || q.includes('ok') || q.includes('adios') || q.includes('bye') || q.includes('nos vemos')) {
            return `¡Con mucho gusto, <strong>${user.primerNombre}</strong>! 🚀<br><br>
            Recuerda que en <strong>RYMCO</strong> la seguridad la hacemos todos. ¡Que tengas un excelente y muy productivo turno laboral! 💪✨`;
        }

        // 16. Respuesta por defecto con menú inteligente de la empresa
        return `Entiendo tu consulta sobre "<em>${escapeHTML(query)}</em>", <strong>${user.primerNombre}</strong>. 🤖<br><br>
        Puedes preguntarme cualquier tema de <strong>RYMCO</strong>, por ejemplo:<br>
        • 🏢 <strong>Sobre la Empresa:</strong> Historia, qué es RYMCO, misión y valores.<br>
        • 🏭 <strong>Productos:</strong> Tubería conduit EMT, pared gruesa, cédula 40, galvanizado.<br>
        • ⏰ <strong>Turnos y Horarios:</strong> Horas de entrada/salida y tolerancia.<br>
        • 🦺 <strong>Seguridad y EPP:</strong> Casco, botas, lentes, guantes y programa 5S.<br>
        • 💵 <strong>Nómina y Pagos:</strong> Fechas de quincena y prestaciones de ley.<br>
        • 🇲🇽 <strong>Días Festivos:</strong> Descansos obligatorios del año.<br>
        • 📋 <strong>Permisos y RH:</strong> Trámites con Recursos Humanos o supervisor.`;
    }

    // Exponer funciones globales para interactividad
    window.toggleChatbotIA = toggleChatbotIA;
    window.handleChatKeyPress = handleChatKeyPress;
    window.preguntarIA = preguntarIA;
    window.enviarMensajeChatIA = enviarMensajeChatIA;
    window.getUsuarioInfoChatbot = getUsuarioInfo;

    // Inicializar al cargar el documento
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', injectChatbotHTML);
    } else {
        injectChatbotHTML();
    }
})();
