/**
 * SIAI RYMCO - Sincronizador de API PHP y MySQL
 * Mantiene sincronizados los registros locales con la base de datos MySQL mediante los endpoints PHP.
 */

window.SIAI_PHP = {
    // 1. Guardar registro de bitácora en PHP/MySQL
    async guardarBitacora(registro) {
        try {
            const res = await fetch('../api/bitacora.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(registro)
            });
            return await res.json();
        } catch (e) {
            console.warn('[SIAI PHP API] Error al guardar bitácora:', e);
            return { success: false, error: e.message };
        }
    },

    // 2. Obtener registros de bitácora desde PHP/MySQL
    async obtenerBitacora(params = {}) {
        try {
            const query = new URLSearchParams(params).toString();
            const res = await fetch(`../api/bitacora.php?${query}`);
            return await res.json();
        } catch (e) {
            console.warn('[SIAI PHP API] Error al obtener bitácora:', e);
            return { success: false, data: [] };
        }
    },

    // 3. Eliminar registro de bitácora en PHP/MySQL
    async eliminarBitacora(idRegistro) {
        try {
            const res = await fetch('../api/bitacora.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'delete', id_registro: idRegistro })
            });
            return await res.json();
        } catch (e) {
            console.warn('[SIAI PHP API] Error al eliminar registro:', e);
            return { success: false, error: e.message };
        }
    },

    // 4. Obtener Inventario desde PHP/MySQL
    async obtenerInventario(proceso = null) {
        try {
            const url = proceso ? `../api/inventario.php?proceso=${encodeURIComponent(proceso)}` : '../api/inventario.php';
            const res = await fetch(url);
            return await res.json();
        } catch (e) {
            console.warn('[SIAI PHP API] Error al obtener inventario:', e);
            return { success: false, data: [] };
        }
    },

    // 5. Guardar / Actualizar Trabajadores en PHP/MySQL
    async guardarTrabajador(trabajador) {
        try {
            const res = await fetch('../api/trabajadores.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(trabajador)
            });
            return await res.json();
        } catch (e) {
            console.warn('[SIAI PHP API] Error al guardar trabajador:', e);
            return { success: false, error: e.message };
        }
    },

    // 6. Obtener Trabajadores desde PHP/MySQL
    async obtenerTrabajadores() {
        try {
            const res = await fetch('../api/trabajadores.php');
            return await res.json();
        } catch (e) {
            console.warn('[SIAI PHP API] Error al obtener trabajadores:', e);
            return { success: false, data: [] };
        }
    },

    // 7. Guardar Configuración en PHP/MySQL
    async guardarConfiguracion(configData) {
        try {
            const res = await fetch('../api/configuracion.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(configData)
            });
            return await res.json();
        } catch (e) {
            console.warn('[SIAI PHP API] Error al guardar configuración:', e);
            return { success: false, error: e.message };
        }
    },

    // 8. Obtener Configuración desde PHP/MySQL
    async obtenerConfiguracion() {
        try {
            const res = await fetch('../api/configuracion.php');
            return await res.json();
        } catch (e) {
            console.warn('[SIAI PHP API] Error al obtener configuración:', e);
            return { success: false, data: {} };
        }
    }
};

// Sincronización automática de arranque con la base de datos MySQL
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Cargar configuración global si está disponible
        const configRes = await window.SIAI_PHP.obtenerConfiguracion();
        if (configRes && configRes.success && configRes.data) {
            const semanaLabel = document.getElementById('user-dash-semana-trabajar-label') || document.getElementById('admin-dash-semana-trabajar-label');
            if (semanaLabel && configRes.data.semana_trabajar) {
                semanaLabel.textContent = `📅 Semana a trabajar: ${configRes.data.semana_trabajar}`;
            }
        }
    } catch (err) {
        console.log('[SIAI PHP API Bridge] Iniciado en modo offline/híbrido');
    }
});
