# Guía de Uso del Sistema SIAI RYMCO en Laptop y Teléfonos (Flutter)

Esta guía explica cómo ejecutar el sistema en la **Laptop (Web)** y cómo conectarlo a los **Teléfonos Móviles** mediante **Flutter**.

---

## 💻 1. Ejecutar el Sistema en la Laptop (Servidor Local)

Para que tu Laptop funcione como servidor y los teléfonos puedan conectarse:

### Paso A: Abrir el proyecto en VS Code o Servidor Local
1. Abre la carpeta del proyecto en VS Code.
2. Si usas la extensión **Live Server**:
   - Haz clic derecho en `index.html` y selecciona **"Open with Live Server"**.
   - El sistema se abrirá en `http://127.0.0.1:5500` en tu Laptop.

### Paso B: Conocer la dirección IP de tu Laptop en la red Wi-Fi
1. Abre la terminal (PowerShell o CMD) en tu Laptop.
2. Escribe:
   ```bash
   ipconfig
   ```
3. Busca la línea que dice **Dirección IPv4** (por ejemplo: `192.168.1.75`).
4. La dirección de acceso para los teléfonos será:
   ```
   http://192.168.1.75:5500/index.html
   ```

---

## 📱 2. Ejecutar la App en Teléfonos con Flutter

En la carpeta [flutter_siai_rymco](file:///c:/Users/Sistemas/Documents/lupita/RYMCO%20lupita/flutter_siai_rymco) ya tienes preparado el proyecto de Flutter con diseño corporativo formal y configurador de IP en vivo.

### Paso 1: Instalar dependencias
Abre la terminal en la carpeta `flutter_siai_rymco` y ejecuta:
```bash
cd flutter_siai_rymco
flutter pub get
```

### Paso 2: Ejecutar en el teléfono o emulador
Conecta tu teléfono Android o iPhone por cable USB (con depuración USB activa) y ejecuta:
```bash
flutter run
```

### Paso 3: Conectar la App con tu Laptop
1. Al abrir la app en el teléfono, si aún no detecta la IP, toca el botón de **Configuración de Red (icono de ethernet)** en la barra superior.
2. Escribe la IP de tu laptop (ejemplo: `http://192.168.1.75:5500/index.html`) y presiona **Conectar**.
3. ¡Listo! Todo el sistema se cargará en el teléfono en pantalla completa, adaptado al móvil y con diseño corporativo.

---

## 📦 3. Generar el Archivo Instalador (.APK) para Android

Si deseas instalar la aplicación directamente en los teléfonos de los encargados y trabajadores sin necesidad de tener el cable conectado a la laptop:

```bash
cd flutter_siai_rymco
flutter build apk --release
```

El archivo APK generado se guardará en:
`flutter_siai_rymco/build/app/outputs/flutter-apk/app-release.apk`

Solo envías ese archivo por WhatsApp o correo a los teléfonos para que lo instalen.

---

## 👥 Credenciales de Acceso Rápidas

* **Administrador:** `admin` / `admin123`
* **Encargado de Planta:** `encargado` / `encargado123`
* **Trabajador / Operador:** `usuario` / `user123`
