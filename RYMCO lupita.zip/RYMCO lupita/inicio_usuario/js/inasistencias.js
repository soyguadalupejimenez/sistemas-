// ==========================================================================
// SIAI RYMCO - MÓDULO DE AVISOS DE INASISTENCIA (TRABAJADOR)
// ==========================================================================

let userInasistenciasList = [];
let inasistenciaSeleccionadaId = null;
let fotoInasistenciaTempBase64 = '';

// Cargar inasistencias desde Firebase / LocalStorage
async function cargarInasistenciasUsuario() {
    let cargadas = [];

    if (typeof firebase !== 'undefined' && firebase.firestore) {
        try {
            const db = firebase.firestore();
            const snap = await db.collection('avisos_inasistencia').orderBy('creadoEl', 'desc').get();
            snap.forEach(doc => {
                cargadas.push({ id: doc.id, ...doc.data() });
            });
        } catch (e) {
            console.warn('[Firebase Inasistencias Trabajador]:', e);
        }
    }

    if (cargadas.length === 0) {
        const local = localStorage.getItem('rymco_avisos_inasistencia');
        if (local) {
            try { cargadas = JSON.parse(local); } catch (e) {}
        }
    }

    // Filtrar solo las del usuario actual
    let user = {};
    try { user = JSON.parse(localStorage.getItem('siai_usuario') || '{}'); } catch(e){}
    const curUser = user.username || user.nombre_completo || 'operador1';

    userInasistenciasList = cargadas.filter(a => 
        a.creadoPorUsername === curUser || 
        a.creadoPorNombre === user.nombre_completo || 
        !a.creadoPorUsername // Demo
    );

    actualizarBadgeInasistenciasUsuario();
    renderInasistenciasUsuario();
}

function actualizarBadgeInasistenciasUsuario() {
    const badge = document.getElementById('sidebarUserInasistenciasCount');
    if (!badge) return;

    const count = userInasistenciasList.filter(a => a.estado === 'Aviso Enviado').length;
    if (count > 0) {
        badge.textContent = count;
        badge.style.display = 'inline-block';
    } else {
        badge.style.display = 'none';
    }
}

function renderInasistenciasUsuario() {
    const container = document.getElementById('userInasistenciasGridContainer');
    if (!container) return;
    container.innerHTML = '';

    if (userInasistenciasList.length === 0) {
        container.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 36px 20px; background: rgba(255, 255, 255, 0.02); border: 1px dashed rgba(255, 255, 255, 0.1); border-radius: 16px;">
                <h4 style="color: #FFFFFF; font-size: 1.15rem; margin: 0 0 6px 0;">No tienes avisos de inasistencia registrados</h4>
                <p style="color: #94A3B8; font-size: 0.9rem; margin: 0;">Cuando tengas algún imprevisto que te impida acudir a tu turno, puedes notificarlo en el formulario superior.</p>
            </div>
        `;
        return;
    }

    userInasistenciasList.forEach(a => {
        let badgeEstadoStyle = 'background: rgba(245, 158, 11, 0.25); color: #FCD34D; border: 1px solid rgba(245, 158, 11, 0.4);';
        if (a.estado === 'Enterado') {
            badgeEstadoStyle = 'background: rgba(16, 185, 129, 0.25); color: #6EE7B7; border: 1px solid rgba(16, 185, 129, 0.4);';
        }

        const totalMsg = Array.isArray(a.mensajes) ? a.mensajes.length : 0;
        const rango = a.fechaInicio === a.fechaFin ? a.fechaInicio : `${a.fechaInicio} al ${a.fechaFin}`;

        const card = document.createElement('div');
        card.className = 'junta-card';
        card.innerHTML = `
            <div>
                <div class="junta-card-header">
                    <span class="badge-tipo-junta tipo-urgente">${a.tipoMotivo || 'Inasistencia'}</span>
                    <span style="font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 10px; ${badgeEstadoStyle}">${a.estado === 'Enterado' ? 'Enterado por Administración' : 'Aviso Enviado'}</span>
                </div>
                <h3 class="junta-title" style="font-size: 1.1rem;">Ausencia: ${rango}</h3>
                
                <div class="junta-meta-row">
                    <div class="junta-meta-item">
                        <span>Notificado a: <strong>${a.adminDestinatarioNombre}</strong></span>
                    </div>
                    <div class="junta-meta-item">
                        <span>Enviado: <strong>${a.fechaEnvio || 'Reciente'}</strong></span>
                    </div>
                </div>

                ${a.fotoUrl ? `
                    <div style="margin-bottom: 12px; text-align: center; background: rgba(0,0,0,0.25); padding: 8px; border-radius: 8px;">
                        <img src="${a.fotoUrl}" style="max-height: 120px; border-radius: 6px; cursor: pointer; max-width: 100%;" onclick="window.open('${a.fotoUrl}', '_blank')">
                        <small style="display: block; font-size: 0.7rem; color: #38BDF8; margin-top: 3px;">Comprobante adjunto</small>
                    </div>
                ` : ''}

                <div class="junta-desc">
                    <strong>Motivo expuesto:</strong><br>
                    ${a.motivoDetallado.length > 130 ? a.motivoDetallado.substring(0, 130) + '...' : a.motivoDetallado}
                </div>
            </div>

            <div class="junta-footer">
                <button type="button" class="btn-confirmar-asistencia" onclick="abrirModalInasistenciaUser('${a.id}')" style="background: rgba(245, 158, 11, 0.2); color: #FCD34D; border-color: rgba(245, 158, 11, 0.4);">
                    Ver Respuesta / Diálogo (${totalMsg})
                </button>
                <span style="font-size: 0.78rem; color: #94A3B8;">
                    ${a.estado === 'Enterado' ? 'Enterado por Admin' : 'Pendiente'}
                </span>
            </div>
        `;
        container.appendChild(card);
    });
}

// Previsualización y compresión de fotos
function userPrevisualizarFotoInasistencia(e) {
    const file = e.target.files[0];
    if (!file) return;

    document.getElementById('user-inasistencia-foto-nombre').textContent = file.name;

    const reader = new FileReader();
    reader.onload = function(evt) {
        const img = new Image();
        img.onload = function() {
            const canvas = document.createElement('canvas');
            const MAX_WIDTH = 900;
            const scale = MAX_WIDTH / img.width;
            if (scale < 1) {
                canvas.width = MAX_WIDTH;
                canvas.height = img.height * scale;
            } else {
                canvas.width = img.width;
                canvas.height = img.height;
            }
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            fotoInasistenciaTempBase64 = canvas.toDataURL('image/jpeg', 0.7);

            const preview = document.getElementById('user-inasistencia-foto-preview');
            const wrapper = document.getElementById('user-inasistencia-preview-wrapper');
            preview.src = fotoInasistenciaTempBase64;
            wrapper.style.display = 'block';
        };
        img.src = evt.target.result;
    };
    reader.readAsDataURL(file);
}

function userQuitarFotoInasistencia() {
    fotoInasistenciaTempBase64 = '';
    document.getElementById('user-inasistencia-foto-input').value = '';
    document.getElementById('user-inasistencia-foto-nombre').textContent = 'Sin foto adjunta';
    document.getElementById('user-inasistencia-preview-wrapper').style.display = 'none';
}

// Enviar Aviso de Inasistencia
async function userEnviarInasistencia(e) {
    e.preventDefault();

    let user = {};
    try { user = JSON.parse(localStorage.getItem('siai_usuario') || '{}'); } catch(e){}

    const adminDest = document.getElementById('user-inasistencia-admin-dest').value;
    const tipo = document.getElementById('user-inasistencia-tipo').value;
    const fInicio = document.getElementById('user-inasistencia-fecha-inicio').value;
    const fFin = document.getElementById('user-inasistencia-fecha-fin').value;
    const motivo = document.getElementById('user-inasistencia-motivo').value.trim();

    if (!fInicio || !fFin || !motivo) {
        alert('Por favor completa las fechas y la explicación del motivo.');
        return;
    }

    const now = new Date();
    const fechaStr = now.toLocaleDateString('es-MX') + ' ' + now.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });

    const nuevoAviso = {
        id: 'inasis_' + Date.now(),
        tipoMotivo: tipo,
        adminDestinatarioNombre: adminDest,
        fechaInicio: fInicio,
        fechaFin: fFin,
        motivoDetallado: motivo,
        fotoUrl: fotoInasistenciaTempBase64 || '',
        estado: 'Aviso Enviado',
        fechaEnvio: fechaStr,
        creadoPorNombre: user.nombre_completo || 'Trabajador Operativo',
        creadoPorUsername: user.username || 'operador1',
        creadoPorPuesto: user.puesto || 'Trabajador',
        creadoEl: now.toISOString(),
        mensajes: [
            {
                autor: user.nombre_completo || 'Trabajador Operativo',
                rol: 'Trabajador',
                fecha: fechaStr,
                mensaje: `Notificación de inasistencia del ${fInicio} al ${fFin}. Motivo: ${motivo}`
            }
        ]
    };

    // 1. Guardar Localmente
    const todas = JSON.parse(localStorage.getItem('rymco_avisos_inasistencia') || '[]');
    todas.unshift(nuevoAviso);
    localStorage.setItem('rymco_avisos_inasistencia', JSON.stringify(todas));

    userInasistenciasList.unshift(nuevoAviso);

    // 2. Guardar en Firestore
    if (typeof firebase !== 'undefined' && firebase.firestore) {
        try {
            const db = firebase.firestore();
            await db.collection('avisos_inasistencia').doc(nuevoAviso.id).set(nuevoAviso);
        } catch(err) {
            console.warn('[Firebase] Error guardando inasistencia:', err);
        }
    }

    // Resetear formulario
    document.getElementById('form-user-crear-inasistencia').reset();
    userQuitarFotoInasistencia();
    actualizarBadgeInasistenciasUsuario();
    renderInasistenciasUsuario();
    alert('Aviso de inasistencia enviado a ' + adminDest + '. El administrador ha sido notificado.');
}

// Modal de detalle
function abrirModalInasistenciaUser(id) {
    const a = userInasistenciasList.find(item => item.id === id);
    if (!a) return;
    inasistenciaSeleccionadaId = id;

    const rango = a.fechaInicio === a.fechaFin ? a.fechaInicio : `${a.fechaInicio} al ${a.fechaFin}`;
    document.getElementById('modalUserInasisTitulo').textContent = `Inasistencia: ${rango}`;
    document.getElementById('modalUserInasisAdminDest').textContent = `Destinatario: ${a.adminDestinatarioNombre}`;
    document.getElementById('modalUserInasisFechas').textContent = rango;
    document.getElementById('modalUserInasisTipo').textContent = a.tipoMotivo;
    document.getElementById('modalUserInasisFechaEnvio').textContent = a.fechaEnvio || 'Reciente';
    document.getElementById('modalUserInasisDesc').textContent = a.motivoDetallado;

    const estEl = document.getElementById('modalUserInasisEstadoBadge');
    if (estEl) {
        estEl.textContent = a.estado === 'Enterado' ? 'Enterado por Administración' : 'Aviso Enviado';
        estEl.style.background = a.estado === 'Enterado' ? 'rgba(16, 185, 129, 0.25)' : 'rgba(245, 158, 11, 0.25)';
        estEl.style.color = a.estado === 'Enterado' ? '#6EE7B7' : '#FCD34D';
    }

    // Foto
    const fotoBox = document.getElementById('modalUserInasisFotoBox');
    const fotoImg = document.getElementById('modalUserInasisFotoImg');
    if (a.fotoUrl) {
        fotoBox.style.display = 'block';
        fotoImg.src = a.fotoUrl;
    } else {
        fotoBox.style.display = 'none';
    }

    // Renderizar hilo
    renderHiloMensajesInasistenciaUser(a);

    const modal = document.getElementById('modal-detalle-inasistencia-user');
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.remove('panel-hidden');
    }
}

function renderHiloMensajesInasistenciaUser(a) {
    const container = document.getElementById('modalUserInasisHiloRespuestas');
    if (!container) return;
    container.innerHTML = '';

    const msgs = Array.isArray(a.mensajes) ? a.mensajes : [];
    if (msgs.length === 0) {
        container.innerHTML = `<div style="font-size: 0.8rem; color: #94A3B8; text-align: center; padding: 10px;">Esperando acuse del Administrador...</div>`;
        return;
    }

    msgs.forEach(msg => {
        const esAdmin = msg.rol && msg.rol.toLowerCase().includes('admin');
        const div = document.createElement('div');
        div.style.background = esAdmin ? 'rgba(245, 158, 11, 0.12)' : 'rgba(255, 255, 255, 0.04)';
        div.style.border = esAdmin ? '1px solid rgba(245, 158, 11, 0.3)' : '1px solid rgba(255, 255, 255, 0.08)';
        div.style.borderRadius = '8px';
        div.style.padding = '8px 12px';

        div.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2px;">
                <span style="font-weight: 700; font-size: 0.8rem; color: ${esAdmin ? '#FCD34D' : '#FFFFFF'};">
                    ${msg.autor} (${msg.rol}):
                </span>
                <span style="font-size: 0.7rem; color: #94A3B8;">${msg.fecha}</span>
            </div>
            <div style="font-size: 0.86rem; color: #E2E8F0; line-height: 1.35;">
                ${msg.mensaje}
            </div>
        `;
        container.appendChild(div);
    });
}

function cerrarModalInasistenciaUser() {
    const modal = document.getElementById('modal-detalle-inasistencia-user');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.add('panel-hidden');
    }
    inasistenciaSeleccionadaId = null;
}

// Responder
async function guardarRespuestaInasistenciaUser() {
    if (!inasistenciaSeleccionadaId) return;
    const a = userInasistenciasList.find(item => item.id === inasistenciaSeleccionadaId);
    if (!a) return;

    const input = document.getElementById('modalUserInasisRespuestaInput');
    const texto = input.value.trim();

    if (!texto) {
        alert('Por favor escribe un mensaje antes de enviar.');
        return;
    }

    let user = {};
    try { user = JSON.parse(localStorage.getItem('siai_usuario') || '{}'); } catch(e){}

    const now = new Date();
    const fechaStr = now.toLocaleDateString('es-MX') + ' ' + now.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });

    if (!Array.isArray(a.mensajes)) a.mensajes = [];

    a.mensajes.push({
        autor: user.nombre_completo || 'Trabajador Operativo',
        rol: 'Trabajador',
        fecha: fechaStr,
        mensaje: texto
    });

    // Guardar en LocalStorage
    const todas = JSON.parse(localStorage.getItem('rymco_avisos_inasistencia') || '[]');
    const idx = todas.findIndex(item => item.id === a.id);
    if (idx > -1) {
        todas[idx].mensajes = a.mensajes;
        localStorage.setItem('rymco_avisos_inasistencia', JSON.stringify(todas));
    }

    // Guardar en Firestore
    if (typeof firebase !== 'undefined' && firebase.firestore) {
        try {
            const db = firebase.firestore();
            await db.collection('avisos_inasistencia').doc(a.id).update({
                mensajes: a.mensajes
            });
        } catch(err) {
            console.warn('[Firebase] Error al guardar mensaje:', err);
        }
    }

    input.value = '';
    renderHiloMensajesInasistenciaUser(a);
    alert('Mensaje enviado al Administrador.');
}

window.userPrevisualizarFotoInasistencia = userPrevisualizarFotoInasistencia;
window.userQuitarFotoInasistencia = userQuitarFotoInasistencia;
window.userEnviarInasistencia = userEnviarInasistencia;
window.abrirModalInasistenciaUser = abrirModalInasistenciaUser;
window.cerrarModalInasistenciaUser = cerrarModalInasistenciaUser;
window.guardarRespuestaInasistenciaUser = guardarRespuestaInasistenciaUser;
