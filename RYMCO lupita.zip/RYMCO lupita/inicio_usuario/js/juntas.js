// ==========================================================================
// SIAI RYMCO - MÓDULO DE AVISO DE JUNTAS (TRABAJADOR)
// ==========================================================================

let userJuntasList = [];
let userFiltroJuntasActual = 'proximas';

const monthNamesWorker = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];
const dayNamesWorker = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

const defaultWorkerJuntas = [
    {
        id: 'junta_demo_1',
        titulo: 'Reunión de Seguridad y Revisión de Producción',
        fecha: '2026-09-04',
        hora: '10:00',
        tipo: 'Seguridad',
        audiencia: 'Todos',
        lugar: 'Sala de Juntas Planta 1',
        agenda: '1. Revisión de protocolos de EPP en área de rolado.\n2. Análisis de metas de producción de la semana.\n3. Asuntos generales.',
        convocadoPor: 'Administración General',
        asistentesConfirmados: ['operador1'],
        creadaEl: new Date().toISOString()
    },
    {
        id: 'junta_demo_worker_2',
        titulo: 'Capacitación Operativa: Calidad en Tubería Conduit',
        fecha: '2026-09-08',
        hora: '15:00',
        tipo: 'Capacitación',
        audiencia: 'Operadores y Trabajadores',
        lugar: 'Comedor Principal / Auditorio',
        agenda: 'Normativas de calidad galvanizado, inspección de costura y empaque.',
        convocadoPor: 'Dpto. de Calidad',
        asistentesConfirmados: [],
        creadaEl: new Date().toISOString()
    }
];

// Cargar y sincronizar juntas desde Firestore / LocalStorage
async function cargarJuntasUsuario() {
    let cargadas = [];

    if (typeof firebase !== 'undefined' && firebase.firestore) {
        try {
            const db = firebase.firestore();
            const snap = await db.collection('juntas').orderBy('fecha', 'asc').get();
            snap.forEach(doc => {
                cargadas.push({ id: doc.id, ...doc.data() });
            });
        } catch (e) {
            console.warn('[Firebase Juntas Trabajador]:', e);
        }
    }

    if (cargadas.length === 0) {
        const local = localStorage.getItem('rymco_juntas_lista');
        if (local) {
            try {
                cargadas = JSON.parse(local);
            } catch (e) {}
        }
    }

    if (cargadas.length === 0) {
        cargadas = defaultWorkerJuntas;
        localStorage.setItem('rymco_juntas_lista', JSON.stringify(cargadas));
    }

    // Filtrar juntas dirigidas a Trabajadores ("Todos" o "Operadores y Trabajadores")
    userJuntasList = cargadas.filter(j => 
        !j.audiencia || 
        j.audiencia === 'Todos' || 
        j.audiencia === 'Operadores y Trabajadores' || 
        j.audiencia === 'Trabajadores' || 
        j.audiencia === 'Operadores'
    );

    actualizarContadoresJuntasUsuario();
    renderJuntasUsuario();
    actualizarBannerAlertaUsuario();
    if (typeof renderCalendar === 'function') renderCalendar();
}

function actualizarContadoresJuntasUsuario() {
    const hoyISO = new Date().toISOString().split('T')[0];
    let countProx = 0;
    let countH = 0;
    let countHist = 0;

    userJuntasList.forEach(j => {
        if (j.fecha === hoyISO) {
            countH++;
            countProx++;
        } else if (j.fecha > hoyISO) {
            countProx++;
        } else {
            countHist++;
        }
    });

    const elP = document.getElementById('countProximas');
    const elH = document.getElementById('countHoy');
    const elHist = document.getElementById('countHistorial');
    const elSide = document.getElementById('sidebarJuntasCount');

    if (elP) elP.textContent = countProx;
    if (elH) elH.textContent = countH;
    if (elHist) elHist.textContent = countHist;
    if (elSide) {
        elSide.textContent = countProx;
        elSide.style.display = countProx > 0 ? 'inline-block' : 'none';
    }
}

function filtrarJuntasUsuario(tipo) {
    userFiltroJuntasActual = tipo;
    document.querySelectorAll('#juntas-panel-container .juntas-tab-btn').forEach(btn => btn.classList.remove('active'));
    const activeBtn = document.getElementById(`tab-${tipo}`);
    if (activeBtn) activeBtn.classList.add('active');
    renderJuntasUsuario();
}

function renderJuntasUsuario() {
    const container = document.getElementById('juntasGridContainer');
    if (!container) return;
    container.innerHTML = '';

    const hoyISO = new Date().toISOString().split('T')[0];
    let filtered = [];

    if (userFiltroJuntasActual === 'proximas') {
        filtered = userJuntasList.filter(j => j.fecha >= hoyISO);
    } else if (userFiltroJuntasActual === 'hoy') {
        filtered = userJuntasList.filter(j => j.fecha === hoyISO);
    } else {
        filtered = userJuntasList.filter(j => j.fecha < hoyISO);
    }

    if (filtered.length === 0) {
        container.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 40px 20px; background: rgba(255, 255, 255, 0.02); border: 1px dashed rgba(255, 255, 255, 0.1); border-radius: 16px;">
                <h4 style="color: #FFFFFF; font-size: 1.15rem; margin: 0 0 6px 0;">No hay juntas programadas en esta sección</h4>
                <p style="color: #94A3B8; font-size: 0.9rem; margin: 0;">Cuando la Administración convoque a una reunión para tu área o planta general, aparecerá aquí.</p>
            </div>
        `;
        return;
    }

    let user = {};
    try {
        user = JSON.parse(localStorage.getItem('siai_usuario') || '{}');
    } catch (e) {}
    const currentUsername = user.username || user.nombre_completo || 'operador1';

    filtered.forEach(j => {
        const tipoClass = j.tipo === 'Urgente' ? 'tipo-urgente' : (j.tipo === 'Seguridad' ? 'tipo-seguridad' : (j.tipo === 'Capacitación' ? 'tipo-capacitacion' : 'tipo-ordinaria'));
        
        let tiempoBadge = '';
        if (j.fecha === hoyISO) {
            tiempoBadge = `<span class="junta-countdown-badge" style="background: rgba(239, 68, 68, 0.25); color: #FCA5A5; border: 1px solid rgba(239, 68, 68, 0.4);">Hoy a las ${j.hora}</span>`;
        } else if (j.fecha > hoyISO) {
            const diffDays = Math.ceil((new Date(j.fecha) - new Date(hoyISO)) / (1000 * 60 * 60 * 24));
            tiempoBadge = `<span class="junta-countdown-badge">En ${diffDays} día(s)</span>`;
        } else {
            tiempoBadge = `<span class="junta-countdown-badge" style="opacity: 0.7;">Concluida</span>`;
        }

        const yaConfirmo = Array.isArray(j.asistentesConfirmados) && j.asistentesConfirmados.includes(currentUsername);
        const totalAsistentes = Array.isArray(j.asistentesConfirmados) ? j.asistentesConfirmados.length : 0;

        const card = document.createElement('div');
        card.className = 'junta-card';
        card.innerHTML = `
            <div>
                <div class="junta-card-header">
                    <span class="badge-tipo-junta ${tipoClass}">${j.tipo || 'Ordinaria'}</span>
                    ${tiempoBadge}
                </div>
                <h3 class="junta-title">${j.titulo}</h3>
                
                <div class="junta-meta-row">
                    <div class="junta-meta-item">
                        <span>Fecha:</span> <strong>${formatearFechaLargaWorker(j.fecha)}</strong> a las <strong>${j.hora} hrs</strong>
                    </div>
                    <div class="junta-meta-item">
                        <span>Lugar:</span> <span>${j.lugar || 'Sala de Juntas'}</span>
                    </div>
                    <div class="junta-meta-item">
                        <span>Dirigido a:</span> <span><strong>${j.audiencia || 'Todos'}</strong></span>
                    </div>
                    <div class="junta-meta-item">
                        <span>Convocado por:</span> <span><strong>${j.convocadoPor || 'Administración'}</strong></span>
                    </div>
                </div>

                <div class="junta-desc">
                    <strong>Agenda de la Reunión:</strong><br>
                    ${j.agenda ? j.agenda.replace(/\n/g, '<br>') : 'Sin agenda detallada.'}
                </div>
            </div>

            <div class="junta-footer">
                <button type="button" class="btn-confirmar-asistencia ${yaConfirmo ? 'confirmado' : ''}" onclick="toggleConfirmarAsistenciaUsuario('${j.id}')">
                    ${yaConfirmo ? 'Asistencia Confirmada' : 'Confirmar Asistencia'}
                </button>
                <span class="btn-ver-asistentes" title="${totalAsistentes} personas han confirmado">
                    ${totalAsistentes} confirmados
                </span>
            </div>
        `;
        container.appendChild(card);
    });
}

function formatearFechaLargaWorker(isoDate) {
    if (!isoDate) return '--';
    const parts = isoDate.split('-');
    if (parts.length < 3) return isoDate;
    const d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
    return `${dayNamesWorker[d.getDay()]} ${d.getDate()} de ${monthNamesWorker[d.getMonth()]}`;
}

async function toggleConfirmarAsistenciaUsuario(juntaId) {
    let user = {};
    try {
        user = JSON.parse(localStorage.getItem('siai_usuario') || '{}');
    } catch (e) {}
    const currentUsername = user.username || user.nombre_completo || 'operador1';

    const todas = JSON.parse(localStorage.getItem('rymco_juntas_lista') || '[]');
    const juntaGlobal = todas.find(j => j.id === juntaId);
    const junta = userJuntasList.find(j => j.id === juntaId);
    if (!junta) return;

    if (!Array.isArray(junta.asistentesConfirmados)) {
        junta.asistentesConfirmados = [];
    }
    if (juntaGlobal && !Array.isArray(juntaGlobal.asistentesConfirmados)) {
        juntaGlobal.asistentesConfirmados = [];
    }

    const idx = junta.asistentesConfirmados.indexOf(currentUsername);
    if (idx > -1) {
        junta.asistentesConfirmados.splice(idx, 1);
        if (juntaGlobal) juntaGlobal.asistentesConfirmados.splice(juntaGlobal.asistentesConfirmados.indexOf(currentUsername), 1);
    } else {
        junta.asistentesConfirmados.push(currentUsername);
        if (juntaGlobal && !juntaGlobal.asistentesConfirmados.includes(currentUsername)) {
            juntaGlobal.asistentesConfirmados.push(currentUsername);
        }
    }

    // Guardar local
    localStorage.setItem('rymco_juntas_lista', JSON.stringify(todas.length > 0 ? todas : userJuntasList));

    // Guardar Firebase
    if (typeof firebase !== 'undefined' && firebase.firestore) {
        try {
            const db = firebase.firestore();
            await db.collection('juntas').doc(juntaId).update({
                asistentesConfirmados: junta.asistentesConfirmados
            });
        } catch (e) {
            console.warn('[Firebase] Error al confirmar asistencia:', e);
        }
    }

    renderJuntasUsuario();
    actualizarBannerAlertaUsuario();
}

function actualizarBannerAlertaUsuario() {
    const banner = document.getElementById('juntaAlertBanner');
    if (!banner) return;

    const hoyISO = new Date().toISOString().split('T')[0];
    const proximaJunta = userJuntasList.find(j => j.fecha >= hoyISO);

    if (proximaJunta) {
        banner.style.display = 'flex';
        banner.classList.remove('panel-hidden');
        const elTit = document.getElementById('bannerJuntaTitulo');
        const elDet = document.getElementById('bannerJuntaDetalle');
        if (elTit) elTit.textContent = `Próxima Junta: ${proximaJunta.titulo}`;
        if (elDet) elDet.textContent = `${formatearFechaLargaWorker(proximaJunta.fecha)} • ${proximaJunta.hora} hrs • ${proximaJunta.lugar} • Dirigido a: ${proximaJunta.audiencia}`;
        
        let user = {};
        try { user = JSON.parse(localStorage.getItem('siai_usuario') || '{}'); } catch(e){}
        const currentUsername = user.username || user.nombre_completo || 'operador1';
        const yaConfirmo = Array.isArray(proximaJunta.asistentesConfirmados) && proximaJunta.asistentesConfirmados.includes(currentUsername);
        
        const btnB = document.getElementById('btnBannerConfirmar');
        if (btnB) {
            btnB.className = `btn-confirmar-asistencia ${yaConfirmo ? 'confirmado' : ''}`;
            btnB.textContent = yaConfirmo ? 'Asistencia Confirmada' : 'Confirmar Asistencia';
            btnB.onclick = () => toggleConfirmarAsistenciaUsuario(proximaJunta.id);
        }
    } else {
        banner.style.display = 'none';
        banner.classList.add('panel-hidden');
    }
}
