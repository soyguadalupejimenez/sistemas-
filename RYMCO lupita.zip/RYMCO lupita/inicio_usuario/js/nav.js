// ==========================================================================
// SIAI RYMCO - NAVEGACIÓN Y PERFIL DE TRABAJADOR / OPERADOR
// ==========================================================================

function showUserPanel(panelId) {
    const panels = [
        'juntas-panel-container',
        'mediacion-panel-container',
        'inasistencias-panel-container',
        'avisos-panel-container',
        'calendario-panel-container'
    ];
    
    panels.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.style.display = 'none';
            el.classList.remove('panel-block');
            el.classList.add('panel-hidden');
        }
    });

    const target = document.getElementById(panelId);
    if (target) {
        target.style.display = 'block';
        target.classList.remove('panel-hidden');
        target.classList.add('panel-block');
    }

    document.querySelectorAll('.admin-nav-item').forEach(li => li.classList.remove('active'));
    if (panelId === 'juntas-panel-container') {
        const item = document.getElementById('menu-juntas');
        if (item) item.classList.add('active');
        if (typeof renderJuntasUsuario === 'function') renderJuntasUsuario();
    } else if (panelId === 'mediacion-panel-container') {
        const item = document.getElementById('menu-mediacion');
        if (item) item.classList.add('active');
        if (typeof renderMediacionesUsuario === 'function') renderMediacionesUsuario();
    } else if (panelId === 'inasistencias-panel-container') {
        const item = document.getElementById('menu-inasistencias');
        if (item) item.classList.add('active');
        if (typeof renderInasistenciasUsuario === 'function') renderInasistenciasUsuario();
    } else if (panelId === 'avisos-panel-container') {
        const item = document.getElementById('menu-avisos');
        if (item) item.classList.add('active');
    } else if (panelId === 'calendario-panel-container') {
        const item = document.getElementById('menu-calendario');
        if (item) item.classList.add('active');
        if (typeof renderCalendar === 'function') renderCalendar();
    }

    // Cerrar sidebar en pantallas reducidas para mostrar el panel limpio
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    if (sidebar) {
        sidebar.classList.remove('open', 'sidebar-open');
        if (overlay) overlay.classList.remove('active');
    }
}

// Perfil de Usuario
async function mostrarPerfilUsuarioModal() {
    const modal = document.getElementById('modal-perfil-usuario');
    if (!modal) return;

    let user = {};
    try {
        const raw = localStorage.getItem('siai_usuario');
        if (raw) user = JSON.parse(raw);
    } catch (e) {}

    const elFull = document.getElementById('modalUserFullName');
    const elRole = document.getElementById('modalUserRole');
    const elUser = document.getElementById('modalUsername');
    const elWork = document.getElementById('modalWorkerId');
    const elMail = document.getElementById('modalUserEmail');

    if (elFull) elFull.textContent = user.nombre_completo || 'Operador de Planta';
    if (elRole) elRole.textContent = user.puesto || 'Trabajador';
    if (elUser) elUser.textContent = user.username || '--';
    if (elWork) elWork.textContent = user.num_trabajador || 'OP-202';
    if (elMail) elMail.textContent = user.email || 'operador@rymco.com';

    modal.style.display = 'flex';
    modal.classList.remove('panel-hidden');
}

function cerrarPerfilUsuarioModal() {
    const modal = document.getElementById('modal-perfil-usuario');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.add('panel-hidden');
    }
}

// Cerrar modales con clic afuera
window.addEventListener('click', function(e) {
    const m1 = document.getElementById('modal-perfil-usuario');
    const m2 = document.getElementById('modal-dia-detalle');
    const m3 = document.getElementById('modal-detalle-mediacion-user');
    const m4 = document.getElementById('modal-detalle-inasistencia-user');
    if (e.target === m1) cerrarPerfilUsuarioModal();
    if (e.target === m2 && typeof cerrarDetalleDia === 'function') cerrarDetalleDia();
    if (e.target === m3 && typeof cerrarModalMediacionUser === 'function') cerrarModalMediacionUser();
    if (e.target === m4 && typeof cerrarModalInasistenciaUser === 'function') cerrarModalInasistenciaUser();
});

// Inicialización de la sesión del Trabajador
document.addEventListener('DOMContentLoaded', function () {
    try {
        const raw = localStorage.getItem('siai_usuario');
        if (raw) {
            const u = JSON.parse(raw);
            if (u.nombre_completo) {
                const elName = document.getElementById('displayUserName');
                if (elName) elName.innerHTML = u.nombre_completo + '<br><span>RYMCO S.A. (' + (u.puesto || 'Trabajador') + ')</span>';
                const elTop = document.getElementById('topUserLabel');
                if (elTop) elTop.textContent = u.nombre_completo;
            }
        }
    } catch (e) { }

    // Asegurar que el sidebar y overlay inicien cerrados en dispositivos móviles
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    if (sidebar) sidebar.classList.remove('open', 'sidebar-open');
    if (overlay) overlay.classList.remove('active');

    // Menú móvil / Toggle
    const toggleBtn = document.getElementById('sidebar-toggle');
    if (toggleBtn && sidebar && overlay) {
        toggleBtn.addEventListener('click', () => {
            const isOpen = sidebar.classList.contains('open') || sidebar.classList.contains('sidebar-open');
            if (isOpen) {
                sidebar.classList.remove('open', 'sidebar-open');
                overlay.classList.remove('active');
            } else {
                sidebar.classList.add('open', 'sidebar-open');
                overlay.classList.add('active');
            }
        });
        overlay.addEventListener('click', () => {
            sidebar.classList.remove('open', 'sidebar-open');
            overlay.classList.remove('active');
        });
    }

    // Cargar datos
    if (typeof cargarJuntasUsuario === 'function') cargarJuntasUsuario();
    if (typeof cargarMediacionesUsuario === 'function') cargarMediacionesUsuario();
    if (typeof cargarInasistenciasUsuario === 'function') cargarInasistenciasUsuario();
    if (typeof renderCalendar === 'function') renderCalendar();
    if (typeof cargarAvisosDesdeFirebase === 'function') cargarAvisosDesdeFirebase();
});
