// ==========================================================================
// SIAI RYMCO - MÓDULO DE TABLÓN DE AVISOS Y COMUNICADOS (TRABAJADOR)
// ==========================================================================

async function cargarAvisosDesdeFirebase() {
    if (typeof firebase === 'undefined' || !firebase.firestore) return;
    try {
        const db = firebase.firestore();
        const snap = await db.collection('avisos').orderBy('fecha', 'desc').limit(10).get();
        if (snap.empty) return;

        const container = document.getElementById('avisos-container-cards');
        if (!container) return;
        container.innerHTML = '';

        snap.forEach(doc => {
            const av = doc.data();
            const card = document.createElement('div');
            card.className = 'aviso-card';
            card.innerHTML = `
                <div>
                    <div class="aviso-card-top">
                        <span class="aviso-badge ${av.tipo === 'Seguridad' ? 'badge-seguridad' : (av.tipo === 'Urgente' ? 'badge-importante' : 'badge-general')}">${av.tipo || 'General'}</span>
                        <span class="aviso-fecha">${av.fecha || 'Reciente'}</span>
                    </div>
                    <div class="aviso-titulo">${av.titulo}</div>
                    <div class="aviso-cuerpo">${av.mensaje || av.cuerpo || ''}</div>
                </div>
                <div class="aviso-footer">
                    <span>Publicado por: ${av.autor || 'Administración'}</span>
                    <span>RYMCO S.A.</span>
                </div>
            `;
            container.appendChild(card);
        });
    } catch(e) {
        console.warn('[Firebase Avisos Trabajador]:', e);
    }
}
