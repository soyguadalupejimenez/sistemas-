// ==========================================================================
// SIAI RYMCO - MÓDULO DE MEDIACIÓN Y CONCILIACIÓN (TRABAJADOR)
// ==========================================================================

let userMediacionesList = [];
let mediacionSeleccionadaId = null;

// Cargar mediaciones desde Firebase / LocalStorage
async function cargarMediacionesUsuario() {
    let cargadas = [];

    if (typeof firebase !== 'undefined' && firebase.firestore) {
        try {
            const db = firebase.firestore();
            const snap = await db.collection('mediaciones_quejas').orderBy('creadoEl', 'desc').get();
            snap.forEach(doc => {
                cargadas.push({ id: doc.id, ...doc.data() });
            });
        } catch (e) {
            console.warn('[Firebase Mediaciones Trabajador]:', e);
        }
    }

    if (cargadas.length === 0) {
        const local = localStorage.getItem('rymco_mediaciones_quejas');
        if (local) {
            try { cargadas = JSON.parse(local); } catch (e) {}
        }
    }

    // Filtrar solo las creadas por el usuario actual o donde esté involucrado
    let user = {};
    try { user = JSON.parse(localStorage.getItem('siai_usuario') || '{}'); } catch(e){}
    const curUser = user.username || user.nombre_completo || 'operador1';

    userMediacionesList = cargadas.filter(m => 
        m.creadoPorUsername === curUser || 
        m.creadoPorNombre === user.nombre_completo || 
        !m.creadoPorUsername // Demo
    );

    actualizarBadgeMediacionesUsuario();
    renderMediacionesUsuario();
}

function actualizarBadgeMediacionesUsuario() {
    const badge = document.getElementById('sidebarUserMediacionCount');
    if (!badge) return;

    // Contar casos no concluidos
    const count = userMediacionesList.filter(m => m.estado !== 'Acuerdo Concluido' && m.estado !== 'Cerrado').length;
    if (count > 0) {
        badge.textContent = count;
        badge.style.display = 'inline-block';
    } else {
        badge.style.display = 'none';
    }
}

function renderMediacionesUsuario() {
    const container = document.getElementById('userMediacionesGridContainer');
    if (!container) return;
    container.innerHTML = '';

    if (userMediacionesList.length === 0) {
        container.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 36px 20px; background: rgba(255, 255, 255, 0.02); border: 1px dashed rgba(255, 255, 255, 0.1); border-radius: 16px;">
                <h4 style="color: #FFFFFF; font-size: 1.15rem; margin: 0 0 6px 0;">No tienes solicitudes de mediación activas</h4>
                <p style="color: #94A3B8; font-size: 0.9rem; margin: 0;">Si tienes algún desacuerdo laboral o inconveniente, llena el formulario superior para dialogar con el Administrador de tu elección.</p>
            </div>
        `;
        return;
    }

    userMediacionesList.forEach(m => {
        let estadoBadgeStyle = 'background: rgba(6, 182, 212, 0.2); color: #38BDF8; border: 1px solid rgba(6, 182, 212, 0.4);';
        if (m.estado === 'Citatorio Programado') {
            estadoBadgeStyle = 'background: rgba(245, 158, 11, 0.25); color: #FCD34D; border: 1px solid rgba(245, 158, 11, 0.4);';
        } else if (m.estado === 'Acuerdo Concluido') {
            estadoBadgeStyle = 'background: rgba(16, 185, 129, 0.25); color: #6EE7B7; border: 1px solid rgba(16, 185, 129, 0.4);';
        }

        const totalMsg = Array.isArray(m.mensajes) ? m.mensajes.length : 0;

        const card = document.createElement('div');
        card.className = 'junta-card';
        card.innerHTML = `
            <div>
                <div class="junta-card-header">
                    <span class="badge-tipo-junta tipo-ordinaria">${m.categoria || 'Mediación'}</span>
                    <span style="font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 10px; ${estadoBadgeStyle}">${m.estado}</span>
                </div>
                <h3 class="junta-title" style="font-size: 1.15rem;">${m.titulo}</h3>
                
                <div class="junta-meta-row">
                    <div class="junta-meta-item">
                        <span>Dirigido a: <strong>${m.adminDestinatarioNombre}</strong></span>
                    </div>
                    <div class="junta-meta-item">
                        <span>Involucrados: <strong>${m.involucrados || 'No especificados'}</strong></span>
                    </div>
                    <div class="junta-meta-item">
                        <span>Enviado: <strong>${m.fechaEnvio || 'Reciente'}</strong></span>
                    </div>
                </div>

                <div class="junta-desc">
                    <strong>Tu explicación:</strong><br>
                    ${m.descripcion.length > 130 ? m.descripcion.substring(0, 130) + '...' : m.descripcion}
                </div>
            </div>

            <div class="junta-footer">
                <button type="button" class="btn-confirmar-asistencia" onclick="abrirModalMediacionUser('${m.id}')" style="background: rgba(6, 182, 212, 0.2); color: #38BDF8; border-color: rgba(6, 182, 212, 0.4);">
                    Ver Diálogo y Acuerdos (${totalMsg})
                </button>
                <span style="font-size: 0.78rem; color: #94A3B8;">
                    ${m.estado === 'Acuerdo Concluido' ? 'Concluido' : 'En proceso'}
                </span>
            </div>
        `;
        container.appendChild(card);
    });
}

// Enviar Petición de Mediación
async function userEnviarMediacion(e) {
    e.preventDefault();

    let user = {};
    try { user = JSON.parse(localStorage.getItem('siai_usuario') || '{}'); } catch(e){}

    const adminDest = document.getElementById('user-med-admin-dest').value;
    const categoria = document.getElementById('user-med-categoria').value;
    const involucrados = document.getElementById('user-med-involucrados').value.trim();
    const titulo = document.getElementById('user-med-titulo').value.trim();
    const desc = document.getElementById('user-med-desc').value.trim();
    const propuesta = document.getElementById('user-med-propuesta').value.trim();

    if (!titulo || !desc) {
        alert('Por favor completa el título y la explicación de lo sucedido.');
        return;
    }

    const now = new Date();
    const fechaStr = now.toLocaleDateString('es-MX') + ' ' + now.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });

    const nuevaMediacion = {
        id: 'med_' + Date.now(),
        titulo: titulo,
        categoria: categoria,
        adminDestinatarioNombre: adminDest,
        involucrados: involucrados || 'No especificados',
        descripcion: desc,
        propuestaSolucion: propuesta || 'Sin propuesta inicial formulada.',
        estado: 'Enviado / Pendiente de Revisión',
        acuerdoFinal: '',
        fechaEnvio: fechaStr,
        creadoPorNombre: user.nombre_completo || 'Trabajador Operativo',
        creadoPorUsername: user.username || 'operador1',
        creadoPorPuesto: user.puesto || 'Trabajador',
        creadoEl: now.toISOString(),
        mensajes: [
            {
                autor: user.nombre_completo || 'Trabajador Operativo',
                rol: 'Trabajador',
                fecha: fechaStr,
                mensaje: desc
            }
        ]
    };

    // 1. Guardar Localmente
    const todas = JSON.parse(localStorage.getItem('rymco_mediaciones_quejas') || '[]');
    todas.unshift(nuevaMediacion);
    localStorage.setItem('rymco_mediaciones_quejas', JSON.stringify(todas));

    userMediacionesList.unshift(nuevaMediacion);

    // 2. Guardar en Firestore si está disponible
    if (typeof firebase !== 'undefined' && firebase.firestore) {
        try {
            const db = firebase.firestore();
            await db.collection('mediaciones_quejas').doc(nuevaMediacion.id).set(nuevaMediacion);
        } catch(err) {
            console.warn('[Firebase] Error guardando mediación:', err);
        }
    }

    // Resetear formulario
    document.getElementById('form-user-crear-mediacion').reset();
    actualizarBadgeMediacionesUsuario();
    renderMediacionesUsuario();
    alert('Tu solicitud de mediación ha sido enviada con total confidencialidad a ' + adminDest + '.');
}

// Abrir Modal de Diálogo
function abrirModalMediacionUser(id) {
    const med = userMediacionesList.find(m => m.id === id);
    if (!med) return;
    mediacionSeleccionadaId = id;

    document.getElementById('modalUserMedTitulo').textContent = med.titulo;
    document.getElementById('modalUserMedAdminDest').textContent = `Destinatario: ${med.adminDestinatarioNombre}`;
    document.getElementById('modalUserMedInvolucrados').textContent = med.involucrados || 'No especificados';
    document.getElementById('modalUserMedFecha').textContent = med.fechaEnvio || 'Reciente';
    document.getElementById('modalUserMedDesc').textContent = med.descripcion;

    const badge = document.getElementById('modalUserMedEstadoBadge');
    badge.textContent = med.estado;
    badge.style.background = med.estado === 'Acuerdo Concluido' ? 'rgba(16, 185, 129, 0.25)' : 'rgba(6, 182, 212, 0.25)';
    badge.style.color = med.estado === 'Acuerdo Concluido' ? '#6EE7B7' : '#38BDF8';

    // Propuesta inicial
    const propBox = document.getElementById('modalUserMedPropuestaBox');
    const propEl = document.getElementById('modalUserMedPropuesta');
    if (med.propuestaSolucion && med.propuestaSolucion !== 'Sin propuesta inicial formulada.') {
        propBox.style.display = 'block';
        propEl.textContent = med.propuestaSolucion;
    } else {
        propBox.style.display = 'none';
    }

    // Acuerdo concluido
    const acuerdoBox = document.getElementById('modalUserMedAcuerdoConcluidoBox');
    const acuerdoTxt = document.getElementById('modalUserMedAcuerdoTexto');
    if (med.estado === 'Acuerdo Concluido' && med.acuerdoFinal) {
        acuerdoBox.style.display = 'block';
        acuerdoTxt.textContent = med.acuerdoFinal;
    } else {
        acuerdoBox.style.display = 'none';
    }

    // Renderizar Mensajes del hilo
    renderHiloMensajesMediacionUser(med);

    const modal = document.getElementById('modal-detalle-mediacion-user');
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.remove('panel-hidden');
    }
}

function renderHiloMensajesMediacionUser(med) {
    const container = document.getElementById('modalUserMedHiloRespuestas');
    if (!container) return;
    container.innerHTML = '';

    const msgs = Array.isArray(med.mensajes) ? med.mensajes : [];
    if (msgs.length === 0) {
        container.innerHTML = `<div style="font-size: 0.8rem; color: #94A3B8; text-align: center; padding: 10px;">Esperando respuesta del Administrador...</div>`;
        return;
    }

    msgs.forEach(msg => {
        const esAdmin = msg.rol && msg.rol.toLowerCase().includes('admin');
        const div = document.createElement('div');
        div.style.background = esAdmin ? 'rgba(6, 182, 212, 0.12)' : 'rgba(255, 255, 255, 0.04)';
        div.style.border = esAdmin ? '1px solid rgba(6, 182, 212, 0.3)' : '1px solid rgba(255, 255, 255, 0.08)';
        div.style.borderRadius = '8px';
        div.style.padding = '8px 12px';

        div.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2px;">
                <span style="font-weight: 700; font-size: 0.8rem; color: ${esAdmin ? '#38BDF8' : '#FFFFFF'};">
                    ${msg.autor} (${msg.rol}):
                </span>
                <span style="font-size: 0.7rem; color: #94A3B8;">${msg.fecha}</span>
            </div>
            <div style="font-size: 0.86rem; color: #E2E8F0; line-height: 1.35;">
                ${msg.mensaje}
            </div>
        `;
        container.appendChild(div);
    });
}

function cerrarModalMediacionUser() {
    const modal = document.getElementById('modal-detalle-mediacion-user');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.add('panel-hidden');
    }
    mediacionSeleccionadaId = null;
}

// Guardar respuesta del trabajador
async function guardarRespuestaMediacionUser() {
    if (!mediacionSeleccionadaId) return;
    const med = userMediacionesList.find(m => m.id === mediacionSeleccionadaId);
    if (!med) return;

    const input = document.getElementById('modalUserMedRespuestaInput');
    const texto = input.value.trim();

    if (!texto) {
        alert('Por favor escribe un mensaje antes de enviar.');
        return;
    }

    let user = {};
    try { user = JSON.parse(localStorage.getItem('siai_usuario') || '{}'); } catch(e){}

    const now = new Date();
    const fechaStr = now.toLocaleDateString('es-MX') + ' ' + now.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });

    if (!Array.isArray(med.mensajes)) med.mensajes = [];

    med.mensajes.push({
        autor: user.nombre_completo || 'Trabajador Operativo',
        rol: 'Trabajador',
        fecha: fechaStr,
        mensaje: texto
    });

    // Guardar en LocalStorage
    const todas = JSON.parse(localStorage.getItem('rymco_mediaciones_quejas') || '[]');
    const idx = todas.findIndex(m => m.id === med.id);
    if (idx > -1) {
        todas[idx].mensajes = med.mensajes;
        localStorage.setItem('rymco_mediaciones_quejas', JSON.stringify(todas));
    }

    // Guardar en Firestore
    if (typeof firebase !== 'undefined' && firebase.firestore) {
        try {
            const db = firebase.firestore();
            await db.collection('mediaciones_quejas').doc(med.id).update({
                mensajes: med.mensajes
            });
        } catch(err) {
            console.warn('[Firebase] Error al guardar mensaje:', err);
        }
    }

    input.value = '';
    renderHiloMensajesMediacionUser(med);
    alert('Mensaje enviado al Administrador.');
}

window.userEnviarMediacion = userEnviarMediacion;
window.abrirModalMediacionUser = abrirModalMediacionUser;
window.cerrarModalMediacionUser = cerrarModalMediacionUser;
window.guardarRespuestaMediacionUser = guardarRespuestaMediacionUser;
