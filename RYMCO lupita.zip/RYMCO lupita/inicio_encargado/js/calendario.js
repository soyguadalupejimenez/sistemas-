// ==========================================================================
// SIAI RYMCO - MÓDULO DE CALENDARIO DE PLANTA (ENCARGADO DE PLANTA)
// ==========================================================================

let currentDate = new Date();
let currentSelectedDayKey = '';

const monthNamesCal = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];
const dayNamesCal = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

const festivosOficiales = {
    '01-01': { titulo: 'Año Nuevo', desc: 'Día de descanso obligatorio oficial.' },
    '02-05': { titulo: 'Día de la Constitución Mexicana', desc: 'Conmemoración oficial de la Constitución.' },
    '03-21': { titulo: 'Natalicio de Benito Juárez', desc: 'Día festivo oficial en México.' },
    '05-01': { titulo: 'Día del Trabajo', desc: 'Día de descanso obligatorio para trabajadores.' },
    '09-16': { titulo: 'Día de la Independencia de México', desc: 'Fiesta patria oficial y descanso obligatorio.' },
    '11-20': { titulo: 'Revolución Mexicana', desc: 'Conmemoración del inicio de la Revolución.' },
    '12-25': { titulo: 'Navidad', desc: 'Celebración de Navidad y descanso oficial.' }
};

// Renderizar Cuadrícula del Calendario
function renderCalendar() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const titleEl = document.getElementById('currentMonthYear');
    if (titleEl) {
        titleEl.textContent = `${monthNamesCal[month]} ${year}`;
    }

    const firstDayIndex = new Date(year, month, 1).getDay();
    const lastDate = new Date(year, month + 1, 0).getDate();
    const prevLastDate = new Date(year, month, 0).getDate();

    const grid = document.getElementById('calendarDaysGrid');
    if (!grid) return;
    grid.innerHTML = '';

    const today = new Date();
    const notas = JSON.parse(localStorage.getItem('rymco_encargado_calendar_notes') || '{}');

    // Días del mes anterior
    for (let i = firstDayIndex; i > 0; i--) {
        const prevDay = prevLastDate - i + 1;
        const cell = document.createElement('div');
        cell.className = 'cal-day-cell other-month';
        cell.innerHTML = `<span class="cal-day-number">${prevDay}</span>`;
        grid.appendChild(cell);
    }

    // Días del mes actual
    for (let day = 1; day <= lastDate; day++) {
        const cell = document.createElement('div');
        cell.className = 'cal-day-cell';

        const isToday = (day === today.getDate() && month === today.getMonth() && year === today.getFullYear());
        if (isToday) cell.classList.add('today');

        const keyMesDia = `${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const keyFechaCompleta = `${year}-${keyMesDia}`;
        
        let badgesHtml = '<div class="cal-badges-wrapper">';

        // Buscar si hay juntas este día
        if (typeof juntasList !== 'undefined' && Array.isArray(juntasList)) {
            const juntasDelDia = juntasList.filter(j => j.fecha === keyFechaCompleta);
            juntasDelDia.forEach(j => {
                badgesHtml += `<span class="cal-event-tag tag-junta">Junta ${j.hora}</span>`;
            });
        }

        if (festivosOficiales[keyMesDia]) {
            badgesHtml += `<span class="cal-event-tag tag-festivo">Festivo Oficial</span>`;
        }

        if (day === 15 || day === lastDate) {
            badgesHtml += `<span class="cal-event-tag tag-pago">Pago Nómina</span>`;
        }

        if (notas[keyFechaCompleta]) {
            badgesHtml += `<span class="cal-event-tag tag-nota">Nota</span>`;
        }

        badgesHtml += '</div>';

        cell.innerHTML = `
            <span class="cal-day-number">${day}</span>
            ${badgesHtml}
        `;

        cell.addEventListener('click', () => {
            abrirDetalleDia(year, month, day);
        });

        grid.appendChild(cell);
    }
}

function cambiarMes(delta) {
    currentDate.setMonth(currentDate.getMonth() + delta);
    renderCalendar();
}

function irAlMesActual() {
    currentDate = new Date();
    renderCalendar();
}

function abrirDetalleDia(year, month, day) {
    const dateObj = new Date(year, month, day);
    const dayOfWeek = dayNamesCal[dateObj.getDay()];
    const keyMesDia = `${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    currentSelectedDayKey = `${year}-${keyMesDia}`;

    document.getElementById('modalDiaTitulo').textContent = `${dayOfWeek}, ${day} de ${monthNamesCal[month]} de ${year}`;

    const badgeBox = document.getElementById('modalDiaEventoBadge');
    const descBox = document.getElementById('modalDiaEventoDesc');
    const isLastDay = day === new Date(year, month + 1, 0).getDate();

    let eventosDelDia = [];

    // Juntas del día
    if (typeof juntasList !== 'undefined' && Array.isArray(juntasList)) {
        const juntasDelDia = juntasList.filter(j => j.fecha === currentSelectedDayKey);
        if (juntasDelDia.length > 0) {
            juntasDelDia.forEach(j => {
                eventosDelDia.push(`<strong>Junta (${j.hora} hrs):</strong> ${j.titulo} en <em>${j.lugar}</em>`);
            });
        }
    }

    if (festivosOficiales[keyMesDia]) {
        const f = festivosOficiales[keyMesDia];
        eventosDelDia.push(`<strong>${f.titulo}:</strong> ${f.desc}`);
        badgeBox.innerHTML = `<span style="color: #EF4444; background: rgba(239, 68, 68, 0.15); padding: 4px 10px; border-radius: 12px; border: 1px solid rgba(239, 68, 68, 0.3);">Día Festivo Oficial (Descanso)</span>`;
    } else if (day === 15 || isLastDay) {
        eventosDelDia.push(`<strong>Pago de Nómina:</strong> Depósito de nómina quincenal.`);
        badgeBox.innerHTML = `<span style="color: #10B981; background: rgba(16, 185, 129, 0.15); padding: 4px 10px; border-radius: 12px; border: 1px solid rgba(16, 185, 129, 0.3);">Día de Pago</span>`;
    } else {
        badgeBox.innerHTML = `<span style="color: #38BDF8; background: rgba(6, 182, 212, 0.15); padding: 4px 10px; border-radius: 12px; border: 1px solid rgba(6, 182, 212, 0.3);">Jornada Regular de Planta</span>`;
    }

    if (eventosDelDia.length === 0) {
        eventosDelDia.push(`Turno ordinario de operación y producción en planta.`);
    }

    descBox.innerHTML = eventosDelDia.join('<br><br>');

    const notas = JSON.parse(localStorage.getItem('rymco_encargado_calendar_notes') || '{}');
    const notaActual = notas[currentSelectedDayKey] || '';
    document.getElementById('modalDiaNotaInput').value = notaActual;

    document.getElementById('modal-dia-detalle').style.display = 'flex';
}

function cerrarDetalleDia() {
    const modal = document.getElementById('modal-dia-detalle');
    if (modal) modal.style.display = 'none';
}

function guardarNotaDia() {
    const notaInput = document.getElementById('modalDiaNotaInput');
    const texto = notaInput.value.trim();
    const notas = JSON.parse(localStorage.getItem('rymco_encargado_calendar_notes') || '{}');

    if (texto) {
        notas[currentSelectedDayKey] = texto;
    } else {
        delete notas[currentSelectedDayKey];
    }

    localStorage.setItem('rymco_encargado_calendar_notes', JSON.stringify(notas));
    renderCalendar();
    cerrarDetalleDia();
}
