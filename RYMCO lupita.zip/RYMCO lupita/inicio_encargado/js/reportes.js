// ==========================================================================
// SIAI RYMCO - MÓDULO DE REPORTES DE ANOMALÍAS (ENCARGADO DE PLANTA)
// ==========================================================================

let encargadoAnomaliasList = [];
let filtroAnomaliaActual = 'pendientes';
let anomaliaEncargadoSeleccionadaId = null;

// Cargar anomalías desde Firebase / LocalStorage
async function cargarReportesEncargado() {
    let cargadas = [];

    if (typeof firebase !== 'undefined' && firebase.firestore) {
        try {
            const db = firebase.firestore();
            const snap = await db.collection('reportes_anomalias').orderBy('creadoEl', 'desc').get();
            snap.forEach(doc => {
                cargadas.push({ id: doc.id, ...doc.data() });
            });
        } catch (e) {
            console.warn('[Firebase Anomalías Encargado]:', e);
        }
    }

    if (cargadas.length === 0) {
        const local = localStorage.getItem('rymco_reportes_anomalias');
        if (local) {
            try { cargadas = JSON.parse(local); } catch(e){}
        }
    }

    if (cargadas.length === 0) {
        cargadas = [
            {
                id: 'rep_demo_1',
                titulo: 'Pedacería de tubo y scrap tirado en pasillo',
                categoria: 'Orden y Limpieza',
                gravedad: 'Media',
                trabajadorInvolucrado: 'Operadores Línea 1 (Turno Matutino)',
                area: 'Línea de Rolado - Pasillo Central',
                descripcion: 'Al realizar el recorrido de inspección se detectaron restos de tubo cortado y pedacería metálica sobre el piso del pasillo principal, representando un riesgo de tropiezo.',
                fotoEvidencia: '',
                fecha: '2026-09-03 08:30',
                reportadoPor: 'Administrador SIAI',
                estado: 'Abierto',
                respuestas: [],
                creadoEl: new Date().toISOString()
            }
        ];
        localStorage.setItem('rymco_reportes_anomalias', JSON.stringify(cargadas));
    }

    encargadoAnomaliasList = cargadas;
    actualizarContadoresReportesEncargado();
    renderReportesEncargado();
}

function actualizarContadoresReportesEncargado() {
    let countP = 0;
    let countAtendidos = 0;
    let countT = encargadoAnomaliasList.length;

    encargadoAnomaliasList.forEach(r => {
        if (r.estado === 'Abierto' || r.estado === 'En Proceso' || r.estado === 'En Revisión') {
            countP++;
        } else if (r.estado === 'Atendido / Resuelto' || r.estado === 'Resuelto') {
            countAtendidos++;
        }
    });

    const elP = document.getElementById('countReportesPendientes');
    const elA = document.getElementById('countReportesAtendidos');
    const elT = document.getElementById('countReportesTodos');
    const elSide = document.getElementById('sidebarReportesCount');

    if (elP) elP.textContent = countP;
    if (elA) elA.textContent = countAtendidos;
    if (elT) elT.textContent = countT;

    if (elSide) {
        elSide.textContent = countP;
        elSide.style.display = countP > 0 ? 'inline-block' : 'none';
    }
}

function filtrarReportesEncargado(tipo) {
    filtroAnomaliaActual = tipo;
    document.querySelectorAll('#reportes-encargado-container .juntas-tab-btn').forEach(b => b.classList.remove('active'));
    const btn = document.getElementById(`tab-rep-${tipo}`);
    if (btn) btn.classList.add('active');
    renderReportesEncargado();
}

function renderReportesEncargado() {
    const container = document.getElementById('reportesGridContainer');
    if (!container) return;
    container.innerHTML = '';

    let filtered = [];
    if (filtroAnomaliaActual === 'pendientes') {
        filtered = encargadoAnomaliasList.filter(r => r.estado === 'Abierto' || r.estado === 'En Proceso' || r.estado === 'En Revisión');
    } else if (filtroAnomaliaActual === 'atendidos') {
        filtered = encargadoAnomaliasList.filter(r => r.estado === 'Atendido / Resuelto' || r.estado === 'Resuelto');
    } else {
        filtered = encargadoAnomaliasList;
    }

    if (filtered.length === 0) {
        container.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 40px 20px; background: rgba(255, 255, 255, 0.02); border: 1px dashed rgba(255, 255, 255, 0.1); border-radius: 16px;">
                <h4 style="color: #FFFFFF; font-size: 1.15rem; margin: 0 0 6px 0;">No hay reportes en este estado</h4>
                <p style="color: #94A3B8; font-size: 0.9rem; margin: 0;">No se han detectado anomalías pendientes en planta.</p>
            </div>
        `;
        return;
    }

    filtered.forEach(r => {
        let badgeGravedadClass = 'tipo-ordinaria';
        if (r.gravedad === 'Alta') badgeGravedadClass = 'tipo-urgente';
        else if (r.gravedad === 'Media') badgeGravedadClass = 'tipo-seguridad';
        else if (r.gravedad === 'Baja') badgeGravedadClass = 'tipo-capacitacion';

        let badgeEstadoStyle = 'background: rgba(239, 68, 68, 0.25); color: #FCA5A5; border: 1px solid rgba(239, 68, 68, 0.4);';
        if (r.estado === 'En Proceso' || r.estado === 'En Revisión') {
            badgeEstadoStyle = 'background: rgba(245, 158, 11, 0.25); color: #FCD34D; border: 1px solid rgba(245, 158, 11, 0.4);';
        } else if (r.estado === 'Atendido / Resuelto' || r.estado === 'Resuelto') {
            badgeEstadoStyle = 'background: rgba(16, 185, 129, 0.25); color: #6EE7B7; border: 1px solid rgba(16, 185, 129, 0.4);';
        }

        const totalResp = Array.isArray(r.respuestas) ? r.respuestas.length : 0;

        const card = document.createElement('div');
        card.className = 'junta-card';
        card.innerHTML = `
            <div>
                <div class="junta-card-header">
                    <span class="badge-tipo-junta ${badgeGravedadClass}">${r.categoria || 'Anomalía'} • ${r.gravedad || 'Media'}</span>
                    <span style="font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 10px; ${badgeEstadoStyle}">${r.estado}</span>
                </div>
                <h3 class="junta-title" style="font-size: 1.15rem;">${r.titulo}</h3>
                
                <div class="junta-meta-row">
                    <div class="junta-meta-item">
                        <span>Trabajador(es):</span> <strong>${r.trabajadorInvolucrado || 'No especificado'}</strong>
                    </div>
                    <div class="junta-meta-item">
                        <span>Área / Ubicación:</span> <strong>${r.area || 'Planta General'}</strong>
                    </div>
                    <div class="junta-meta-item">
                        <span>Reportado:</span> <strong>${r.fecha || 'Reciente'}</strong> por ${r.reportadoPor || 'Administración'}
                    </div>
                </div>

                ${r.fotoEvidencia ? `
                    <div style="margin-bottom: 12px; text-align: center; background: rgba(0,0,0,0.25); padding: 8px; border-radius: 8px;">
                        <img src="${r.fotoEvidencia}" style="max-height: 140px; border-radius: 6px; cursor: pointer; max-width: 100%;" onclick="window.open('${r.fotoEvidencia}', '_blank')">
                        <small style="display: block; font-size: 0.7rem; color: #38BDF8; margin-top: 3px;">Foto de evidencia adjunta</small>
                    </div>
                ` : ''}

                <div class="junta-desc">
                    <strong>Descripción de la anomalía:</strong><br>
                    ${r.descripcion}
                </div>
            </div>

            <div class="junta-footer">
                <button type="button" class="btn-confirmar-asistencia" onclick="abrirModalAnomaliaEncargado('${r.id}')" style="background: rgba(6, 182, 212, 0.2); color: #38BDF8; border-color: rgba(6, 182, 212, 0.4);">
                    Atender / Seguimiento (${totalResp})
                </button>
                <span style="font-size: 0.78rem; color: #94A3B8;">
                    ${r.estado === 'Resuelto' || r.estado === 'Atendido / Resuelto' ? 'Atendido' : 'Pendiente'}
                </span>
            </div>
        `;
        container.appendChild(card);
    });
}

function abrirModalAnomaliaEncargado(id) {
    const r = encargadoAnomaliasList.find(item => item.id === id);
    if (!r) return;
    anomaliaEncargadoSeleccionadaId = id;

    const elTit = document.getElementById('modalEncargadoAnomaliaTitulo');
    const elTrab = document.getElementById('modalEncargadoTrabajador');
    const elArea = document.getElementById('modalEncargadoArea');
    const elFecha = document.getElementById('modalEncargadoFecha');
    const elAutor = document.getElementById('modalEncargadoAutor');
    const elDesc = document.getElementById('modalEncargadoDesc');
    const elBadge = document.getElementById('modalEncargadoEstadoBadge');
    const elGrav = document.getElementById('modalEncargadoGravedadBadge');

    if (elTit) elTit.textContent = r.titulo;
    if (elTrab) elTrab.textContent = r.trabajadorInvolucrado || 'No especificado';
    if (elArea) elArea.textContent = r.area || 'Planta General';
    if (elFecha) elFecha.textContent = r.fecha || 'Reciente';
    if (elAutor) elAutor.textContent = r.reportadoPor || 'Administración';
    if (elDesc) elDesc.textContent = r.descripcion;

    if (elGrav) {
        elGrav.textContent = `Gravedad: ${r.gravedad || 'Media'}`;
        elGrav.className = `badge-tipo-junta ${r.gravedad === 'Alta' ? 'tipo-urgente' : (r.gravedad === 'Baja' ? 'tipo-capacitacion' : 'tipo-seguridad')}`;
    }

    if (elBadge) {
        elBadge.textContent = r.estado;
        elBadge.style.background = (r.estado === 'Resuelto' || r.estado === 'Atendido / Resuelto') ? 'rgba(16, 185, 129, 0.25)' : 'rgba(239, 68, 68, 0.25)';
        elBadge.style.color = (r.estado === 'Resuelto' || r.estado === 'Atendido / Resuelto') ? '#6EE7B7' : '#FCA5A5';
    }

    // Foto
    const fotoCont = document.getElementById('modalEncargadoFotoContainer');
    const fotoImg = document.getElementById('modalEncargadoFotoImg');
    if (r.fotoEvidencia) {
        if (fotoCont) fotoCont.style.display = 'block';
        if (fotoImg) fotoImg.src = r.fotoEvidencia;
    } else {
        if (fotoCont) fotoCont.style.display = 'none';
    }

    // Estado en el select
    const selEstado = document.getElementById('modalEncargadoNuevoEstado');
    if (selEstado) {
        selEstado.value = r.estado === 'Abierto' ? 'En Proceso' : (r.estado === 'Resuelto' || r.estado === 'Atendido / Resuelto' ? 'Atendido / Resuelto' : 'En Proceso');
    }

    renderHiloRespuestasEncargado(r);

    const modal = document.getElementById('modal-responder-anomalia-encargado');
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.remove('panel-hidden');
    }
}

function renderHiloRespuestasEncargado(r) {
    const container = document.getElementById('modalEncargadoHiloRespuestas');
    if (!container) return;
    container.innerHTML = '';

    const respuestas = Array.isArray(r.respuestas) ? r.respuestas : [];
    if (respuestas.length === 0) {
        container.innerHTML = `
            <div style="font-size: 0.82rem; color: #94A3B8; text-align: center; padding: 10px; background: rgba(255,255,255,0.02); border-radius: 8px;">
                Sin respuestas registradas todavía. Agrega la primera acción tomada abajo.
            </div>
        `;
        return;
    }

    respuestas.forEach(resp => {
        const div = document.createElement('div');
        div.style.background = 'rgba(255, 255, 255, 0.04)';
        div.style.border = '1px solid rgba(255, 255, 255, 0.08)';
        div.style.borderRadius = '8px';
        div.style.padding = '8px 12px';

        div.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2px;">
                <span style="font-weight: 700; font-size: 0.8rem; color: #38BDF8;">
                    ${resp.autor} (${resp.rol || 'Encargado'}):
                </span>
                <span style="font-size: 0.7rem; color: #94A3B8;">${resp.fecha}</span>
            </div>
            <div style="font-size: 0.85rem; color: #E2E8F0; line-height: 1.35;">
                ${resp.mensaje}
            </div>
        `;
        container.appendChild(div);
    });
}

function cerrarModalAnomaliaEncargado() {
    const modal = document.getElementById('modal-responder-anomalia-encargado');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.add('panel-hidden');
    }
    anomaliaEncargadoSeleccionadaId = null;
}

async function guardarRespuestaEncargado() {
    if (!anomaliaEncargadoSeleccionadaId) return;
    const r = encargadoAnomaliasList.find(item => item.id === anomaliaEncargadoSeleccionadaId);
    if (!r) return;

    const input = document.getElementById('modalEncargadoRespuestaInput');
    const nuevoEstado = document.getElementById('modalEncargadoNuevoEstado').value;
    const texto = input.value.trim();

    if (!texto) {
        alert('Por favor describe la acción correctiva o comentario antes de guardar.');
        return;
    }

    let user = {};
    try { user = JSON.parse(localStorage.getItem('siai_usuario') || '{}'); } catch(e){}
    const nombreEncargado = user.nombre_completo || 'Encargado de Planta';

    const now = new Date();
    const fechaStr = now.toLocaleDateString('es-MX') + ' ' + now.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });

    if (!Array.isArray(r.respuestas)) r.respuestas = [];

    r.respuestas.push({
        autor: nombreEncargado,
        rol: 'Encargado de Turno',
        fecha: fechaStr,
        mensaje: texto
    });

    r.estado = nuevoEstado;

    // Guardar en LocalStorage
    localStorage.setItem('rymco_reportes_anomalias', JSON.stringify(encargadoAnomaliasList));

    // Guardar en Firebase
    if (typeof firebase !== 'undefined' && firebase.firestore) {
        try {
            const db = firebase.firestore();
            await db.collection('reportes_anomalias').doc(r.id).update({
                estado: r.estado,
                respuestas: r.respuestas
            });
        } catch(err) {
            console.warn('[Firebase] Error actualizando anomalía:', err);
        }
    }

    input.value = '';
    actualizarContadoresReportesEncargado();
    renderReportesEncargado();
    cerrarModalAnomaliaEncargado();
    alert('Acción registrada con éxito. Estatus actualizado a: ' + nuevoEstado);
}
