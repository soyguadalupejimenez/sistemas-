// ==========================================================================
// SIAI RYMCO - NAVEGACIÓN Y PERFIL DE ENCARGADO DE PLANTA
// ==========================================================================

// 1. Navegación entre Paneles del Encargado
function showEncargadoPanel(panelId) {
    const panels = [
        'juntas-panel-container',
        'reportes-encargado-container',
        'avisos-panel-container',
        'calendario-panel-container'
    ];

    panels.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.style.display = 'none';
            el.classList.remove('panel-block');
            el.classList.add('panel-hidden');
        }
    });

    const target = document.getElementById(panelId);
    if (target) {
        target.style.display = 'block';
        target.classList.remove('panel-hidden');
        target.classList.add('panel-block');
    }

    // Actualizar estado activo en el sidebar
    document.querySelectorAll('.admin-nav-item').forEach(li => li.classList.remove('active'));

    if (panelId === 'juntas-panel-container') {
        const item = document.getElementById('menu-juntas');
        if (item) item.classList.add('active');
        if (typeof renderJuntasEncargado === 'function') renderJuntasEncargado();
    } else if (panelId === 'reportes-encargado-container') {
        const item = document.getElementById('menu-reportes');
        if (item) item.classList.add('active');
        if (typeof renderReportesEncargado === 'function') renderReportesEncargado();
    } else if (panelId === 'avisos-panel-container') {
        const item = document.getElementById('menu-avisos');
        if (item) item.classList.add('active');
    } else if (panelId === 'calendario-panel-container') {
        const item = document.getElementById('menu-calendario');
        if (item) item.classList.add('active');
        if (typeof renderCalendar === 'function') renderCalendar();
    }

    // Cerrar automáticamente el sidebar en pantallas pequeñas para ver el panel de bienvenida completo
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    if (sidebar) {
        sidebar.classList.remove('open', 'sidebar-open');
        if (overlay) overlay.classList.remove('active');
    }
}

// 2. Modal de Perfil de Encargado
function mostrarPerfilEncargadoModal() {
    const modal = document.getElementById('modal-perfil-encargado');
    if (!modal) return;

    let user = {};
    try {
        const raw = localStorage.getItem('siai_usuario');
        if (raw) user = JSON.parse(raw);
    } catch (e) {}

    const elFull = document.getElementById('modalEncargadoFullName');
    const elRole = document.getElementById('modalEncargadoRole');
    const elUser = document.getElementById('modalEncargadoUsername');
    const elWork = document.getElementById('modalEncargadoWorkerId');
    const elMail = document.getElementById('modalEncargadoEmail');

    let nombre = user.nombre_completo || 'Encargado de Planta';
    if (nombre.includes('Supervisor')) nombre = 'Encargado de Planta';

    if (elFull) elFull.textContent = nombre;
    if (elRole) elRole.textContent = user.puesto || 'Encargado';
    if (elUser) elUser.textContent = user.username || 'encargado';
    if (elWork) elWork.textContent = user.num_trabajador || 'ENC-101';
    if (elMail) elMail.textContent = user.email || 'encargado@rymco.com';

    modal.style.display = 'flex';
    modal.classList.remove('panel-hidden');
}

function cerrarPerfilEncargadoModal() {
    const modal = document.getElementById('modal-perfil-encargado');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.add('panel-hidden');
    }
}

// Cerrar modales al hacer clic en el backdrop
window.addEventListener('click', function (e) {
    const m1 = document.getElementById('modal-perfil-encargado');
    const m2 = document.getElementById('modal-dia-detalle');
    const m3 = document.getElementById('modal-responder-anomalia-encargado');
    if (e.target === m1) cerrarPerfilEncargadoModal();
    if (e.target === m2 && typeof cerrarDetalleDia === 'function') cerrarDetalleDia();
    if (e.target === m3 && typeof cerrarModalAnomaliaEncargado === 'function') cerrarModalAnomaliaEncargado();
});

// Inicialización general de la sesión del Encargado
document.addEventListener('DOMContentLoaded', function () {
    try {
        const raw = localStorage.getItem('siai_usuario');
        if (raw) {
            const u = JSON.parse(raw);
            let nombreMostrar = u.nombre_completo || 'Encargado de Planta';
            if (nombreMostrar.includes('Supervisor')) {
                nombreMostrar = 'Encargado de Planta';
                u.nombre_completo = nombreMostrar;
                u.puesto = 'Encargado';
                localStorage.setItem('siai_usuario', JSON.stringify(u));
            }
            const elName = document.getElementById('displayEncargadoName');
            if (elName) elName.innerHTML = nombreMostrar + '<br><span>RYMCO S.A. (' + (u.puesto || 'Encargado') + ')</span>';
            const elTop = document.getElementById('topEncargadoLabel');
            if (elTop) elTop.textContent = nombreMostrar;
        }
    } catch (e) { }

    // Asegurar que el sidebar y overlay siempre inicien cerrados en dispositivos móviles
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    if (sidebar) sidebar.classList.remove('open', 'sidebar-open');
    if (overlay) overlay.classList.remove('active');

    // Menú móvil / Toggle
    const toggleBtn = document.getElementById('sidebar-toggle');
    if (toggleBtn && sidebar && overlay) {
        toggleBtn.addEventListener('click', () => {
            const isOpen = sidebar.classList.contains('open') || sidebar.classList.contains('sidebar-open');
            if (isOpen) {
                sidebar.classList.remove('open', 'sidebar-open');
                overlay.classList.remove('active');
            } else {
                sidebar.classList.add('open', 'sidebar-open');
                overlay.classList.add('active');
            }
        });
        overlay.addEventListener('click', () => {
            sidebar.classList.remove('open', 'sidebar-open');
            overlay.classList.remove('active');
        });
    }

    // Cargar datos iniciales
    if (typeof cargarJuntasEncargado === 'function') cargarJuntasEncargado();
    if (typeof cargarReportesEncargado === 'function') cargarReportesEncargado();
    if (typeof renderCalendar === 'function') renderCalendar();
});
