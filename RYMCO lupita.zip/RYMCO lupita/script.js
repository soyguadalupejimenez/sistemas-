// ==========================================================
// SIAI RYMCO - Frontend Script con Firebase y HTML
// ==========================================================

// 1. VISIBILIDAD DE CONTRASEÑA INTERACTIVA
const passwordInput = document.getElementById('password');
const togglePasswordBtn = document.getElementById('togglePassword');

if (togglePasswordBtn && passwordInput) {
    togglePasswordBtn.addEventListener('click', function() {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            togglePasswordBtn.textContent = 'Ocultar';
        } else {
            passwordInput.type = 'password';
            togglePasswordBtn.textContent = 'Mostrar';
        }
        passwordInput.focus(); 
    });
}

// 2. ALTERNAR ENTRE LOGIN, REGISTRO Y RECUPERACIÓN
const loginSection = document.getElementById('loginSection');
const registerSection = document.getElementById('registerSection');
const forgotPasswordSection = document.getElementById('forgotPasswordSection');
const showRegisterBtn = document.getElementById('showRegister');
const showLoginBtn = document.getElementById('showLogin');
const showForgotBtn = document.getElementById('showForgot');
const backToLoginBtn = document.getElementById('backToLogin');

if (showRegisterBtn) {
    showRegisterBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (loginSection) loginSection.style.display = 'none';
        if (forgotPasswordSection) forgotPasswordSection.style.display = 'none';
        if (registerSection) registerSection.style.display = 'block';
    });
}

if (showLoginBtn) {
    showLoginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (registerSection) registerSection.style.display = 'none';
        if (forgotPasswordSection) forgotPasswordSection.style.display = 'none';
        if (loginSection) loginSection.style.display = 'block';
    });
}

if (showForgotBtn) {
    showForgotBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (loginSection) loginSection.style.display = 'none';
        if (registerSection) registerSection.style.display = 'none';
        if (forgotPasswordSection) forgotPasswordSection.style.display = 'block';
    });
}

if (backToLoginBtn) {
    backToLoginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (forgotPasswordSection) forgotPasswordSection.style.display = 'none';
        if (registerSection) registerSection.style.display = 'none';
        if (loginSection) loginSection.style.display = 'block';
    });
}

// 3. GENERADOR DE NOMBRE DE USUARIO SUGERIDO
const regFullName = document.getElementById('regFullName');
const regUsername = document.getElementById('regUsername');

if (regFullName && regUsername) {
    regFullName.addEventListener('input', function() {
        const fullName = this.value.trim().toLowerCase();
        if (fullName.length > 0) {
            const parts = fullName.split(/\s+/);
            let suggested = '';
            
            if (parts.length >= 3) {
                const name = parts.slice(2).join('');
                const lastName = parts[0];
                suggested = `${name}.${lastName}`.replace(/[^a-z0-9.]/g, '');
            } else if (parts.length === 2) {
                suggested = `${parts[1]}.${parts[0]}`.replace(/[^a-z0-9.]/g, '');
            } else {
                suggested = parts[0].replace(/[^a-z0-9.]/g, '');
            }
            
            regUsername.value = suggested;
        } else {
            regUsername.value = '';
        }
    });
}

// 4. REGISTRO DE USUARIOS CON FIREBASE / LOCALSTORAGE
const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', async function(event) {
        event.preventDefault();
        
        const submitBtn = this.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'REGISTRANDO...';
        
        const fullName = document.getElementById('regFullName').value.trim();
        const workerId = document.getElementById('regWorkerId').value.trim();
        const email = document.getElementById('regEmail').value.trim();
        const role = document.getElementById('regJobRole').value;
        const username = document.getElementById('regUsername').value.trim();
        const password = document.getElementById('regPassword').value;
        
        const errorEl = document.getElementById('regErrorMessage');
        const successEl = document.getElementById('regSuccessMessage');
        
        if (errorEl) errorEl.style.display = 'none';
        if (successEl) successEl.style.display = 'none';

        try {
            let registered = false;

            // Intento 1: Registro en Firebase Firestore si está disponible
            if (typeof firebase !== 'undefined' && firebase.firestore) {
                try {
                    const db = firebase.firestore();
                    await db.collection('usuarios').doc(username).set({
                        nombre_completo: fullName,
                        num_trabajador: workerId,
                        email: email,
                        puesto: role,
                        username: username,
                        password: password,
                        fecha_registro: firebase.firestore.FieldValue.serverTimestamp()
                    });
                    registered = true;
                } catch (fbErr) {
                    console.warn('[SIAI Firebase] Advertencia guardando usuario:', fbErr);
                }
            }

            // Intento 2: Registro en LocalStorage como respaldo offline
            const localUsers = JSON.parse(localStorage.getItem('siai_usuarios_registrados') || '[]');
            localUsers.push({
                nombre_completo: fullName,
                num_trabajador: workerId,
                email: email,
                puesto: role,
                username: username,
                password: password
            });
            localStorage.setItem('siai_usuarios_registrados', JSON.stringify(localUsers));
            registered = true;

            if (registered) {
                if (successEl) {
                    successEl.textContent = '¡Registro completado con éxito! Redirigiendo a tu bienvenida...';
                    successEl.style.display = 'block';
                }

                const nuevoUsuario = {
                    nombre_completo: fullName,
                    num_trabajador: workerId,
                    email: email,
                    puesto: role || 'Trabajador',
                    username: username
                };

                let targetUrl = 'inicio_usuario/bienvenidouser.html';
                if (role === 'Administrador') {
                    targetUrl = 'inicio_admin/bienvenidoadmin.html';
                } else if (role === 'Encargado') {
                    targetUrl = 'inicio_encargado/bienvenidoencarg.html';
                }

                setTimeout(() => {
                    iniciarSesionExitosa(nuevoUsuario, targetUrl);
                }, 1000);
            }
        } catch (err) {
            console.error('Error al registrar:', err);
            if (errorEl) {
                errorEl.textContent = 'Error al registrar usuario. Intenta de nuevo.';
                errorEl.style.display = 'block';
            }
            submitBtn.disabled = false;
            submitBtn.textContent = 'REGISTRARSE';
        }
    });
}

// 5. INICIO DE SESIÓN CON FIREBASE / CREDENCIALES DIRECTAS
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async function(event) {
        event.preventDefault();

        const submitBtn = this.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'VERIFICANDO...';

        const username = document.getElementById('username').value.trim(); 
        const password = document.getElementById('password').value;
        const errorMessage = document.getElementById('errorMessage');

        if (errorMessage) errorMessage.style.display = 'none';

        try {
            // A) Verificar Credenciales Directas de Administrador, Encargado u Operador
            if (username.toLowerCase() === 'admin' && password === 'admin123') {
                iniciarSesionExitosa({
                    nombre_completo: 'Administrador SIAI',
                    username: 'admin',
                    puesto: 'Administrador',
                    email: 'admin@rymco.com'
                }, 'inicio_admin/bienvenidoadmin.html');
                return;
            }

            if ((username.toLowerCase() === 'encargado' || username.toLowerCase() === 'supervisor') && (password === 'encargado123' || password === 'supervisor123')) {
                iniciarSesionExitosa({
                    nombre_completo: 'Encargado de Planta',
                    username: 'encargado',
                    puesto: 'Encargado',
                    email: 'encargado@rymco.com'
                }, 'inicio_encargado/bienvenidoencarg.html');
                return;
            }

            if ((username.toLowerCase() === 'usuario' || username.toLowerCase() === 'operador') && (password === 'user123' || password === 'operador123')) {
                iniciarSesionExitosa({
                    nombre_completo: 'Operador de Planta',
                    username: username,
                    puesto: 'Trabajador',
                    email: 'operador@rymco.com'
                }, 'inicio_usuario/bienvenidouser.html');
                return;
            }

            // B) Verificar usuarios en LocalStorage offline
            const localUsers = JSON.parse(localStorage.getItem('siai_usuarios_registrados') || '[]');
            const foundLocal = localUsers.find(u => 
                (u.username === username || u.email === username) && u.password === password
            );

            if (foundLocal) {
                let targetUrl = 'inicio_usuario/bienvenidouser.html';
                if (foundLocal.puesto === 'Administrador') {
                    targetUrl = 'inicio_admin/bienvenidoadmin.html';
                } else if (foundLocal.puesto === 'Encargado') {
                    targetUrl = 'inicio_encargado/bienvenidoencarg.html';
                }
                iniciarSesionExitosa(foundLocal, targetUrl);
                return;
            }

            // C) Verificar usuario en Firebase Firestore
            if (typeof firebase !== 'undefined' && firebase.firestore) {
                try {
                    const db = firebase.firestore();
                    const docSnap = await db.collection('usuarios').doc(username).get();
                    if (docSnap.exists) {
                        const userData = docSnap.data();
                        if (userData.password === password) {
                            let targetUrl = 'inicio_usuario/bienvenidouser.html';
                            if (userData.puesto === 'Administrador') {
                                targetUrl = 'inicio_admin/bienvenidoadmin.html';
                            } else if (userData.puesto === 'Encargado') {
                                targetUrl = 'inicio_encargado/bienvenidoencarg.html';
                            }
                            iniciarSesionExitosa(userData, targetUrl);
                            return;
                        }
                    }
                } catch(e) {
                    console.warn('[SIAI Firebase Auth] Advertencia al consultar Firebase:', e);
                }
            }

            // D) Si fallaron las verificaciones
            showError('Usuario o contraseña incorrectos. Verifica tus datos o usa credenciales de prueba (admin / admin123).');
            submitBtn.disabled = false;
            submitBtn.textContent = 'ACCESO';

        } catch (err) {
            console.error('Error durante la verificación:', err);
            showError('Ocurrió un error al iniciar sesión. Intenta nuevamente.');
            submitBtn.disabled = false;
            submitBtn.textContent = 'ACCESO';
        }
    });
}

function iniciarSesionExitosa(usuarioObj, urlDestino) {
    const submitBtn = document.querySelector('#loginForm button[type="submit"]');
    if (submitBtn) submitBtn.textContent = '¡ACCEDIENDO!';
    
    // Guardar sesión en LocalStorage
    localStorage.setItem('siai_usuario', JSON.stringify(usuarioObj));

    setTimeout(() => {
        window.location.href = urlDestino;
    }, 500);
}

function showError(message) {
    const errorMessage = document.getElementById('errorMessage');
    if (errorMessage) {
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
    }
}

// 6. RECUPERACIÓN DE CONTRASEÑA EN FIREBASE / FRONTEND
const forgotPasswordForm = document.getElementById('forgotPasswordForm');
if (forgotPasswordForm) {
    forgotPasswordForm.addEventListener('submit', async function(event) {
        event.preventDefault();

        const submitBtn = this.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'ENVIANDO...';

        const forgotEmail = document.getElementById('forgotEmail').value.trim();
        const errorEl = document.getElementById('forgotErrorMessage');
        const successEl = document.getElementById('forgotSuccessMessage');

        if (errorEl) errorEl.style.display = 'none';
        if (successEl) successEl.style.display = 'none';

        try {
            if (typeof firebase !== 'undefined' && firebase.auth) {
                try {
                    await firebase.auth().sendPasswordResetEmail(forgotEmail);
                } catch(e) {
                    console.warn('[Firebase Auth] Correo no registrado en Auth o en modo demo:', e);
                }
            }

            if (successEl) {
                successEl.textContent = `Se han enviado las instrucciones de recuperación a ${forgotEmail}.`;
                successEl.style.display = 'block';
            }

            setTimeout(() => {
                if (successEl) successEl.style.display = 'none';
                this.reset();
                if (backToLoginBtn) backToLoginBtn.click();
                submitBtn.disabled = false;
                submitBtn.textContent = 'ENVIAR INSTRUCCIONES';
            }, 4000);

        } catch (err) {
            console.error('Error en recuperación:', err);
            if (errorEl) {
                errorEl.textContent = 'Ocurrió un error al enviar el correo. Verifica tu dirección.';
                errorEl.style.display = 'block';
            }
            submitBtn.disabled = false;
            submitBtn.textContent = 'ENVIAR INSTRUCCIONES';
        }
    });
}