/**
 * SIAI RYMCO - Configuración de Firebase / Compatibility Layer
 */
(function() {
    window.firebaseConfig = window.firebaseConfig || {
        apiKey: "demo-siai-rymco-key",
        authDomain: "siai-rymco.firebaseapp.com",
        projectId: "siai-rymco",
        storageBucket: "siai-rymco.appspot.com",
        messagingSenderId: "000000000000",
        appId: "1:000000000000:web:000000000000"
    };

    if (typeof firebase !== 'undefined' && firebase.apps && !firebase.apps.length) {
        try {
            firebase.initializeApp(window.firebaseConfig);
            console.log('[SIAI RYMCO] Firebase inicializado correctamente.');
        } catch (e) {
            console.warn('[SIAI RYMCO] Advertencia al inicializar Firebase:', e);
        }
    }
})();
