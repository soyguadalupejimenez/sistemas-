# 📖 Manual de Usuario y Guía de Operación Completa: SIAI RYMCO S.A.
> **Sistema Integrado de Análisis de Inventarios, Control de Producción y Gestión Operacional**

---

## 📌 1. Introducción y Propósito del Sistema

El **Sistema Integrado de Análisis de Inventarios (SIAI)** desarrollado para **RYMCO S.A.** es una plataforma digital integral creada para automatizar, controlar y auditar los procesos de fabricación, recuperación y acondicionamiento de tubería conduit (galvanizada, PVC, ligera, pesada) y accesorios eléctricos.

### 🎯 Objetivos Principales:
* **Eliminar Errores de Cálculo Manual**: Sustituye las bitácoras físicas en papel y archivos Excel propensos a equivocaciones por un registro digital validado automáticamente.
* **Visibilidad en Tiempo Real**: Proporciona a la administración y a los operarios información en vivo sobre inventarios, piezas producidas, kilos procesados y rendimiento por turno.
* **Control Multiproceso**: Cubre de forma unificada las 4 áreas operativas de la planta:
  1. ♻️ **Recuperación** (Material reciclado y reutilizable).
  2. 📦 **Acondicionamiento General** (Embalaje, empaque y preparación para despacho).
  3. 🛠️ **Conformado, Rimado y Pintura** (Procesamiento de tubería y acabados).
  4. 🛡️ **Re-galvanización** (Protección anticorrosiva e inmersión).
* **Auditoría y Trazabilidad**: Permite rastrear la producción de cada trabajador, turno y fecha, garantizando métricas precisas para la toma de decisiones empresariales.

---

## 📐 2. Arquitectura del Sistema

```
                               ┌──────────────────────────────────────────────┐
                               │       Interfaz Web (HTML5 / JS / CSS3)       │
                               │  Navegador Web / PWA / Modo App Desktop      │
                               └──────────────────────┬───────────────────────┘
                                                      │
                                   ┌──────────────────┴──────────────────┐
                                   ▼                                     ▼
                      ┌──────────────────────────┐         ┌──────────────────────────┐
                      │ Base de Datos PostgreSQL │         │   API PHP & Middleware   │
                      │        (pdo_pgsql)       │         │ (AuthCheck / Sync API)   │
                      └────────────┬─────────────┘         └─────────────┬────────────┘
                                   │                                     │
                                   └──────────────────┬──────────────────┘
                                                      ▼
                                       ┌─────────────────────────────┐
                                       │ Firebase Cloud & LocalStore │
                                       │    (Respaldo y Offline)     │
                                       └─────────────────────────────┘
```

---

## 💻 3. Requisitos Técnicos y Entorno de Ejecución

### 3.1. Requisitos de Software
* **Servidor Web**: Apache / NGINX o el servidor web integrado de PHP (`php -S localhost:8080`).
* **Intérprete de PHP**: Versión 8.0 o superior (con extensión `pdo_pgsql` / `pdo_mysql` habilitada).
* **Motor de Base de Datos**: PostgreSQL v14+ (o MySQL / MariaDB según la configuración seleccionada).
* **Navegador Web**: Google Chrome, Microsoft Edge, Mozilla Firefox o Safari (versiones actualizadas).
* **Opcional para Modo Escritorio (Windows)**: Python 3.x (para servidor HTTP ligero) o PowerShell 5.1+.

---

## 🛠️ 4. Instalación y Configuración del Servidor PHP / PostgreSQL

### Paso 1: Configurar la Base de Datos PostgreSQL
1. Abre **pgAdmin 4** o tu cliente SQL preferido (DBeaver, TablePlus, psql).
2. Crea una nueva base de datos llamada `siai_rymco`:
   ```sql
   CREATE DATABASE siai_rymco;
   ```
3. Abre la herramienta de consultas (**Query Tool**) sobre la base de datos `siai_rymco` y ejecuta el script de estructura inicial:
   * Tablas creadas: `usuarios`, `trabajadores`, `bitacora`, `inventario`, `configuracion`, `historial_auditoria`.

### Paso 2: Activar la Extensión PostgreSQL en `php.ini`
1. Abre el archivo de configuración `php.ini` de tu servidor PHP (en **XAMPP**: *Control Panel > Apache > Config > PHP (php.ini)*).
2. Busca las líneas de extensiones de PostgreSQL:
   ```ini
   ;extension=pdo_pgsql
   ;extension=pgsql
   ```
3. Remueve el punto y coma `;` inicial para activarlas:
   ```ini
   extension=pdo_pgsql
   extension=pgsql
   ```
4. Guarda los cambios y reinicia el servicio Apache.

### Paso 3: Configurar Credenciales de Conexión
Verifica que las constantes de conexión en `config/conexion.php` o en las configuraciones del proyecto coincidan con tus datos locales:

```php
define('PG_HOST', 'localhost');
define('PG_PORT', '5432');
define('PG_DB', 'siai_rymco');
define('PG_USER', 'postgres');        // Usuario de PostgreSQL
define('PG_PASS', 'tu_contraseña');    // Contraseña asignada en la instalación
```

### Paso 4: Despliegue en la Carpeta `htdocs`
1. Copia la carpeta del proyecto a la ruta web de tu servidor local:
   * **XAMPP**: `C:\xampp\htdocs\siai_rymco\`
   * **Laragon**: `C:\laragon\www\siai_rymco\`
2. Ingresa desde tu navegador a:
   👉 `http://localhost/siai_rymco/index.html` (o `index.php`)

---

## 🔑 5. Credenciales y Roles de Acceso

El sistema cuenta con 2 roles diferenciados de acceso:

| Rol | Usuario por Defecto | Contraseña | Panel Asignado | Permisos y Alcance |
| :--- | :--- | :--- | :--- | :--- |
| **Administrador** | `admin` | `admin123` | [`inicio_admin/bienvenidoadmin.html`](file:///c:/Users/lupit/Downloads/RYMCO%20lupita/sistemas%20lu/proyecto%20ya%20como%20pra%20primer%20parcil/inicio_admin/bienvenidoadmin.html) | Acceso total: KPIs, gestión de inventario, auditoría, alta/baja de trabajadores, avisos, reportes y configuración. |
| **Operador / Usuario** | `usuario` / `operador` | `user123` / `operador123` | [`inicio_usuario/bienvenidouser.html`](file:///c:/Users/lupit/Downloads/RYMCO%20lupita/sistemas%20lu/proyecto%20ya%20como%20pra%20primer%20parcil/inicio_usuario/bienvenidouser.html) | Captura de bitácora diaria, consulta de inventario por proceso, calculadora de pesos, historial propio y reportes individuales. |

---

## 📱 6. Manual del Usuario: Módulo de Operador / Trabajador

El panel de operador está optimizado para facilitar la captura ágil de datos durante la jornada laboral en planta, accesible desde computadoras o dispositivos móviles.

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      PANEL DE OPERADOR (TRABAJADOR)                     │
├───────────────┬──────────────────┬─────────────────┬────────────────────┤
│ 🏠 Inicio     │ 📋 Bitácora      │ 📐 Conduit      │ 🧮 Calculadora     │
│ 📊 Historial  │ 🔄 Turnos        │ 📄 Reportes PDF │ ⚙️ Configuración   │
└───────────────┴──────────────────┴─────────────────┴────────────────────┘
```

### 6.1. Inicio Panel (Dashboard de Operador)
* **Bienvenida Personalizada**: Muestra el nombre del operador y la semana de trabajo actual.
* **Tarjetas KPI**: Resumen rápido de la producción semanal del usuario:
  * 📦 Piezas acumuladas en la semana.
  * ⚖️ Kilos totales registrados.
  * 📋 Número de registros completados en el turno actual.
* **Gráfico de Rendimiento**: Muestra la evolución diaria de producción por piezas.

### 6.2. Captura de Bitácora Diaria (Registro de Producción)
Es el módulo principal para ingresar los trabajos terminados en el turno.
1. **Seleccionar Proceso**: Elige entre *Recuperación*, *Acondicionamiento*, *Conformado/Rimado/Pintura* o *Re-galvanización*.
2. **Seleccionar Producto / Código**: Puedes escribir o seleccionar del menú interactivo. El sistema incluye **Autocomplete inteligente** basado en catálogos y registros previos.
3. **Ingresar Cantidad de Piezas**: Escribe la cantidad procesada.
4. **Ingresar Peso Total (kg)**: Introduce el peso real capturado en báscula.
5. **Seleccionar Turno**: Elige *Mañana*, *Tarde* o *Noche*.
6. **Asignar Trabajadores Responsables**: Permite seleccionar a los miembros del equipo que participaron en el lote.
7. **Guardar Registro**: Al presionar **"Registrar Producción"**, el sistema realiza las siguientes acciones:
   * Calcula automáticamente promedios y valida incongruencias.
   * Guarda el registro en la base de datos local y/o servidor PHP/PostgreSQL.
   * Sincroniza con el almacén central de inventarios.
   * Actualiza los totales en pantalla sin recargar la página.

### 6.3. Catálogo Tubería Conduit
* Proporciona una guía rápida de especificaciones técnicas para tuberías de 1/2", 3/4", 1", 1 1/2", 2", etc.
* Muestra equivalencias en milímetros, diámetros externos, espesores de pared y códigos de color asociados a la planta.

### 6.4. Calculadora y Estimación de Pesos
* Permite calcular el peso teórico acumulado ingresando la cantidad de tramos o piezas de tubería según su cédula y diámetro.
* Útil para contrastar el peso teórico contra el peso real registrado en báscula y detectar discrepancias de densidad o material.

### 6.5. Historial de Registros
* Permite consultar todos los registros ingresados por el operador.
* Incluye buscador en tiempo real, filtros por fecha y opción para descargar la bitácora personal en formato Excel o PDF.

### 6.6. Turnos y Procesos
* Muestra la tabla de horarios de turnos de la planta RYMCO S.A.
* Muestra la asignación de metas diarias por equipo de trabajo.

### 6.7. Reportes PDF y Configuración
* Genera un documento en PDF listo para imprimir o entregar al supervisor al finalizar el turno.

---

## 👨‍💼 7. Manual del Usuario: Módulo Administrativo

El panel administrativo proporciona control global de las operaciones de RYMCO S.A., supervisión de inventario y gestión de personal.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       PANEL DE ADMINISTRACIÓN (ADMIN)                       │
├─────────────────┬──────────────────┬─────────────────┬──────────────────────┤
│ 📊 Dashboard    │ 📋 Bitácora      │ 📦 Inventario   │ ♻️ Recuperación      │
│ 📈 Registros    │ 👥 Trabajadores  │ 💬 Mensajes     │ 📄 Reportes PDF      │
│ ⚙️ Configuración│ 🚪 Cerrar Sesión │                 │                      │
└─────────────────┴──────────────────┴─────────────────┴──────────────────────┘
```

### 7.1. Dashboard Principal (KPIs Ejecutivos)
* **Panel Metrónomo Operativo**: Visión global de producción general de la planta.
* **Indicadores Clave (KPIs)**:
  * Total Piezas Producidas (General y por mes).
  * Kilos Totales Procesados.
  * Porcentaje de Eficiencia Global.
  * Número de Operarios Activos en Planta.
* **Gráficos Dinámicos**: Comparativa visual por proceso y análisis de volumen por turno.

### 7.2. Bitácora Diaria (Supervisión General)
* Visualización centralizada de **todos** los registros de producción ingresados por los distintos operarios en planta.
* **Filtros Avanzados**: Búsqueda por rango de fechas, proceso, turno, trabajador o producto.
* **Edición y Corrección**: El administrador puede editar registros con errores tipográficos o eliminar registros duplicados de la bitácora.

### 7.3. Control de Inventario Multiproceso
* Visualización del stock actual desglosado en los 4 procesos principales (*Recuperación*, *Acondicionamiento*, *Conformado*, *Re-galvanización*).
* **Alertas de Stock Crítico**: Resalta automáticamente en rojo los productos con niveles por debajo del mínimo configurado.
* **Entradas y Salidas**: Registro de movimientos de almacén y ajustes manuales auditados.

### 7.4. Módulo de Recuperación de Material
* Seguimiento específico a la tubería re-procesada y material reciclado.
* Muestra indicadores de merma, tasa de aprovechamiento de materia prima y costos recuperados.

### 7.5. Registro de Producción Histórico
* Mapeo de datos semanales, mensuales y anuales de la planta.
* Permite comparar el desempeño del mes actual con periodos anteriores.

### 7.6. Gestión de Trabajadores y Personal
* **Alta de Operarios**: Registro de nuevos trabajadores con nombre completo, número de empleado, puesto y turno.
* **Estadísticas de Rendimiento**: Gráficas individuales que evalúan la productividad de cada trabajador (piezas por hora y kilos por turno).
* **Control de Estado**: Habilitar, deshabilitar o suspender acceso a operarios.

### 7.7. Centro de Mensajes y Avisos a Planta
* Permite redactar comunicados o alertas que aparecerán en la pantalla principal de los operarios al ingresar al sistema (ej. *"Mantenimiento en línea 2 a las 14:00 hrs"*).

### 7.8. Reportes PDF Ejecutivos
* Exportación de reportes institucionales listos para firma directiva, con encabezado oficial de RYMCO S.A., desglose por proceso y firma de conformidad.

### 7.9. Configuración del Sistema y Mantenimiento
* **Datos de la Empresa**: Razón Social, RFC, Dirección y Teléfonos de contacto.
* **Semana a Trabajar**: Configuración del periodo de trabajo activo.
* **Gestión de Usuarios y Seguridad**: Cambio de contraseñas de administradores y operadores.
* **Respaldo de Base de Datos (Backup)**: Exportación completa de los datos en formato JSON / SQL.
* **Limpieza de Sistema**: Mantenimiento preventivo para purgar logs antiguos o restablecer datos de prueba.

---

## 🚀 8. Lanzadores Ejecutables Modo Escritorio (Windows Desktop)

Para facilitar el acceso al personal sin necesidad de escribir comandos o abrir servidores manualmente, la carpeta del proyecto incluye ejecutables directos para Windows:

### 8.1. Lanzador por Lote: [`ABRIR_SIAI_RYMCO.bat`](file:///c:/Users/lupit/Downloads/RYMCO%20lupita/sistemas%20lu/proyecto%20ya%20como%20pra%20primer%20parcil/ABRIR_SIAI_RYMCO.bat)
* **¿Qué hace?**: 
  1. Inicia un servidor local ligero en el puerto `8080`.
  2. Detecta la presencia de Microsoft Edge o Google Chrome.
  3. Abre la aplicación en **Modo App Ventana Independiente** (`--app=http://localhost:8080/index.html`), ocultando la barra de direcciones y pestañas para simular una aplicación nativa de escritorio.
* **Instrucciones de uso**: Dar doble clic sobre el archivo [`ABRIR_SIAI_RYMCO.bat`](file:///c:/Users/lupit/Downloads/RYMCO%20lupita/sistemas%20lu/proyecto%20ya%20como%20pra%20primer%20parcil/ABRIR_SIAI_RYMCO.bat).

### 8.2. Lanzador Oculto: `EJECUTAR_SIAI_RYMCO.vbs`
* **¿Qué hace?**: Ejecuta la apertura del sistema sin mostrar la ventana de consola negra (cmd/powershell), brindando una experiencia limpia al usuario final.
* **Instrucciones de uso**: Se puede crear un acceso directo en el Escritorio de Windows apuntando a este archivo.

### 8.3. Script PowerShell: [`start_server.ps1`](file:///c:/Users/lupit/Downloads/RYMCO%20lupita/sistemas%20lu/proyecto%20ya%20como%20pra%20primer%20parcil/start_server.ps1)
* **¿Qué hace?**: Inicia el servidor web en PowerShell y lanza la aplicación en el puerto `8080`.
* **Uso en consola**:
  ```powershell
  powershell -ExecutionPolicy Bypass -File start_server.ps1
  ```

---

## ❓ 9. Solución de Problemas Frecuentes (Troubleshooting)

| Problema / Mensaje | Causa Probable | Solución Paso a Paso |
| :--- | :--- | :--- |
| **`Fatal error: Uncaught PDOException: Could not find driver`** | La extensión `pdo_pgsql` o `pdo_mysql` no está activada en `php.ini`. | 1. Abre `php.ini`.<br>2. Elimina el `;` al inicio de `extension=pdo_pgsql`.<br>3. Reinicia Apache. |
| **No se pueden guardar registros en la base de datos** | La contraseña o usuario de PostgreSQL en [`config/conexion.php`](file:///c:/Users/lupit/Downloads/RYMCO%20lupita/sistemas%20lu/proyecto%20ya%20como%20pra%20primer%20parcil/includes/auth_check.php) es incorrecto. | Verifica el usuario (`postgres`) y contraseña en [`config/conexion.php`](file:///c:/Users/lupit/Downloads/RYMCO%20lupita/sistemas%20lu/proyecto%20ya%20como%20pra%20primer%20parcil/includes/auth_check.php) probando la conexión desde pgAdmin. |
| **Error `Address already in use` en puerto 8080** | Hay otra aplicación (como Skype, IIS o otra instancia de Python) usando el puerto 8080. | Modifica la variable `$port = 8085` o `%port%` dentro de [`start_server.ps1`](file:///c:/Users/lupit/Downloads/RYMCO%20lupita/sistemas%20lu/proyecto%20ya%20como%20pra%20primer%20parcil/start_server.ps1) / [`ABRIR_SIAI_RYMCO.bat`](file:///c:/Users/lupit/Downloads/RYMCO%20lupita/sistemas%20lu/proyecto%20ya%20como%20pra%20primer%20parcil/ABRIR_SIAI_RYMCO.bat). |
| **Pantalla en blanco o no carga estilos en el navegador** | Ruta de carpetas incorrecta o caché del navegador desactualizada. | Presiona `Ctrl + F5` para forzar la recarga limpia de la página sin caché. |
| **El botón "Registrar Producción" no reacciona** | Campos obligatorios vacíos (Producto, Piezas, Peso o Turno). | Asegúrate de rellenar todos los campos del formulario de la bitácora antes de enviar. |

---

## 📑 10. Preguntas Frecuentes (FAQ)

**1. ¿El sistema funciona sin conexión a Internet?**  
*Sí.* El sistema está diseñado en arquitectura híbrida. Si se interrumpe la conexión a la nube, los datos se almacenan localmente en el navegador (`LocalStorage` / `IndexedDB`) y se sincronizan automáticamente con la base de datos PostgreSQL/MySQL en cuanto el servidor web está activo.

**2. ¿Cómo exporto los reportes para contabilidad o dirección?**  
Tanto en el panel de operador como de administración encontrarás botones de exportación a **Excel (`.xlsx`)** y **PDF (`.pdf`)** en cada una de las tablas de bitácora e inventarios.

**3. ¿Pueden trabajar varios operarios al mismo tiempo?**  
*Sí.* Al instalar el sistema en una red local (LAN) o en un servidor PHP central, cualquier computadora, tablet o teléfono conectado a la red local de RYMCO puede ingresar a través de la IP del servidor (ej. `http://192.168.1.50/siai_rymco`).

---

**SIAI RYMCO S.A. — Sistema Integrado de Análisis de Inventarios**  
*Manual de Usuario y Guía Técnica de Operación — Versión 2.0*
